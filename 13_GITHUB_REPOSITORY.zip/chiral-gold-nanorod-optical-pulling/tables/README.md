# Manuscript Tables Package

This directory contains all 12 scientific tables formatted in CSV and documented for the article:
*Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference*.

## Table Index
- Table 1: Geometrical parameters (baseline vs optimized)
- Table S1: Discrete nanorod coordinates, radii, and 3D unit orientation vectors
- Table 2: Optical and material parameters
- Table 3: Numerical simulation settings across 4 solvers
- Table 4: Multi-solver cross-validation (FDTD, FEM, CDA, Bessel)
- Table 5: Mesh convergence study
- Table 6: Structural optimization progression
- Table 7: Polarization-dependent optomechanical response
- Table 8: Latin Hypercube statistical regression and cross-validation (N=90 train, N=30 test)
- Table 9: Monte Carlo fabrication tolerance (100 realizations, truncated Gaussian g >= 1.0 nm)
- Table 10: Comparison with state-of-the-art optical pulling systems
- Table 11: Nanofabrication pathways and feasibility assessment
