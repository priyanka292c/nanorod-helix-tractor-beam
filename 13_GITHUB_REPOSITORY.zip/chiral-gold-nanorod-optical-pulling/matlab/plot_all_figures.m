% Master plotting script for all 27 figures
close all; clear; clc;
fig_dirs = dir('../figures/Fig*');
for i = 1:length(fig_dirs)
    m_script = fullfile('../figures', fig_dirs(i).name, 'plot_script.m');
    if exist(m_script, 'file')
        fprintf('Executing %s...\n', m_script);
        run(m_script);
    end
end
fprintf('All figure scripts completed successfully.\n');
