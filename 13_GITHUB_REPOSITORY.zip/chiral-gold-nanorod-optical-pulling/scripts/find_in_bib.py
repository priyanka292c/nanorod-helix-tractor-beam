with open('08_references.bib', 'r', encoding='utf-8') as f:
    text = f.read()

import re

queries = [
    'brzobohaty', 'novotny', 'sukhov', 'durnin', 'mcgloin', 'kajorndejnukul',
    'nieto', 'savage', 'ciraci', 'zhu', 'toscano', 'berthelot', 'taflove',
    'markel', 'hohenester', 'shen', 'lan', 'robbie', 'mark', 'fischer', 'grier'
]

for q in queries:
    matches = re.findall(rf'@\w+\s*\{{\s*([^,\s]*{q}[^,\s]*)', text, re.IGNORECASE)
    print(f"Query '{q}': {matches}")
