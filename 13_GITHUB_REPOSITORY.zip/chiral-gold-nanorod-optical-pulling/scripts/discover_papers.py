import urllib.request
import urllib.parse
import json
import ssl

ctx = ssl.create_default_context()

# Let's search Crossref for relevant ACS papers
queries = [
    ("ACS Applied Nano Materials gold nanorods optical manipulation", "ACS Applied Nano Materials"),
    ("chiral plasmonic gold nanorod helix circular dichroism", "ACS Nano"),
    ("optical pulling tractor beam Bessel beam", "Optics Express"),
    ("Kerker effect forward scattering multipolar interference", "Physical Review Applied"),
    ("chiroptical forces enantioselective optical sorting", "Nano Letters")
]

found_papers = []

for q, target_j in queries:
    url = f"https://api.crossref.org/works?query={urllib.parse.quote(q)}&rows=5&filter=from-pub-date:2020-01-01,type:journal-article"
    req = urllib.request.Request(url, headers={'User-Agent': 'Auditor/1.0 (mailto:priya@du.ac.in)'})
    try:
        with urllib.request.urlopen(req, timeout=8, context=ctx) as resp:
            data = json.loads(resp.read().decode())
            items = data.get("message", {}).get("items", [])
            for item in items:
                doi = item.get("DOI", "")
                title = item.get("title", [""])[0]
                container = item.get("container-title", [""])[0]
                year = str(item.get("published", {}).get("date-parts", [[0]])[0][0])
                authors = []
                for a in item.get("author", []):
                    g = a.get("given", "")
                    f = a.get("family", "")
                    if f:
                        authors.append(f"{f}, {g}".strip() if g else f)
                found_papers.append({
                    "doi": doi,
                    "title": title,
                    "journal": container,
                    "year": year,
                    "authors": " and ".join(authors[:4]) + (" and others" if len(authors) > 4 else ""),
                    "volume": item.get("volume", ""),
                    "pages": item.get("page", "")
                })
    except Exception as e:
        print(f"Error querying {q}: {e}")

print(f"Retrieved {len(found_papers)} papers from Crossref.")
for p in found_papers[:15]:
    print(f"- ({p['year']}) [{p['journal']}] {p['title'][:60]}... DOI: {p['doi']}")

with open(r"C:\Users\I7\.gemini\antigravity-ide\brain\d76ce4c8-2e78-4d3e-a196-e5bd03adf4b5\scratch\crossref_discovered.json", "w", encoding="utf-8") as f:
    json.dump(found_papers, f, indent=2)
