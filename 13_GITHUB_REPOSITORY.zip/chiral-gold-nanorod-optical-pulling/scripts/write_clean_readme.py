content = """# Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference

[![Target Journal: ACS Applied Nano Materials](https://img.shields.io/badge/Journal-ACS%20Applied%20Nano%20Materials-003366.svg)](https://pubs.acs.org/journal/aanmf6)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Status: Submission-Ready](https://img.shields.io/badge/Status-Submission--Ready-success.svg)]()

This repository contains the complete computational implementation, simulation workflows, underlying datasets, figure generation scripts, and manuscript sources for the research article:

> **“Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”**  
> *Priyanka$^1$, Ram Soorat$^{2,*}$, Rajveer Singh$^3$, Narender Kumar$^4$, and Sandeep$^5$*  
> $^1$*Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
> $^2$*School of Technology, Woxsen University, Hyderabad, Telangana 502345, India*  
> $^3$*Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India*  
> $^4$*Department of Physics, Sri Venkateswara College, University of Delhi, New Delhi 110021, India*  
> $^5$*Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India*  
> \*Corresponding Author: `rsoorat@gmail.com`  
> **Paper DOI:** [TO BE ASSIGNED UPON ACCEPTANCE BY ACS]  
> **Repository:** https://github.com/priyaphysics/chiral-gold-nanorod-optical-pulling  
> **Dataset Archive:** Zenodo / GitHub  

---

## Graphical Summary (TOC)
```
       Chiral Au Nanorod Helix Architecture (N = 10, P₀ = 100 nm, r = 20–30 nm, g = 2.0 nm)
                                      +
                   Bessel Vortex Beam (θ₀ = 49.5°, cos θ₀ = 0.650)
                                      ↓
           Collective Near-Field Hybridization (ED-MD-EQ Mode Alignment)
                                      ↓
         Suppressed Retro-Scattering & Giant Forward Asymmetry (g_asym = 0.954)
                                      ↓
      Giant Backward Optical Pulling (Fz = -10.50 pN/(W/μm²), Qpr = -0.712, Δλ = 285 nm)
                                      ↓
                Polarization-Gated Bidirectional Colloidal Sorting
```

---

## Key Scientific Highlights
- **Giant Pulling Force Density:** $F_z = -10.50$ pN/(W/$\mu$m$^2$) at $\lambda_0 = 1060$ nm with a radiation-pressure efficiency of $Q_{\\mathrm{pr}} = -0.712$.
- **Broad Pulling Bandwidth:** 285 nm continuous optical pulling range (875 nm -- 1160 nm).
- **Forward Scattering Asymmetry:** $g_{\\mathrm{asym}} = 0.954$, comfortably exceeding the absorption-corrected pulling threshold $g_{\\mathrm{crit,abs}} = 0.721$.
- **Multi-Solver Cross-Validation:** FDTD primary results validated against Finite Element Method (COMSOL Multiphysics; 2.7% error), Coupled Dipole Approximation (CDA; 5.5% error), and Boundary Element Method (BEM far-field asymmetry; 3.8% error).
- **Polarization Switch:** Inverting beam spin from LCP ($\sigma = -1$) to RCP ($\sigma = +1$) transforms the pulling force into forward propulsion ($F_z = +1.15$ pN/(W/$\mu$m$^2$)), yielding $C_{\\mathrm{chiral}} = 1.00$.
- **Fabrication Tolerance:** 100/100 Monte Carlo disorder realizations maintain robust optical pulling ($>97\\%$ yield lower bound; mean $\\langle F_z \\rangle = -9.82 \\pm 0.62$ pN, range $-10.84$ to $-8.12$ pN).
- **Statistical Optical Predictor:** Circular dichroism (CD) predicts pulling force across 90 Latin Hypercube configurations ($R^2 = 0.947$, independent hold-out $R^2_{\\mathrm{test}} = 0.937$).

---

## Repository Architecture
```
chiral-gold-nanorod-optical-pulling/
├── manuscript/             # LaTeX sources, DOCX, and compiled PDF manuscripts
├── supplementary/          # Supporting Information document and sources
├── figures/                # Fig01 to Fig27 individual reproducible figure directories
├── tables/                 # Tables 1 to 11 in clean CSV and Markdown formats
├── data/                   # Raw, processed, multi-solver validation, and statistical datasets
├── simulations/            # Lumerical LSF scripts, CDA solver, BEM scripts, Bessel decompositions
├── matlab/                 # MATLAB plotting and validation drivers
├── python/                 # Python numerical solvers, Monte Carlo, and regression pipelines
├── scripts/                # Utility scripts for document compilation and audits
└── docs/                   # Detailed reproducibility guides and nanomaterial specifications
```

---

## Computational Reproduction Instructions
Refer to [`docs/REPRODUCIBILITY.md`](docs/REPRODUCIBILITY.md) for full setup instructions and solver requirements.
"""

with open(r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\README.md", "w", encoding="utf-8") as f:
    f.write(content)
print("README.md written successfully!")
