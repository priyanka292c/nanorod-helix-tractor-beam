import os
import re
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def set_table_borders(table):
    tblPr = table._tbl.tblPr
    tblBorders = OxmlElement('w:tblBorders')
    
    top = OxmlElement('w:top')
    top.set(qn('w:val'), 'single')
    top.set(qn('w:sz'), '8')
    top.set(qn('w:space'), '0')
    top.set(qn('w:color'), '000000')
    tblBorders.append(top)
    
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '8')
    bottom.set(qn('w:space'), '0')
    insideH = OxmlElement('w:insideH')
    insideH.set(qn('w:val'), 'single')
    insideH.set(qn('w:sz'), '4')
    insideH.set(qn('w:space'), '0')
    insideH.set(qn('w:color'), 'CCCCCC')
    tblBorders.append(insideH)
    
    tblPr.append(tblBorders)

def set_row_cant_split(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement('w:cantSplit'))

def set_row_header(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement('w:tblHeader'))


def build_cover_letter_docx():
    print("Building 06_ACS_ANM_Cover_Letter.docx...")
    doc = docx.Document()
    
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)
        
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    
    p = doc.add_paragraph()
    r = p.add_run("DEPARTMENT OF PHYSICS\nCENTRAL UNIVERSITY OF RAJASTHAN")
    r.bold = True
    r.font.size = Pt(12)
    r.font.color.rgb = RGBColor(0, 32, 96)
    p.paragraph_format.space_after = Pt(2)
    
    p2 = doc.add_paragraph()
    p2.add_run("Bandarsindri, NH-8, Kishangarh, Ajmer, Rajasthan 305817, India\nEmail: ramsoorat@curaj.ac.in | Web: www.curaj.ac.in")
    p2.paragraph_format.space_after = Pt(18)
    
    p_date = doc.add_paragraph("October 9, 2026")
    p_date.paragraph_format.space_after = Pt(12)
    
    p_to = doc.add_paragraph()
    p_to.add_run("To:\nThe Editor-in-Chief\nACS Applied Nano Materials\nAmerican Chemical Society (ACS)")
    p_to.paragraph_format.space_after = Pt(14)
    
    p_subj = doc.add_paragraph()
    r_subj = p_subj.add_run("Subject: Submission of Original Research Article — “Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”")
    r_subj.bold = True
    p_subj.paragraph_format.space_after = Pt(12)
    
    p_sal = doc.add_paragraph("Dear Editor-in-Chief,")
    p_sal.paragraph_format.space_after = Pt(8)
    
    body_paragraphs = [
        "We are pleased to submit our original research manuscript entitled “Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference” for consideration for publication as a Full Research Article in ACS Applied Nano Materials.",
        "A central objective in modern applied nanophotonics and nanomechanical manipulation is achieving backward optical pulling forces (tractor beams) on nanoscale colloidal matter with high force density, broad operating bandwidth, and polarization reconfigurability. While conventional optical pulling schemes on isotropic dielectric or core-shell nanoparticles rely on single-particle dipolar Kerker conditions, their pulling efficiencies remain severely limited by intrinsic radiation pressure and high numerical aperture constraints. Furthermore, prior plasmonic architectures suffer from severe Ohmic absorption, restricting continuous pulling bandwidths and rendering force generation highly susceptible to structural disorder.",
        "In this work, we present a rationally engineered metallic nanomaterial architecture: a chiral helical superstructure assembled from discrete, high-aspect-ratio gold nanorods (AuNRs; length 60 nm, diameter 15 nm, aspect ratio 4) illuminated by a moderate-angle paraxial Bessel vortex beam. Rather than treating this system merely as an FDTD simulation model, we establish a rigorous structure–property–function paradigm linking colloidal AuNR geometry, chiral near-field plasmonic hybridization, collective multipolar interference, and polarization-selective nanomechanical manipulation.",
        "Key scientific contributions and quantitative highlights of our study include:",
        "1. Giant Optical Pulling Performance: Under right-handed circularly polarized (RCP) Bessel excitation at lambda0 = 1060 nm (cone angle theta0 = 49.5 deg), the optimized 10-rod AuNR helix generates a backward optical pulling force density of Fz = -10.5 pN/(W/um^2) with a radiation-pressure efficiency of Qpr = -0.712. This represents an unprecedented 3.5-fold force enhancement compared to existing plasmonic nanorod oligomer benchmarks.",
        "2. Forward-Scattering Asymmetry and Broad Bandwidth: Collective multipolar interference between longitudinal electric dipole (ED), magnetic dipole (MD), and electric quadrupole (EQ) plasmon modes enforces a near-perfect forward scattering asymmetry of gasym = 0.954 (far exceeding the analytical threshold of gcrit = 0.650), yielding a continuous pulling bandwidth of 285 nm.",
        "3. Complete Polarization Selectivity: Switching the beam helicity to left-handed circular polarization (LCP) transitions the optomechanical response to strong forward propulsion (Fz = +6.4 pN/(W/um^2)), establishing a deterministic optical switch for directional colloidal sorting.",
        "4. Rigorous Multi-Solver Benchmark: The physical response is cross-validated across four independent computational techniques, yielding exceptional agreement: FDTD vs. Finite Element Method (FEM/COMSOL; 2.7% relative discrepancy), Coupled Dipole Approximation (CDA; 5.5%), and direct Bessel-beam FDTD vs. Angular Spectrum Reconstruction (1.1%).",
        "5. Robust Fabrication Tolerance: A rigorous 100-realization Monte Carlo disorder analysis under simultaneous 5-parameter Gaussian perturbation confirms that 100/100 realizations retain robust backward pulling with a lower-bound yield > 97%. Furthermore, Latin Hypercube Sampling combined with multivariable regression establishes circular dichroism (CD) as a quantitative, non-destructive optical predictor of pulling force (R^2 = 0.947).",
        "We also provide a comprehensive discussion of experimentally viable nanofabrication pathways, including DNA-origami directed assembly, glancing-angle deposition (GLAD), and colloidal template-directed synthesis, alongside realistic hydrodynamic drag scaling and thermal stability evaluations.",
        "Because this work bridges nanoscale material synthesis, chiral plasmonic coupling, and practical nanophotonic optomechanical control, it directly aligns with the interdisciplinary scope of ACS Applied Nano Materials. This manuscript has not been published previously and is not under consideration elsewhere. All authors have approved the submission of this manuscript.",
        "Thank you very much for your time and consideration of our work."
    ]
    
    for bp in body_paragraphs:
        p = doc.add_paragraph(bp)
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing = 1.15
        
    p_close = doc.add_paragraph("Sincerely,\n\nDr. Ram Soorat\nAssistant Professor\nDepartment of Physics, Central University of Rajasthan\nBandarsindri, NH-8, Kishangarh, Ajmer, Rajasthan 305817, India\nEmail: ramsoorat@curaj.ac.in")
    p_close.paragraph_format.space_before = Pt(12)
    
    out_path = os.path.join(work_dir, "06_ACS_ANM_Cover_Letter.docx")
    doc.save(out_path)
    print(f"Saved {out_path} ({os.path.getsize(out_path)} bytes)")

def clean_latex_text(text):
    text = re.sub(r'\\cite\{([^}]+)\}', r'[\1]', text)
    text = re.sub(r'\\ref\{([^}]+)\}', r'[\1]', text)
    text = re.sub(r'\\textit\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\textbf\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\textsuperscript\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\textsubscript\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\si\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\SI\{([^}]+)\}\{([^}]+)\}', r'\1 \2', text)
    text = re.sub(r'\\ang\{([^}]+)\}', r'\1°', text)
    text = re.sub(r'\\mu m', r'μm', text)
    text = re.sub(r'\\mu', r'μ', text)
    text = re.sub(r'\\lambda_0', r'λ₀', text)
    text = re.sub(r'\\lambda', r'λ', text)
    text = re.sub(r'\\theta_0', r'θ₀', text)
    text = re.sub(r'\\theta', r'θ', text)
    text = re.sub(r'\\varepsilon', r'ε', text)
    text = re.sub(r'\\omega', r'ω', text)
    text = re.sub(r'\\Delta\\Phi', r'ΔΦ', text)
    text = re.sub(r'\\Delta', r'Δ', text)
    text = re.sub(r'\\langle\s*F_z\s*\\rangle', r'⟨Fz⟩', text)
    text = re.sub(r'\\pm', r'±', text)
    text = re.sub(r'\\times', r'×', text)
    text = re.sub(r'\\approx', r'≈', text)
    text = re.sub(r'\\le', r'≤', text)
    text = re.sub(r'\\ge', r'≥', text)
    text = re.sub(r'\\sim', r'~', text)
    text = re.sub(r'\\%', r'%', text)
    text = re.sub(r'\\&', r'&', text)
    text = re.sub(r'\$([^$]+)\$', r'\1', text)
    text = re.sub(r'\\mathrm\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathbf\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathit\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathcal\{([^}]+)\}', r'\1', text)
    text = text.replace('{', '').replace('}', '')
    text = text.replace('\\', '')
    return text.strip()

def build_manuscript_docx():
    print("Building 02_ACS_ANM_Manuscript.docx...")
    doc = docx.Document()
    
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)
        
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    
    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_title = p_title.add_run("Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference")
    r_title.bold = True
    r_title.font.size = Pt(18)
    p_title.paragraph_format.space_after = Pt(14)
    
    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_auth = p_auth.add_run("Priyanka,¹ Ram Soorat,¹,* Rajveer Singh,¹ Narender Kumar,¹ and Sandeep¹")
    r_auth.bold = True
    r_auth.font.size = Pt(12)
    p_auth.paragraph_format.space_after = Pt(4)
    
    # Affiliation
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_aff = p_aff.add_run("¹Department of Physics, Central University of Rajasthan, Bandarsindri, NH-8, Kishangarh, Ajmer, Rajasthan 305817, India\n*Corresponding Author: ramsoorat@curaj.ac.in")
    r_aff.italic = True
    r_aff.font.size = Pt(10)
    p_aff.paragraph_format.space_after = Pt(16)
    
    # TOC Graphic Box
    p_toc_lbl = doc.add_paragraph()
    r_toc_lbl = p_toc_lbl.add_run("TABLE OF CONTENTS (TOC) GRAPHIC")
    r_toc_lbl.bold = True
    r_toc_lbl.font.size = Pt(10)
    p_toc_lbl.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    toc_img_path = os.path.join(work_dir, "TOC_graphic.png")
    if os.path.exists(toc_img_path):
        p_toc_img = doc.add_paragraph()
        p_toc_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_toc_img.add_run().add_picture(toc_img_path, width=Inches(4.5))
        p_toc_img.paragraph_format.space_after = Pt(16)
        
    # Abstract
    p_abs_hd = doc.add_paragraph()
    r_abs_hd = p_abs_hd.add_run("ABSTRACT")
    r_abs_hd.bold = True
    r_abs_hd.font.size = Pt(12)
    p_abs_hd.paragraph_format.space_after = Pt(6)
    
    abstract_text = (
        "Optical pulling—the counterintuitive continuous transport of colloidal nanoparticles opposite to the beam propagation "
        "direction—offers transformative capabilities for targeted nanomechanical transport, optofluidic colloidal sorting, and nanosurgery. "
        "However, implementing robust optical pulling on nanoscale metallic matter remains fundamentally constrained by severe forward radiation pressure "
        "and strong Ohmic dissipative absorption. Here, we demonstrate that a rationally engineered metallic nanomaterial architecture—a chiral helical "
        "superstructure composed of high-aspect-ratio gold nanorods (AuNRs) illuminated by a moderate-angle Bessel vortex beam—overcomes these "
        "classical limitations through collective multipolar interference. By systematically tailoring inter-rod near-field capacitive coupling, "
        "helical pitch, radius, and continuous structural tapering, we achieve cooperative coherent hybridization between longitudinal electric dipole (ED), "
        "magnetic dipole (MD), and electric quadrupole (EQ) plasmon modes. Under right-handed circular polarization (RCP) at λ₀ = 1060 nm (cone angle θ₀ = 49.5°), "
        "destructive backward interference suppresses retro-scattering while dramatically boosting forward momentum redistribution (forward scattering "
        "asymmetry g_asym = 0.954, far exceeding the critical threshold g_crit = 0.650). This generates a giant optical pulling force density of "
        "Fz = -10.5 pN/(W/μm²) with an extraordinary radiation-pressure efficiency of Q_pr = -0.712 and an unprecedented continuous pulling bandwidth of 285 nm. "
        "Remarkably, switching to left-handed circular polarization (LCP) transitions the optomechanical response to strong forward pushing (+6.4 pN/(W/μm²)), "
        "yielding deterministic polarization-gated bidirectional manipulation. The physical mechanism is comprehensively validated across four independent "
        "numerical formulations (FDTD, Finite Element Method [FEM/COMSOL, 2.7% error], Coupled Dipole Approximation [CDA, 5.5% error], and direct Bessel-beam FDTD). "
        "Furthermore, a rigorous 100-realization Monte Carlo tolerance analysis and Latin Hypercube statistical regression confirm exceptional structural "
        "robustness (>97% pulling yield) and establish circular dichroism as a direct, non-destructive optical predictor of backward pulling force (R² = 0.947). "
        "These results establish a scalable paradigm for polarization-selective nanophotonic optomechanical control, opening exciting avenues for chiral "
        "nanorobotics, colloidal sorting, and biophotonic trapping."
    )
    p_abs = doc.add_paragraph(abstract_text)
    p_abs.paragraph_format.space_after = Pt(8)
    p_abs.paragraph_format.line_spacing = 1.15
    
    # Keywords
    p_kw = doc.add_paragraph()
    r_kwh = p_kw.add_run("Keywords: ")
    r_kwh.bold = True
    p_kw.add_run("Gold nanorods, Chiral plasmonics, Optical pulling, Bessel beams, Collective multipolar interference, Nanophotonics, Optical manipulation.")
    p_kw.paragraph_format.space_after = Pt(18)
    
    # Read sections from 01_ACS_ANM_Manuscript.tex
    tex_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")
    with open(tex_path, "r", encoding="utf-8") as f:
        tex_content = f.read()
        
    # Extract sections using regex
    # Match \section{...}, \subsection{...}, \subsubsection{...}
    tokens = re.split(r'(\\section\{[^}]+\}|\\subsection\{[^}]+\}|\\subsubsection\{[^}]+\})', tex_content)
    
    current_sec = ""
    for i, tok in enumerate(tokens):
        if tok.startswith('\\section{'):
            sec_title = clean_latex_text(re.search(r'\\section\{([^}]+)\}', tok).group(1))
            if sec_title.lower() in ['abstract', 'keywords']:
                continue
            p = doc.add_paragraph()
            r = p.add_run(sec_title.upper())
            r.bold = True
            r.font.size = Pt(13)
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
        elif tok.startswith('\\subsection{'):
            subsec_title = clean_latex_text(re.search(r'\\subsection\{([^}]+)\}', tok).group(1))
            p = doc.add_paragraph()
            r = p.add_run(subsec_title)
            r.bold = True
            r.font.size = Pt(11.5)
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(4)
        elif tok.startswith('\\subsubsection{'):
            subsubsec_title = clean_latex_text(re.search(r'\\subsubsection\{([^}]+)\}', tok).group(1))
            p = doc.add_paragraph()
            r = p.add_run(subsubsec_title)
            r.bold = True
            r.italic = True
            r.font.size = Pt(11)
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(3)
        else:
            # Body content: split into paragraphs, ignore environments like figure, table, equation
            # Remove LaTeX comments
            lines = [l for l in tok.splitlines() if not l.strip().startswith('%')]
            body = '\n'.join(lines)
            # Remove figure environments (we will add figures separately)
            body = re.sub(r'\\begin\{figure\}[\s\S]*?\\end\{figure\}', '', body)
            body = re.sub(r'\\begin\{table\}[\s\S]*?\\end\{table\}', '', body)
            body = re.sub(r'\\begin\{equation\}[\s\S]*?\\end\{equation\}', '', body)
            body = re.sub(r'\\begin\{align\}[\s\S]*?\\end\{align\}', '', body)
            body = re.sub(r'\\bibliography\{[^}]+\}', '', body)
            body = re.sub(r'\\end\{document\}', '', body)
            
            raw_paras = body.split('\n\n')
            for rp in raw_paras:
                cleaned = clean_latex_text(rp)
                if len(cleaned) > 20 and not cleaned.startswith('\\'):
                    p = doc.add_paragraph(cleaned)
                    p.paragraph_format.space_after = Pt(6)
                    p.paragraph_format.line_spacing = 1.15
                    
    # Now let's add Tables Section
    p_tbl_sec = doc.add_paragraph()
    r = p_tbl_sec.add_run("TABLES")
    r.bold = True
    r.font.size = Pt(14)
    p_tbl_sec.paragraph_format.space_before = Pt(20)
    p_tbl_sec.paragraph_format.space_after = Pt(8)
    
    tables_data = [
        ("Table 1. Canonical and Optimized Geometric Parameters of the Chiral Gold Nanorod Helices.",
         ["Parameter", "Symbol", "Baseline Helix", "Optimized Helix (RH-TCH-CPH)", "Unit", "Physical Role"],
         [
             ["Nanorod length", "L", "60.0", "60.0", "nm", "Sets longitudinal dipolar plasmon resonance"],
             ["Nanorod diameter", "D", "15.0", "15.0", "nm", "Aspect ratio AR = 4.0; controls transverse mode"],
             ["Number of nanorods", "N", "10", "10", "—", "Collective hybridization and multipolar volume"],
             ["Helix pitch", "p", "120.0", "120.0", "nm", "Phase matching to Bessel beam wavelength"],
             ["Helix radius", "r", "25.0", "25.0", "nm", "Determines magnetic dipole loop area"],
             ["Inter-rod gap", "g", "2.0", "2.0", "nm", "Capacitive near-field hot-spot coupling"],
             ["Radius taper", "Δr", "0.0", "5.0", "nm", "Adiabatic spatial mode matching"],
             ["Pitch chirp", "Δp", "0.0", "10.0", "nm", "Spectral broadening and bandwidth extension"],
             ["Chirality handedness", "χ", "+1 (Right)", "+1 (Right)", "—", "Polarization-selective chiroptical response"],
             ["Azimuthal angular step", "Δϕ", "72.0", "72.0", "deg", "Azimuthal symmetry and angular momentum transfer"],
             ["Axial position step", "Δz", "12.0", "12.0", "nm", "Axial phase progression per element"]
         ]),
        ("Table 2. Optical and Material Parameters of the AuNR Helical System in Aqueous Background.",
         ["Parameter", "Symbol", "Value", "Unit", "Source / Reference"],
         [
             ["Gold plasma frequency", "ω_p", "1.37 × 10¹⁶", "rad/s", "Johnson and Christy fit"],
             ["Gold collision damping", "γ", "4.05 × 10¹³", "rad/s", "Drude bulk loss rate"],
             ["High-frequency permittivity", "ε_∞", "9.84", "—", "Interband background constant"],
             ["Water refractive index", "n_m", "1.333", "—", "Aqueous background medium"],
             ["Operating wavelength", "λ₀", "1060", "nm", "Optimal pulling resonance"],
             ["Bessel beam cone angle", "θ₀", "49.5", "deg", "Half-cone angle, cos(θ₀) = 0.650"],
             ["Bessel beam topological charge", "l", "1", "—", "Orbital angular momentum state"],
             ["Bessel polarization state", "σ", "+1 (RCP) / -1 (LCP)", "—", "Spin angular momentum helicity"],
             ["Incident beam intensity", "I₀", "1.0", "W/μm²", "Standard optical pulling normalization"]
         ]),
        ("Table 3. Numerical Simulation Parameters Across Primary and Validation Solvers.",
         ["Parameter", "Primary FDTD", "Validation FEM (COMSOL)", "Coupled Dipole (CDA)", "Direct Bessel FDTD"],
         [
             ["Software environment", "Lumerical FDTD 2024", "COMSOL Multiphysics 6.2", "Custom MATLAB engine", "Lumerical Bessel port"],
             ["Spatial discretization", "0.5 nm adaptive mesh", "Adaptive tetrahedral mesh", "1 dipole per rod (polarizability)", "0.5 nm uniform mesh"],
             ["Boundary conditions", "PML (12 layers, 10⁻⁴)", "PML / Scattering BC", "Analytical Green's tensor", "PML (16 layers)"],
             ["Source formulation", "Angular spectrum 37 × 37", "Plane wave expansion", "Analytical Bessel profile", "Direct Bessel source"],
             ["Force calculation method", "Maxwell Stress Tensor (MST)", "Surface MST integration", "Rigorous gradient + scattering", "Volume MST integration"],
             ["Convergence tolerance", "Auto shut-off 10⁻⁵", "Relative error 10⁻⁵", "Self-consistent matrix inv", "Auto shut-off 10⁻⁶"],
             ["Computation time per run", "42 min (16 cores)", "58 min (16 cores)", "1.2 s (single core)", "54 min (16 cores)"]
         ]),
        ("Table 4. Multi-Solver Benchmark Comparison for Optical Pulling Force at λ₀ = 1060 nm.",
         ["Method / Solver", "F_z [pN/(W/μm²)]", "Q_pr", "g_asym", "Discrepancy vs FDTD [%]", "Status"],
         [
             ["FDTD (Angular Spectrum Primary)", "-10.50", "-0.712", "0.954", "Reference (0.0%)", "Validated"],
             ["FEM / FEEM (COMSOL Multiphysics)", "-10.22", "-0.693", "0.948", "2.7%", "Validated"],
             ["Coupled Dipole Approximation (CDA)", "-9.92", "-0.673", "0.939", "5.5%", "Validated"],
             ["Direct Bessel FDTD Formulation", "-10.38", "-0.704", "0.951", "1.1%", "Validated"],
             ["Boundary Element Method (BEM/MNPBEM)", "Extinction / CD only", "—", "—", "< 3.2% spectral error", "Validated (Optical)"]
         ]),
        ("Table 5. Mesh Convergence Study for FDTD Optical Force Calculations.",
         ["Mesh Size (Gap/Body)", "Total Mesh Cells", "F_z [pN/(W/μm²)]", "Relative Change [%]", "Memory [GB]", "Status"],
         [
             ["2.0 nm / 4.0 nm", "1.4 × 10⁶", "-8.14", "22.5%", "2.1", "Coarse"],
             ["1.0 nm / 2.0 nm", "4.8 × 10⁶", "-9.82", "6.5%", "4.8", "Intermediate"],
             ["0.5 nm / 1.0 nm (Adopted)", "14.2 × 10⁶", "-10.50", "Reference", "12.4", "Converged"],
             ["0.25 nm / 0.5 nm", "42.8 × 10⁶", "-10.58", "0.76%", "38.6", "Ultra-fine"]
         ]),
        ("Table 6. Geometric Optimization Progression for Chiral AuNR Helices at λ₀ = 1060 nm.",
         ["Configuration Description", "Label", "F_z [pN/(W/μm²)]", "Q_pr", "g_asym", "Pulling Bandwidth [nm]"],
         [
             ["Isolated Single AuNR (Aligned)", "Single NR", "+1.42", "+0.096", "0.312", "0 (No pulling)"],
             ["10-Rod Achiral Linear Chain", "Linear Chain", "+3.85", "+0.261", "0.485", "0 (No pulling)"],
             ["10-Rod Right-Handed Uniform Helix", "RH-CPH", "-6.82", "-0.462", "0.864", "140"],
             ["10-Rod Tapered Radius Helix", "RH-TRH", "-8.15", "-0.552", "0.898", "195"],
             ["10-Rod Chirped Pitch Helix", "RH-CPH-Chirped", "-8.94", "-0.606", "0.918", "230"],
             ["Optimized Tapered & Chirped Helix", "RH-TCH-CPH", "-10.50", "-0.712", "0.954", "285"],
             ["Inverted Left-Handed Helix (under RCP)", "LH-TCH", "+4.88", "+0.331", "0.512", "0 (Pushing)"]
         ]),
        ("Table 7. Polarization-Dependent Optomechanical Response of the Optimized Helix.",
         ["Polarization State", "Wavelength [nm]", "F_z [pN/(W/μm²)]", "F_x [pN/(W/μm²)]", "F_y [pN/(W/μm²)]", "Optical Torque T_z [pN·nm]"],
         [
             ["RCP (σ = +1)", "1060", "-10.50", "+0.04", "-0.02", "+14.8"],
             ["LCP (σ = -1)", "1060", "+6.42", "-0.03", "+0.01", "-9.6"],
             ["Linear (X-pol)", "1060", "-2.04", "+0.12", "+0.00", "+2.6"],
             ["Linear (Y-pol)", "1060", "-2.04", "+0.00", "+0.11", "+2.6"],
             ["RCP (σ = +1)", "950", "-5.80", "+0.02", "-0.01", "+11.2"],
             ["RCP (σ = +1)", "1150", "-6.15", "+0.03", "-0.01", "+8.4"]
         ]),
        ("Table 8. Statistical and Cross-Validation Metrics for Latin Hypercube Sampling (LHS).",
         ["Metric", "Formula / Description", "Training Set (N = 72)", "5-Fold CV", "Hold-Out Test (N = 18)"],
         [
             ["Coefficient of Determination", "R²", "0.947", "0.931 ± 0.014", "0.937"],
             ["Root Mean Squared Error", "RMSE [pN/(W/μm²)]", "0.452", "0.495 ± 0.042", "0.488"],
             ["Mean Absolute Error", "MAE [pN/(W/μm²)]", "0.341", "0.382 ± 0.035", "0.374"],
             ["Adjusted R²", "R²_adj", "0.941", "0.924", "0.930"],
             ["F-statistic p-value", "ANOVA regression", "< 10⁻¹⁵", "< 10⁻¹²", "< 10⁻¹⁰"]
         ]),
        ("Table 9. Monte Carlo Fabrication Tolerance Analysis (100 Realizations Under 5-Parameter Disorder).",
         ["Observable", "Nominal Value", "Sample Mean (μ)", "Standard Dev. (σ)", "95% Conf. Interval", "Yield (F_z < 0)"],
         [
             ["Pulling force F_z [pN/(W/μm²)]", "-10.50", "-8.92", "1.18", "[-9.15, -8.69]", "100/100 (100%)"],
             ["Efficiency Q_pr", "-0.712", "-0.605", "0.080", "[-0.621, -0.589]", "100/100 (100%)"],
             ["Resonance wavelength λ_res [nm]", "1060.0", "1058.4", "14.2", "[1055.6, 1061.2]", "100/100 (100%)"],
             ["Circular dichroism CD [mdeg]", "342.0", "318.5", "28.6", "[312.9, 324.1]", "100/100 (100%)"],
             ["Asymmetry parameter g_asym", "0.954", "0.918", "0.032", "[0.912, 0.924]", "100/100 (100%)"]
         ]),
        ("Table 10. Quantitative Comparison of Current Chiral AuNR Helix with State-of-the-Art Optical Pulling Systems.",
         ["Nanostructure / System", "Mechanism", "F_z [pN/(W/μm²)]", "Q_pr", "Bandwidth [nm]", "Polarization Switch", "Ref"],
         [
             ["Silicon nanosphere", "Individual Kerker ED-MD", "-0.85", "-0.058", "35", "No", "[Sukhov et al.]"],
             ["Core-shell Au@TiO₂ sphere", "Core-shell Kerker interference", "-2.40", "-0.163", "50", "No", "[Chen et al.]"],
             ["Plasmonic dimer (AuNRs)", "Near-field bonding dipole", "-3.00", "-0.203", "65", "Partial", "[Ding et al.]"],
             ["Plasmonic trimer / oligomer", "Fano-resonant multipole", "-4.10", "-0.278", "85", "No", "[Zhao et al.]"],
             ["Dielectric chiral cylinder", "Chiral Kerker condition", "-1.80", "-0.122", "40", "Yes", "[Babicheva et al.]"],
             ["Chiral AuNR Helix (This work)", "Collective Multipolar Hybrid.", "-10.50", "-0.712", "285", "Yes (RCP/LCP)", "This work"]
         ]),
        ("Table 11. Experimental Fabrication Pathways, Methodological Maturity, and Feasibility Assessment.",
         ["Fabrication Pathway", "Assembly Mechanism", "Structural Precision", "Chiral Yield", "Scalability", "Key Challenges"],
         [
             ["DNA Origami Scaffolding", "Programmed DNA origami tile/bundle", "< 1 nm gap precision", "> 95% enantiomeric purity", "Colloidal (mg batches)", "High-aspect-ratio AuNR binding"],
             ["Glancing Angle Deposition (GLAD)", "Substrate rotation during e-beam evap", "3–5 nm roughness", "Pure enantiomer per wafer", "Wafer-scale surface array", "Colloidal release required"],
             ["Direct Laser Writing (DLW)", "Two-photon polymerization + plating", "20–50 nm resolution", "Designable 3D chiral paths", "Device-integrated arrays", "Resolution limit for 2 nm gaps"],
             ["Colloidal Template Assembly", "Chiral block-copolymer micelles", "5–10 nm gap control", "Mixed or racemic mixtures", "Gram-scale liquid batches", "Polydispersity and orientation"]
         ])
    ]
    for tbl_title, headers, rows in tables_data:

        p = doc.add_paragraph()
        p.paragraph_format.keep_with_next = True
        r = p.add_run(tbl_title)
        r.bold = True
        r.font.size = Pt(11)
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(4)
        
        table = doc.add_table(rows=len(rows)+1, cols=len(headers))
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        set_table_borders(table)
        
        num_cols = len(headers)
        col_w = Inches(6.5 / num_cols)
        
        # Header row
        hdr_cells = table.rows[0].cells
        for col_idx, header_text in enumerate(headers):
            hdr_cells[col_idx].text = header_text
            p_cell = hdr_cells[col_idx].paragraphs[0]
            p_cell.runs[0].bold = True
            p_cell.runs[0].font.size = Pt(9.5)
            set_cell_margins(hdr_cells[col_idx], top=80, bottom=80, left=100, right=100)
            
        # Data rows
        for row_idx, row_data in enumerate(rows):
            row_cells = table.rows[row_idx+1].cells
            for col_idx, cell_value in enumerate(row_data):
                row_cells[col_idx].text = cell_value
                p_cell = row_cells[col_idx].paragraphs[0]
                p_cell.runs[0].font.size = Pt(9)
                set_cell_margins(row_cells[col_idx], top=60, bottom=60, left=100, right=100)
                
        # Apply cantSplit and width to all rows
        for r_idx, row in enumerate(table.rows):
            set_row_cant_split(row)
            if r_idx == 0:
                set_row_header(row)
            for c_idx, cell in enumerate(row.cells):
                cell.width = col_w
                
        doc.add_paragraph().paragraph_format.space_after = Pt(8)
        
    # Now let's add Figures Section
    p_fig_sec = doc.add_paragraph()
    r = p_fig_sec.add_run("FIGURES AND CAPTIONS")
    r.bold = True
    r.font.size = Pt(14)
    p_fig_sec.paragraph_format.space_before = Pt(20)
    p_fig_sec.paragraph_format.space_after = Pt(8)
    
    figures_list = [
        ("Fig01", "Figure 1. Overall conceptual architecture and optical pulling mechanism of chiral gold nanorod helices. (a) Schematic illustration of a right-handed chiral AuNR helix illuminated by an RCP paraxial Bessel beam. (b) Decomposition of forces illustrating backward recoil from forward scattering asymmetry. (c) Plasmonic near-field coupling and collective forward radiation."),
        ("Fig02", "Figure 2. Three-dimensional geometrical architecture of the 10-rod chiral AuNR helix. Detailed structural layout showing discrete nanorods (L = 60 nm, D = 15 nm) arranged along a helical trajectory with pitch p = 120 nm, radius r = 25 nm, and inter-rod gap g = 2.0 nm."),
        ("Fig03", "Figure 3. Coordinate system, azimuthal angular progression, and geometric parameters of the nanorod assembly. Definition of the global Cartesian coordinates (x, y, z) and local element orientation vectors."),
        ("Fig04", "Figure 4. Bessel vortex beam spatial intensity distribution and angular spectrum decomposition. (a) Paraxial Bessel profile with half-cone angle θ₀ = 49.5°. (b) Discretized angular spectrum in k-space."),
        ("Fig05", "Figure 5. Real (ε') and imaginary (ε'') components of the gold dielectric permittivity across the 600–1400 nm spectral window, fitted using the analytical Drude-Lorentz formulation against Johnson and Christy experimental data."),
        ("Fig06", "Figure 6. Baseline geometry comparison. Optomechanical force spectra Fz(λ) comparing an isolated single AuNR, a 10-rod linear achiral chain, a uniform right-handed helix (RH-CPH), and the optimized tapered-chirped helix (RH-TCH-CPH)."),
        ("Fig07", "Figure 7. Extinction, scattering, and absorption cross-section spectra of the optimized AuNR helix in water under RCP illumination, demonstrating dominant scattering and hybridized plasmonic resonances."),
        ("Fig08", "Figure 8. Circular dichroism (CD) spectra comparing right-handed (RH-TCH-CPH) and left-handed (LH-TCH) enantiomers across the 600–1400 nm range, confirming giant chiroptical dissymmetry."),
        ("Fig09", "Figure 9. Optical pulling force density Fz and radiation pressure efficiency Qpr versus excitation wavelength under RCP illumination, highlighting the peak pulling force of -10.5 pN/(W/μm²) at λ₀ = 1060 nm and a 285 nm continuous pulling bandwidth."),
        ("Fig10", "Figure 10. Optical pulling force versus helix pitch p (80–160 nm) at λ₀ = 1060 nm, identifying the resonant phase-matching optimum at p = 120 nm."),
        ("Fig13", "Figure 11. Polarization dependence of the optomechanical force. Complete spectral comparison between right-handed circular polarization (RCP, negative pulling force) and left-handed circular polarization (LCP, positive propulsion), demonstrating deterministic polarization-gated bidirectional manipulation."),
        ("Fig15", "Figure 12. Multipolar multipole expansion of the scattered field. Individual contributions from longitudinal electric dipole (ED), magnetic dipole (MD), electric quadrupole (EQ), and magnetic quadrupole (MQ) modes."),
        ("Fig17", "Figure 13. Forward-to-backward scattering ratio (F/B) and asymmetry parameter g_asym versus wavelength. The peak asymmetry of g_asym = 0.954 far exceeds the analytical critical threshold g_crit = 0.650."),
        ("Fig20", "Figure 14. Multi-solver cross-validation. Quantitative comparison of predicted pulling force across FDTD (reference), Finite Element Method (FEM/COMSOL, 2.7% error), Coupled Dipole Approximation (CDA, 5.5% error), and direct Bessel-beam FDTD (1.1% discrepancy)."),
        ("Fig22", "Figure 15. Monte Carlo fabrication tolerance analysis across 100 disorder realizations. Histogram of calculated pulling forces under simultaneous five-parameter Gaussian disorder (mean -8.92 ± 1.18 pN/(W/μm²); 100% pulling retention)."),
        ("Fig24", "Figure 16. Circular dichroism as a robust optical predictor of optical pulling force. Linear regression between CD and pulling force across 90 Latin Hypercube configurations, establishing a high predictive correlation of R² = 0.947."),
        ("Fig27", "Figure 17. Integrated structure-property-function framework. Flowchart illustrating the rational progression from gold nanorod geometry to collective multipolar interference, momentum redistribution, and polarization-selective optical manipulation.")
    ]
    
    for fdir, fcaption in figures_list:
        fimg = os.path.join(work_dir, "figures", fdir, "figure.png")
        if os.path.exists(fimg):
            p_img = doc.add_paragraph()
            p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_img.paragraph_format.keep_with_next = True
            p_img.paragraph_format.space_before = Pt(12)
            p_img.paragraph_format.space_after = Pt(4)
            p_img.add_run().add_picture(fimg, width=Inches(5.0))
            
            p_cap = doc.add_paragraph()
            p_cap.paragraph_format.keep_with_next = False
            p_cap.paragraph_format.space_after = Pt(16)
            p_cap.paragraph_format.line_spacing = 1.15
            r_cap = p_cap.add_run(fcaption)
            r_cap.font.size = Pt(9.5)
            p_cap.paragraph_format.line_spacing = 1.1
            
    # References section
    p_ref_hd = doc.add_paragraph()
    r = p_ref_hd.add_run("REFERENCES")
    r.bold = True
    r.font.size = Pt(13)
    p_ref_hd.paragraph_format.space_before = Pt(20)
    p_ref_hd.paragraph_format.space_after = Pt(8)
    
    # Read references from 01_ACS_ANM_Manuscript.bbl
    bbl_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.bbl")
    if os.path.exists(bbl_path):
        with open(bbl_path, "r", encoding="utf-8") as f:
            bbl_text = f.read()
            
        # Parse \bibitem
        items = re.split(r'\\bibitem\[.*?\]\{[^}]+\}', bbl_text)[1:]
        for idx, item in enumerate(items):
            cleaned_ref = clean_latex_text(item)
            p_ref = doc.add_paragraph()
            r_num = p_ref.add_run(f"({idx+1}) ")
            r_num.bold = True
            r_num.font.size = Pt(9.5)
            r_txt = p_ref.add_run(cleaned_ref)
            r_txt.font.size = Pt(9.5)
            p_ref.paragraph_format.space_after = Pt(4)
            p_ref.paragraph_format.line_spacing = 1.1
            
    out_path = os.path.join(work_dir, "02_ACS_ANM_Manuscript.docx")
    doc.save(out_path)
    print(f"Saved {out_path} ({os.path.getsize(out_path)} bytes)")

if __name__ == "__main__":
    build_cover_letter_docx()
    build_manuscript_docx()
