import pypdf

reader = pypdf.PdfReader('03_ACS_ANM_Manuscript.pdf')
for i, page in enumerate(reader.pages):
    txt = page.extract_text() or ''
    if 'Monte Carlo' in txt or 'rejection' in txt or 'sampling' in txt or 'non-overlap' in txt:
        print(f"--- Page {i+1} ---")
        for line in txt.splitlines():
            if any(k in line.lower() for k in ['gaussian', 'gap', 'sample', 'reject', 'toleran', 'overlap']):
                print(line.encode('ascii', errors='backslashreplace').decode('ascii'))

print("\n--- Checking SI ---")
reader_si = pypdf.PdfReader('05_ACS_ANM_Supporting_Information.pdf')
for i, page in enumerate(reader_si.pages):
    txt = page.extract_text() or ''
    if 'Monte Carlo' in txt or 'rejection' in txt or 'sampling' in txt or 'non-overlap' in txt:
        print(f"--- SI Page {i+1} ---")
        for line in txt.splitlines():
            if any(k in line.lower() for k in ['gaussian', 'gap', 'sample', 'reject', 'toleran', 'overlap']):
                print(line.encode('ascii', errors='backslashreplace').decode('ascii'))
