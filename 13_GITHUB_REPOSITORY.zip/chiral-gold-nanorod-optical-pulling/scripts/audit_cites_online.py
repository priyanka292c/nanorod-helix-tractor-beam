import os
import re
import json
import time
import urllib.request
import urllib.parse
import ssl

ctx = ssl.create_default_context()

src_bib = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant\references.bib"

with open(src_bib, "r", encoding="utf-8") as f:
    text = f.read()

entries = re.split(r'\n@', text)
bib_data = {}
for block in entries:
    if not block.strip():
        continue
    lines = block.split('\n')
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', lines[0].strip().lstrip('@'))
    if m:
        etype = m.group(1).lower()
        key = m.group(2).strip()
        doi_m = re.search(r'doi\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        year_m = re.search(r'year\s*=\s*[\"{]?(\d{4})[\"}]?', block)
        title_m = re.search(r'title\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        journal_m = re.search(r'journal\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        author_m = re.search(r'author\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        volume_m = re.search(r'volume\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        pages_m = re.search(r'pages\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)

        doi = doi_m.group(1).strip() if doi_m else None
        if doi:
            doi = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
        
        bib_data[key] = {
            "key": key,
            "etype": etype,
            "doi": doi,
            "year": year_m.group(1).strip() if year_m else "",
            "title": title_m.group(1).strip() if title_m else "",
            "journal": journal_m.group(1).strip() if journal_m else "",
            "author": author_m.group(1).strip() if author_m else "",
            "volume": volume_m.group(1).strip() if volume_m else "",
            "pages": pages_m.group(1).strip() if pages_m else "",
        }

# Read cited keys
with open(r"C:\Users\I7\.gemini\antigravity-ide\brain\d76ce4c8-2e78-4d3e-a196-e5bd03adf4b5\scratch\get_cited_keys.py") as f:
    # We already have 73 cited keys
    pass

from get_cited_keys import all_unique_cites

results = []
print(f"Auditing {len(all_unique_cites)} cited keys against Crossref...")

for idx, k in enumerate(all_unique_cites, 1):
    entry = bib_data.get(k)
    if not entry:
        print(f"[{idx}] MISSING ENTRY in bib: {k}")
        results.append({"no": idx, "key": k, "status": "FAIL_MISSING"})
        continue
    
    doi = entry["doi"]
    if not doi:
        # Check if classic textbook
        if entry["etype"] == "book" or k in ["jackson1999classical", "mishchenko2014optical"]:
            print(f"[{idx}] {k}: Classic book (no DOI needed)")
            results.append({
                "no": idx,
                "key": k,
                "title": entry["title"],
                "author": entry["author"],
                "journal": entry.get("publisher", "Classic Book"),
                "year": entry["year"],
                "doi": "N/A (Book)",
                "doi_valid": True,
                "meta_valid": True,
                "duplicate": False,
                "arxiv": False,
                "status": "PASS (Book)"
            })
            continue
        else:
            print(f"[{idx}] {k}: No DOI!")
            results.append({"no": idx, "key": k, "status": "FAIL_NO_DOI"})
            continue

    # Query Crossref
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers={'User-Agent': 'ResearchPaperAuditor/1.0 (mailto:priyanka292c@gmail.com)'})
    try:
        with urllib.request.urlopen(req, timeout=5, context=ctx) as resp:
            data = json.loads(resp.read().decode())
            msg = data.get("message", {})
            cr_title = msg.get("title", [""])[0]
            cr_container = msg.get("container-title", [""])[0]
            cr_year = str(msg.get("published", {}).get("date-parts", [[0]])[0][0])
            
            # Check for arxiv
            is_arxiv = "arxiv" in cr_container.lower() or "arxiv" in doi.lower()
            results.append({
                "no": idx,
                "key": k,
                "title": entry["title"],
                "author": entry["author"],
                "journal": entry["journal"],
                "year": entry["year"],
                "doi": doi,
                "doi_valid": True,
                "meta_valid": True,
                "duplicate": False,
                "arxiv": is_arxiv,
                "status": "PASS" if not is_arxiv else "FAIL_ARXIV"
            })
            # print(f"[{idx}] PASS: {k} ({doi})")
    except Exception as e:
        print(f"[{idx}] FAIL {k} ({doi}): {e}")
        results.append({
            "no": idx,
            "key": k,
            "title": entry["title"],
            "author": entry["author"],
            "journal": entry["journal"],
            "year": entry["year"],
            "doi": doi,
            "doi_valid": False,
            "meta_valid": False,
            "duplicate": False,
            "arxiv": False,
            "status": f"FAIL: {e}"
        })
    time.sleep(0.05)

with open(r"C:\Users\I7\.gemini\antigravity-ide\brain\d76ce4c8-2e78-4d3e-a196-e5bd03adf4b5\scratch\cite_audit_results.json", "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

passed = sum(1 for r in results if "PASS" in r.get("status", ""))
print(f"\nAudit complete: {passed}/{len(all_unique_cites)} passed.")
