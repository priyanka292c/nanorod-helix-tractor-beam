import os
import subprocess
import shutil

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

pdflatex_exe = shutil.which("pdflatex")
bibtex_exe = shutil.which("bibtex")
print(f"pdflatex: {pdflatex_exe}")
print(f"bibtex: {bibtex_exe}")

def compile_doc(tex_name, run_bibtex=False):
    base_name = os.path.splitext(tex_name)[0]
    print(f"\n==========================================")
    print(f"Compiling {tex_name}...")
    print(f"==========================================")
    
    # Run 1: pdflatex
    res1 = subprocess.run([pdflatex_exe, "-interaction=nonstopmode", tex_name], cwd=work_dir, capture_output=True, text=True)
    print(f"Run 1 (pdflatex): exit code {res1.returncode}")
    
    if run_bibtex:
        # Run bibtex
        res_b = subprocess.run([bibtex_exe, base_name], cwd=work_dir, capture_output=True, text=True)
        print(f"BibTeX: exit code {res_b.returncode}")
        if res_b.returncode != 0:
            print("BibTeX error output:", res_b.stdout[-500:])
        
        # Run 2: pdflatex
        res2 = subprocess.run([pdflatex_exe, "-interaction=nonstopmode", tex_name], cwd=work_dir, capture_output=True, text=True)
        print(f"Run 2 (pdflatex): exit code {res2.returncode}")
        
    # Run 3: pdflatex
    res3 = subprocess.run([pdflatex_exe, "-interaction=nonstopmode", tex_name], cwd=work_dir, capture_output=True, text=True)
    print(f"Run 3 (pdflatex): exit code {res3.returncode}")
    
    pdf_path = os.path.join(work_dir, f"{base_name}.pdf")
    if os.path.exists(pdf_path):
        size = os.path.getsize(pdf_path)
        print(f"SUCCESS: {pdf_path} generated ({size} bytes)")
    else:
        print(f"FAILED: {pdf_path} not found!")
        # Print last 30 lines of log
        log_path = os.path.join(work_dir, f"{base_name}.log")
        if os.path.exists(log_path):
            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
            print("Tail of log file:")
            for l in lines[-30:]:
                print(l, end="")

# Compile main manuscript
compile_doc("01_ACS_ANM_Manuscript.tex", run_bibtex=True)

# Copy to 03_ACS_ANM_Manuscript.pdf
pdf_src = os.path.join(work_dir, "01_ACS_ANM_Manuscript.pdf")
pdf_dest = os.path.join(work_dir, "03_ACS_ANM_Manuscript.pdf")
if os.path.exists(pdf_src):
    shutil.copy(pdf_src, pdf_dest)
    print(f"Copied {pdf_src} -> {pdf_dest}")

# Compile SI
compile_doc("04_ACS_ANM_Supporting_Information.tex", run_bibtex=False)
si_src = os.path.join(work_dir, "04_ACS_ANM_Supporting_Information.pdf")
si_dest = os.path.join(work_dir, "05_ACS_ANM_Supporting_Information.pdf")
if os.path.exists(si_src):
    shutil.copy(si_src, si_dest)
    print(f"Copied {si_src} -> {si_dest}")

# Compile Cover letter
compile_doc("cover_letter.tex", run_bibtex=False)
cl_src = os.path.join(work_dir, "cover_letter.pdf")
cl_dest = os.path.join(work_dir, "07_ACS_ANM_Cover_Letter.pdf")
if os.path.exists(cl_src):
    shutil.copy(cl_src, cl_dest)
    print(f"Copied {cl_src} -> {cl_dest}")

