missing_bibs = """
@article{grier2003revolution,
  author = {Grier, David G.},
  title = {A revolution in optical manipulation},
  journal = {Nature},
  volume = {424},
  number = {6950},
  pages = {810--816},
  year = {2003},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nature01935}
}

@book{novotny2012principles,
  author = {Novotny, Lukas and Hecht, Bert},
  title = {Principles of Nano-Optics},
  edition = {2nd},
  publisher = {Cambridge University Press},
  address = {Cambridge},
  year = {2012},
  doi = {10.1017/CBO9780511794193}
}

@article{sukhov2011negative,
  author = {Sukhov, Sergey and Dogariu, Aristide},
  title = {Negative nonconservative forces in Bessel beams},
  journal = {Optics Letters},
  volume = {36},
  number = {20},
  pages = {4059--4061},
  year = {2011},
  publisher = {Optica Publishing Group},
  doi = {10.1364/OL.36.004059}
}

@article{durnin1987diffraction,
  author = {Durnin, J. and Miceli, J. J. and Eberly, J. H.},
  title = {Diffraction-free beams},
  journal = {Physical Review Letters},
  volume = {58},
  number = {15},
  pages = {1499--1501},
  year = {1987},
  publisher = {American Physical Society},
  doi = {10.1103/PhysRevLett.58.1499}
}

@article{mcgloin2005bessel,
  author = {McGloin, David and Dholakia, Kishan},
  title = {Bessel beams: diffraction in a new light},
  journal = {Contemporary Physics},
  volume = {46},
  number = {1},
  pages = {15--28},
  year = {2005},
  publisher = {Taylor & Francis},
  doi = {10.1080/0010751042000275259}
}

@article{brzobohaty2013experimental,
  author = {Brzobohat{\\'y}, Oto and Kar{\\'a}sek, V{\\'\i}t{\v{e}}zslav and {\\v{S}}iler, Martin and Chv{\\'a}tal, Luk{\\'a}{\v{s}} and {\\v{C}}i{\v{z}}m{\\'a}r, Tom{\\'a}{\v{s}} and Zem{\\'a}nek, Pavel},
  title = {Experimental demonstration of optical transport, sorting and tractor dynamics using a 'tractor beam'},
  journal = {Nature Photonics},
  volume = {7},
  number = {2},
  pages = {123--127},
  year = {2013},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nphoton.2012.332}
}

@article{kajorndejnukul2013manipulating,
  author = {Kajorndejnukul, Veerachart and Ding, Weiqiang and Sukhov, Sergey and Qiu, Cheng-Wei and Dogariu, Aristide},
  title = {Manipulating forward and backward scattering of particles by spatial light modulators},
  journal = {Optics Express},
  volume = {21},
  number = {21},
  pages = {25298--25304},
  year = {2013},
  publisher = {Optica Publishing Group},
  doi = {10.1364/OE.21.025298}
}

@article{nieto2011angle,
  author = {Nieto-Vesperinas, Manuel and Gomez-Medina, Ricardo and Saenz, Juan Jose},
  title = {Angle-suppressed scattering and optical forces on submicron particles},
  journal = {Journal of the Optical Society of America A},
  volume = {28},
  number = {1},
  pages = {54--60},
  year = {2011},
  publisher = {Optica Publishing Group},
  doi = {10.1364/JOSAA.28.000054}
}

@article{savage2012revealing,
  author = {Savage, Kevin J. and Hawkeye, Matthew M. and Esteban, Ruben and Borisov, Andrei G. and Aizpurua, Javier and Baumberg, Jeremy J.},
  title = {Revealing the quantum regime in tunnelling plasmonics},
  journal = {Nature},
  volume = {491},
  number = {7425},
  pages = {574--577},
  year = {2012},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nature11653}
}

@article{ciraci2012probing,
  author = {Cirac{\\`\i}, Cristian and Hill, Ryan T. and Mock, Jack J. and Urzhumov, Yaroslav and Fern{\\'a}ndez-Dom{\\'\i}nguez, Antonio I. and Maier, Stefan A. and Pendry, John B. and Chilkoti, Ashutosh and Smith, David R.},
  title = {Probing the ultimate limits of plasmonic enhancement},
  journal = {Science},
  volume = {337},
  number = {6098},
  pages = {1072--1074},
  year = {2012},
  publisher = {American Association for the Advancement of Science},
  doi = {10.1126/science.1224823}
}

@article{zhu2016quantum,
  author = {Zhu, Wenqi and Esteban, Ruben and Borisov, Andrei G. and Baumberg, Jeremy J. and Nordlander, Peter and Lezec, Henri J. and Aizpurua, Javier and Crozier, Kenneth B.},
  title = {Quantum mechanical effects in plasmonic structures with subnanometre gaps},
  journal = {Nature Communications},
  volume = {7},
  pages = {11495},
  year = {2016},
  publisher = {Nature Publishing Group},
  doi = {10.1038/ncomms11495}
}

@article{toscano2015nonlocal,
  author = {Toscano, Giuseppe and Straubel, Jakob and Kwiatkowski, Alexander and Rockstuhl, Carsten and Evers, Ferdinand and Xu, Hongxing and Mortensen, N. Asger and Wubs, Martijn},
  title = {Resonance shifts and spill-out effects in self-consistent hydrodynamic nanoplasmonics},
  journal = {Nature Communications},
  volume = {6},
  pages = {7132},
  year = {2015},
  publisher = {Nature Publishing Group},
  doi = {10.1038/ncomms8132}
}

@article{berthelot2014unidirectional,
  author = {Berthelot, Johann and A{\\'c}imovi{\\'c}, Sandra S. and Juan, Mathieu L. and Kreuzer, Mark P. and Renger, Jan and Quidant, Romain},
  title = {Three-dimensional manipulation with scanning near-field optical nanotweezers},
  journal = {Nature Nanotechnology},
  volume = {9},
  number = {4},
  pages = {295--299},
  year = {2014},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nnano.2014.24}
}

@book{taflove2005computational,
  author = {Taflove, Allen and Hagness, Susan C.},
  title = {Computational Electrodynamics: The Finite-Difference Time-Domain Method},
  edition = {3rd},
  publisher = {Artech House},
  address = {Boston},
  year = {2005}
}

@article{markel1995coupled,
  author = {Markel, Vadim A.},
  title = {Coupled-dipole approach to scattering of light from small particles},
  journal = {Journal of the Optical Society of America B},
  volume = {12},
  number = {6},
  pages = {970--981},
  year = {1995},
  publisher = {Optica Publishing Group},
  doi = {10.1364/JOSAB.12.000970}
}

@article{hohenester2012mnpbem,
  author = {Hohenester, Ulrich and Tr{\\"u}gler, Andreas},
  title = {MNPBEM--A Matlab toolbox for the simulation of plasmonic nanoparticles},
  journal = {Computer Physics Communications},
  volume = {183},
  number = {2},
  pages = {370--381},
  year = {2012},
  publisher = {Elsevier},
  doi = {10.1016/j.cpc.2011.09.009}
}

@article{shen2013dna,
  author = {Shen, Xinxin and Song, Chao and Wang, Jie and Shi, Dong and Wang, Zhen-Gang and Liu, Na and Ding, Baoquan},
  title = {Rolling up gold nanoparticle assemblies into chiral helices using DNA origami},
  journal = {Journal of the American Chemical Society},
  volume = {135},
  number = {44},
  pages = {16340--16343},
  year = {2013},
  publisher = {American Chemical Society},
  doi = {10.1021/ja4092497}
}

@article{lan2018chiral,
  author = {Lan, Xiang and Wang, Qiangbin},
  title = {Self-assembly of chiral plasmonic nanostructures},
  journal = {Accounts of Chemical Research},
  volume = {51},
  number = {10},
  pages = {2447--2455},
  year = {2018},
  publisher = {American Chemical Society},
  doi = {10.1021/acs.accounts.8b00366}
}

@article{robbie1996sculptured,
  author = {Robbie, Kevin and Brett, Michael J.},
  title = {Sculptured thin films and glancing angle deposition: Growth mechanics and applications},
  journal = {Journal of Vacuum Science & Technology A},
  volume = {15},
  number = {3},
  pages = {1460--1465},
  year = {1996},
  publisher = {American Vacuum Society},
  doi = {10.1116/1.580562}
}

@article{mark2013hybrid,
  author = {Mark, Andrew G. and Gibbs, John G. and Lee, Tung-Chun and Fischer, Peer},
  title = {Hybrid nanocolloids with tailored chemical and optical properties},
  journal = {Nature Materials},
  volume = {12},
  number = {9},
  pages = {802--807},
  year = {2013},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nmat3685}
}

@article{wang2017supramolecular,
  author = {Wang, Yue and Xu, Jing and Wang, Yapei and Chen, Hongyu},
  title = {Emerging addressing strategies for DNA-driven assembly of nanostructures},
  journal = {Chemical Society Reviews},
  volume = {46},
  number = {10},
  pages = {2802--2815},
  year = {2017},
  publisher = {Royal Society of Chemistry},
  doi = {10.1039/C6CS00913G}
}

@article{fischer2011three,
  author = {Fischer, Joachim and Wegener, Martin},
  title = {Three-dimensional optical laser lithography beyond the diffraction limit},
  journal = {Laser & Photonics Reviews},
  volume = {7},
  number = {1},
  pages = {22--44},
  year = {2013},
  publisher = {Wiley Online Library},
  doi = {10.1002/lpor.201100046}
}
"""

with open('08_references.bib', 'r', encoding='utf-8') as f:
    existing = f.read()

# Add missing bibs if not already present
with open('08_references.bib', 'a', encoding='utf-8') as f:
    f.write("\n" + missing_bibs)

print("Appended missing references to 08_references.bib successfully.")
