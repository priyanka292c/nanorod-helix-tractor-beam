import os

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
si_path = os.path.join(work_dir, "04_ACS_ANM_Supporting_Information.tex")

with open(si_path, "r", encoding="utf-8") as f:
    text = f.read()

# 1. Fix Section S7 title
text = text.replace(
    r"\section{Section S7: Boundary Element Method (BEM / MATLAB) Implementation}",
    r"\section{Section S7: Boundary Element Method (BEM) Implementation}"
)

# 2. Fix eq reference in line 126
text = text.replace(
    r"(Eq.~\ref{eq:bessel_discrete})",
    r"(via discrete azimuthal plane-wave decomposition)"
)

# 3. Fix citations if needed: remove \cite{scholl2012quantum, zuloaga2009quantum} or add bib
text = text.replace(
    r"\cite{scholl2012quantum, zuloaga2009quantum}",
    r""
)

# 4. Wrap Tables S1, S2, S3 with \resizebox{\columnwidth}{!}{...} and \small\singlespacing
text = text.replace(
    r"""\begin{table}[htbp]
\centering
\caption{\textbf{Table S1.} Detailed Cartesian Multipole Cross Sections at Operating Resonance ($\lambda_0 = 1060$ nm).}
\begin{tabular}{lccc}""",
    r"""\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{\textbf{Table S1.} Detailed Cartesian Multipole Cross Sections at Operating Resonance ($\lambda_0 = 1060$ nm).}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}"""
)

text = text.replace(
    r"""\begin{table}[htbp]
\centering
\caption{\textbf{Table S2.} Inter-Rod Gap Robustness Analysis ($g = 1.0$ to $4.0$ nm).}
\begin{tabular}{ccccc}""",
    r"""\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{\textbf{Table S2.} Inter-Rod Gap Robustness Analysis ($g = 1.0$ to $4.0$ nm).}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{ccccc}"""
)

text = text.replace(
    r"""\begin{table}[htbp]
\centering
\caption{\textbf{Table S3.} Computational Specifications and Run Times Across Numerical Solvers.}
\begin{tabular}{lcccc}""",
    r"""\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{\textbf{Table S3.} Computational Specifications and Run Times Across Numerical Solvers.}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccc}"""
)

# And close the resizebox in each table:
text = text.replace(
    r"""\bottomrule
\end{tabular}
\end{table}""",
    r"""\bottomrule
\end{tabular}%
}
\end{table}"""
)

# 5. Fix figure widths in Section S15
import re
text = re.sub(
    r'\\begin\{figure\}\[htbp\]\s*\\centering\s*\\includegraphics\[[^\]]+\]\{([^}]+)\}\s*\\caption\{([^}]+)\}\s*\\end\{figure\}',
    r"""\\begin{figure}[!htbp]
\\centering
\\includegraphics[width=0.68\\textwidth,height=0.36\\textheight,keepaspectratio]{\1}
{\\singlespacing
\\caption{\2}
}
\\end{figure}""",
    text
)

with open(si_path, "w", encoding="utf-8") as f:
    f.write(text)

print("Updated 04_ACS_ANM_Supporting_Information.tex successfully.")
