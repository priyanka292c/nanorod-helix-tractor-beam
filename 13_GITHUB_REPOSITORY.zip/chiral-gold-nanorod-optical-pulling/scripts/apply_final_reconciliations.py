import os

# ==============================================================================
# 1. GENERATE FINAL RECONCILED 01_ACS_ANM_Manuscript.tex
# ==============================================================================
main_tex = r"""\documentclass[journal=aamick,manuscript=article]{achemso}

\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{siunitx}
\usepackage{bm}
\usepackage{xcolor}
\usepackage{array}
\usepackage{longtable}
\usepackage{multirow}
\usepackage{setspace}
\usepackage{geometry}
\geometry{letterpaper, margin=1in}

\usepackage[
 colorlinks=true,
 linkcolor=blue,
 citecolor=blue,
 urlcolor=blue
]{hyperref}

% Canonical Author Metadata from authors.yaml
\title{Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference}

\author{Priyanka}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{priyanka292c@gmail.com}

\author{Ram Soorat}
\affiliation{School of Technology, Woxsen University, Hyderabad, Telangana 502345, India}
\email{rsoorat@gmail.com}
\phone{+91-40-2345-6789}

\author{Rajveer Singh}
\affiliation{Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India}
\email{rajveersingh@arsd.du.ac.in}

\author{Narender Kumar}
\affiliation{Department of Physics, Sri Venkateswara College, Benito Juarez Road, Dhaula Kuan, New Delhi 110021, India}

\author{Sandeep}
\affiliation{Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India}

\keywords{optical pulling forces, tractor beams, chiral plasmonics, gold nanorods, multipolar interference, forward scattering, Bessel beams, circular dichroism}

\begin{document}

\begin{abstract}
Optical pulling forces---the backward dragging of matter against incident photon momentum flux---remain challenging to achieve in lossy plasmonic nanomaterials due to intrinsic absorption-induced forward radiation pressure. Here, we demonstrate that a chiral gold nanorod (AuNR) helical superstructure immersed in water generates strong, polarization-selective optical pulling under non-paraxial left-circularly polarized (LCP) Bessel beam illumination ($\theta_0 = 49.5^\circ$). Arranging ten Au nanorods ($L = 60$~nm, $D = 15$~nm) into a tapered-chirped hybrid helix drives near-in-phase co-excitation of electric dipole, magnetic dipole, and electric quadrupole moments ($\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$, $\Delta\Phi_{\mathrm{ED-EQ}} \approx 18^\circ$). This generalized multipolar interference suppresses backward scattering, elevating the forward-scattering asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, well above the absorption-corrected threshold $g_{\mathrm{crit,abs}} = 0.721$. Full-wave finite-difference time-domain (FDTD) simulations yield a peak optical pulling force of $F_z = -10.50$~pN/(W/$\mu$m$^2$) at $\lambda_0 = 1060$~nm across a continuous 285-nm negative-force band ($\lambda = 875$--$1160$~nm). Switching to right-circular polarization (RCP) reverses the momentum balance into forward pushing ($F_z = +1.15$~pN/(W/$\mu$m$^2$)), providing polarity-reversible optical pulling ($C_{\mathrm{chiral}} = 1.00$). The mechanism is cross-validated using finite element methods (FEM, 2.7\% discrepancy), coupled dipole approximations (CDA, 5.5\%), and boundary element scattering calculations (BEM, 3.8\% in far-field asymmetry), offering foundational guidelines for chiral optomechanical manipulation.
\end{abstract}

\section{Introduction}

The mechanical manipulation of nanoscale matter via optical radiation pressure has revolutionized colloidal physics, biophysics, and nanophotonics since the pioneering work of Ashkin \cite{ashkin1970acceleration, ashkin1986observation, grier2003revolution}. Conventional optical tweezers rely on tightly focused Gaussian beams to trap dielectric or metallic particles at the intensity gradient maximum, where the forward scattering and absorption force (Poynting momentum transfer) is balanced by transverse gradient forces \cite{marago2013optical, novotny2012principles}. In contrast, ``optical pulling forces''---popularly termed optical tractor beams---represent a distinct physical regime in which a particle experiences a continuous longitudinal force directed \emph{backward} toward the light source, opposing the incident wave propagation vector ($\mathbf{k} \cdot \hat{\mathbf{z}} > 0$ while $\mathbf{F} \cdot \hat{\mathbf{z}} < 0$) \cite{chen2011optical, novitsky2011single, sukhov2011negative}.

Realizing optical pulling requires asymmetric momentum redistribution, wherein forward-scattered photons carry greater average longitudinal momentum per photon than the incident beam \cite{chen2011optical, novitsky2011single}. To satisfy conservation of linear momentum, the illuminated object must recoil backward. This backward recoil condition typically demands two structural prerequisites: (i) non-paraxial structured illumination (such as non-diffracting Bessel beams or intersecting plane waves) having an axial wavevector component smaller than the total wavevector ($k_z = k_0 \cos\theta_0 < k_0$) \cite{durnin1987diffraction, mcgloin2005bessel}, and (ii) a scattering object engineered to exhibit high forward-scattering directivity, characterized by an asymmetry parameter $g_{\mathrm{asym}} = \langle \cos\theta \rangle > \cos\theta_0$ \cite{sukhov2011negative, dogariu2013optically}.

While optical pulling has been theoretically explored and experimentally demonstrated in low-loss dielectric spheres, core-shell colloids, and gain media \cite{chen2011optical, novitsky2011single, brzobohaty2013experimental, kajorndejnukul2013manipulating}, metallic plasmonic nanomaterials face an intrinsic absorption-induced limitation \cite{wang2014optimized, myroshnychenko2008modelling}. Noble metals such as gold exhibit significant imaginary permittivity ($\epsilon_2 > 0$) in the visible and near-infrared regimes due to interband transitions and Drude ohmic losses \cite{johnson1972optical}. Absorption transfers incident photon momentum directly to the object as a mandatory forward pushing force ($F_{\mathrm{abs}} = \sigma_{\mathrm{abs}} \langle S_z \rangle / c > 0$). To achieve net optical pulling ($F_z < 0$), the collective forward-scattering recoil must not only exceed the incident scattering momentum flux, but must also overcome this intrinsic absorption-induced forward push. For isolated spherical gold nanoparticles, the electric dipole mode dominates scattering symmetrically, giving modest forward asymmetry ($g_{\mathrm{asym}} < 0.3$) that cannot overcome absorption, resulting in strictly positive radiation pressure \cite{bohren2008absorption}.

In this work, we demonstrate that this absorption-induced limitation can be overcome by exploiting collective plasmonic hybridization in chiral gold nanorod (AuNR) helical superstructures. By assembling ten high-aspect-ratio Au nanorods into a tapered-chirped hybrid helix (RH-TCH-CPH) illuminated by a non-paraxial left-circularly polarized (LCP) Bessel beam ($\theta_0 = 49.5^\circ$), collective near-field coupling excites overlapping electric dipole, magnetic dipole, and electric quadrupole moments. Interference among these multipoles suppresses backward radiation via a generalized multipolar interference mechanism (analogous to the Kerker effect in dielectric particles) \cite{kerker1983electromagnetic, liu2018generalized, nieto2011angle}, elevating the forward-scattering asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, well above the critical threshold $g_{\mathrm{crit}} = 0.650$ (and absorption-corrected threshold $g_{\mathrm{crit,abs}} = 0.721$). Full-wave electrodynamic simulations yield a peak optical pulling force of $F_z = -10.50$~pN/(W/$\mu$m$^2$) at $\lambda_0 = 1060$~nm, operating across a continuous negative-force band of 285~nm ($\lambda = 875$--$1160$~nm). Switching the incident handedness to right-circular polarization (RCP) turns the pulling force into forward pushing ($F_z = +1.15$~pN/(W/$\mu$m$^2$)), providing polarity-reversible optical pulling ($C_{\mathrm{chiral}} = 1.00$).

\section{Physical Concept and Design Strategy}

\subsection{Optical Pulling Physics and Momentum Conservation}

Consider an arbitrary particulate scatterer illuminated by a monochromatic optical beam propagating along the $+z$-axis in an ambient dielectric medium with refractive index $n_m$. The time-averaged longitudinal optical force $F_z$ exerted on the structure can be evaluated rigorously by integrating the Maxwell stress tensor (MST) over a closed surface $\partial\Omega$ enclosing the object in the far field \cite{novotny2012principles, jackson1999classical}:
\begin{equation}
F_z = \oint_{\partial\Omega} \langle \mathbf{T} \rangle \cdot \hat{\mathbf{z}} \, dA,
\label{eq:mst}
\end{equation}
where $\langle \mathbf{T} \rangle = \frac{1}{2} \operatorname{Re}\left[ \epsilon_0 \epsilon_m \mathbf{E} \otimes \mathbf{E}^* + \mu_0 \mathbf{H} \otimes \mathbf{H}^* - \frac{1}{2}\left( \epsilon_0 \epsilon_m |\mathbf{E}|^2 + \mu_0 |\mathbf{H}|^2 \right) \mathbf{I} \right]$ is the time-averaged Maxwell stress tensor, and $\mathbf{I}$ is the identity tensor.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig01/figure.png}
\caption{Overall conceptual architecture and optical-pulling mechanism. (a) Schematic of a right-handed 10-nanorod Au helix under non-paraxial LCP Bessel illumination ($\theta_0 = 49.5^\circ$). (b) Longitudinal optical force spectrum $F_z(\lambda)$ comparing FDTD baseline ($-10.50$~pN/(W/$\mu$m$^2$) at $\lambda_0 = 1060$~nm) against forward-scattering asymmetry parameter $g_{\mathrm{asym}}(\lambda)$ and critical threshold $g_{\mathrm{crit}} = 0.650$. The negative force interval spans a continuous 285-nm bandwidth ($\lambda = 875$--$1160$~nm).}
\label{fig:concept}
\end{figure}

Applying momentum conservation to the electromagnetic field, the longitudinal force can be decomposed into extinction and scattering momentum flux components \cite{chen2011optical, novitsky2011single}:
\begin{equation}
F_z = \frac{n_m I_0}{c} \left[ \sigma_{\mathrm{ext}} \cos\theta_0 - \sigma_{\mathrm{sca}} g_{\mathrm{asym}} \right],
\label{eq:force_balance}
\end{equation}
where $I_0$ is the incident beam intensity, $c$ is the speed of light in vacuum, $\theta_0$ is the characteristic half-cone angle of the incident Bessel beam, $\sigma_{\mathrm{ext}} = \sigma_{\mathrm{sca}} + \sigma_{\mathrm{abs}}$ is the extinction cross section, $\sigma_{\mathrm{sca}}$ is the total scattering cross section, $\sigma_{\mathrm{abs}}$ is the absorption cross section, and $g_{\mathrm{asym}}$ is the forward-scattering asymmetry parameter:
\begin{equation}
g_{\mathrm{asym}} = \langle \cos\theta \rangle = \frac{1}{\sigma_{\mathrm{sca}}} \int_{4\pi} \frac{d\sigma_{\mathrm{sca}}}{d\Omega} \cos\theta \, d\Omega,
\label{eq:gasym}
\end{equation}
with $\theta$ being the scattering polar angle measured from the $+z$ forward axis.

Setting $F_z < 0$ in eq~\ref{eq:force_balance} yields the necessary and sufficient condition for optical pulling:
\begin{equation}
g_{\mathrm{asym}} > \frac{\sigma_{\mathrm{ext}}}{\sigma_{\mathrm{sca}}} \cos\theta_0 = \left( 1 + \frac{\sigma_{\mathrm{abs}}}{\sigma_{\mathrm{sca}}} \right) \cos\theta_0 \equiv g_{\mathrm{crit,abs}}.
\label{eq:pulling_criterion}
\end{equation}
In a hypothetical lossless scatterer ($\sigma_{\mathrm{abs}} = 0$), eq~\ref{eq:pulling_criterion} reduces to the geometric threshold $g_{\mathrm{crit,geom}} = \cos\theta_0$. For a plane wave ($\theta_0 = 0^\circ$), $\cos\theta_0 = 1$, requiring $g_{\mathrm{asym}} > 1$, which is physically impossible for passive scatterers since $|\cos\theta| \le 1$. Hence, optical pulling of passive particles is strictly forbidden under single plane-wave illumination \cite{chen2011optical}. 

In lossy plasmonic nanoparticles ($\sigma_{\mathrm{abs}} > 0$), the ratio $\sigma_{\mathrm{abs}}/\sigma_{\mathrm{sca}}$ further elevates the threshold from $g_{\mathrm{crit,geom}}$ to $g_{\mathrm{crit,abs}}$. For the 10-nanorod Au helix at $\lambda_0 = 1060$~nm, our numerical simulations establish $\sigma_{\mathrm{abs}} / \sigma_{\mathrm{sca}} \approx 0.109$. With an incident Bessel cone angle $\theta_0 = 49.5^\circ$ ($\cos\theta_0 = 0.650$), the absorption-corrected pulling threshold becomes:
\begin{equation}
g_{\mathrm{crit,abs}} = (1 + 0.109) \times 0.650 = 0.721.
\end{equation}
As demonstrated in Figure~\ref{fig:concept}, our engineered chiral superstructure achieves $g_{\mathrm{asym}} = 0.954$, substantially exceeding both $g_{\mathrm{crit,geom}} = 0.650$ and $g_{\mathrm{crit,abs}} = 0.721$, thereby satisfying the pulling criterion despite significant ohmic dissipation. The operational beam and material parameters are summarized in Table~\ref{tab:opt_params}.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Material and Optical Beam Parameters at Operating Resonance ($\lambda_0 = 1060$~nm).}
\label{tab:opt_params}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} \\
\midrule
Operating Wavelength & $\lambda_0$ & 1060 & nm \\
Incident Intensity & $I_0$ & 1.0 & W/$\mu$m$^2$ \\
Bessel Half-Cone Angle & $\theta_0$ & 49.5 & degrees \\
Cone Angle Cosine & $\cos\theta_0$ & 0.650 & dimensionless \\
Ambient Medium Index (Water) & $n_m$ & 1.333 & dimensionless \\
Gold Permittivity (Real) & $\epsilon_1$ & $-48.50$ & dimensionless \\
Gold Permittivity (Imaginary) & $\epsilon_2$ & $+3.85$ & dimensionless \\
Scattering Asymmetry Parameter & $g_{\mathrm{asym}}$ & 0.954 & dimensionless \\
Geometric Pulling Threshold & $g_{\mathrm{crit,geom}}$ & 0.650 & dimensionless \\
Absorption-Corrected Threshold & $g_{\mathrm{crit,abs}}$ & 0.721 & dimensionless \\
Peak Longitudinal Force & $F_z$ & $-10.50$ & pN/(W/$\mu$m$^2$) \\
Radiation Pressure Efficiency & $Q_{\mathrm{pr}}$ & $-0.712$ & dimensionless \\
Negative Force Bandwidth & $\Delta\lambda$ & 285 & nm \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Bessel-Beam Angular Spectrum and Longitudinal Momentum Deficit}

To supply the required momentum deficit, we utilize a circularly polarized zeroth-order non-diffracting Bessel beam \cite{durnin1987diffraction}. The electric field of an ideal vector Bessel beam propagating along $+z$ can be expressed via an angular spectrum representation (ASR) over an azimuthal cone of plane waves \cite{novotny2012principles}:
\begin{equation}
\mathbf{E}_{\mathrm{inc}}(\mathbf{r}) = \frac{1}{2\pi} \int_0^{2\pi} \mathbf{E}_0(\phi) e^{i \mathbf{k}(\phi) \cdot \mathbf{r}} \, d\phi,
\label{eq:bessel_asr}
\end{equation}
where the wavevector components are constrained to a conical surface:
\begin{equation}
\mathbf{k}(\phi) = k_0 n_m \left( \sin\theta_0 \cos\phi \, \hat{\mathbf{x}} + \sin\theta_0 \sin\phi \, \hat{\mathbf{y}} + \cos\theta_0 \, \hat{\mathbf{z}} \right).
\end{equation}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig04/figure.png}
\caption{Bessel beam geometry and angular spectrum decomposition. Longitudinal wavevector component $k_z/k = \cos\theta_0 = 0.650$ under cone angle $\theta_0 = 49.5^\circ$, illustrating the incident longitudinal momentum deficit that enables backward recoil.}
\label{fig:bessel}
\end{figure}

As shown in Figure~\ref{fig:bessel}, each constituent plane wave carries a reduced longitudinal momentum component $\hbar k_z = \hbar k_0 n_m \cos\theta_0$. For $\theta_0 = 49.5^\circ$, $\cos\theta_0 = 0.650$, meaning each incident photon contributes only 65.0\% of its total momentum in the forward $+z$-direction. When the chiral AuNR superstructure scatters photons preferentially into the forward paraxial cone ($\theta \to 0^\circ$), where $k_z \to k_0 n_m$, the scattered photons carry higher axial momentum per photon than the incident photons. By global momentum conservation, the structure recoils backward toward the source ($F_z < 0$).

\section{Nanomaterial Geometry and Material Model}

\subsection{Gold Nanorod Dimensions and Helical Architecture}

The engineered superstructure consists of $N = 10$ gold nanorods arranged in a right-handed tapered-chirped helix (Figure~\ref{fig:helix_geom}). Each individual rod has length $L = 60$~nm and diameter $D = 15$~nm (aspect ratio $L/D = 4$), with hemispherical end-caps of radius $R_{\mathrm{cap}} = 7.5$~nm. The center-of-mass coordinates $(x_i, y_i, z_i)$ of the $i$-th nanorod ($i = 1, \dots, N$) are parameterized by:
\begin{equation}
x_i = r(z_i) \cos\phi_i, \quad y_i = r(z_i) \sin\phi_i, \quad z_i = z_0 + (i-1)\Delta z_i,
\label{eq:helix_pos}
\end{equation}
where $\phi_i = (i-1)\Delta\phi$ is the azimuthal angle with angular step $\Delta\phi = 45^\circ$, providing an aggregate azimuthal span of $\Phi_{\mathrm{tot}} = 405^\circ$ (1.125 helical turns).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig02/figure.png}
\caption{3D trajectory and taper envelope of the chiral Au nanorod helical assembly. Parametric center-of-mass coordinates $x(z)$ and $y(z)$ together with the radial taper envelope $r(z)$ expanding from $r_1 = 20$~nm to $r_{10} = 30$~nm along the axial span $z \in [-60, +60]$~nm.}
\label{fig:helix_geom}
\end{figure}

To prevent narrow-band localized resonances and promote collective broadband coupling, we introduce a dual spatial taper:
\begin{enumerate}
\item \textbf{Radial Taper:} The helix radius expands linearly along the axis:
\begin{equation}
r(z) = r_{\mathrm{start}} + \frac{r_{\mathrm{end}} - r_{\mathrm{start}}}{z_{\mathrm{max}} - z_{\mathrm{min}}} (z - z_{\mathrm{min}}),
\end{equation}
with $r_{\mathrm{start}} = 20$~nm at the upstream entry face ($z = -60$~nm) and $r_{\mathrm{end}} = 30$~nm at the downstream exit face ($z = +60$~nm).
\item \textbf{Axial Pitch Chirp:} The pitch increases along $z$:
\begin{equation}
P(z) = P_0 + \kappa_{\mathrm{chirp}} z,
\end{equation}
with $P_0 = 100$~nm and chirp parameter $\kappa_{\mathrm{chirp}} = 0.25$, yielding an axial inter-rod spacing $\Delta z_i$ that expands from $10.5$~nm to $13.5$~nm.
\end{enumerate}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig03/figure.png}
\caption{Coordinate system and geometric parameters. Canonical definitions of the 10-nanorod assembly, depicting individual rod length $L = 60$~nm, diameter $D = 15$~nm, surface-to-surface gap $g = 2.0$~nm, and local tilt angle $\theta_{\mathrm{tilt}} = 45^\circ$.}
\label{fig:coords}
\end{figure}

The orientation of each nanorod is specified by aligning its long axis tangential to the local helical curve with a uniform tilt angle $\theta_{\mathrm{tilt}} = 45^\circ$ relative to the $z$-axis (Figure~\ref{fig:coords}). The edge-to-edge inter-rod gap is set to $g = 2.0$~nm, establishing strong capacitive near-field coupling while remaining in the domain of classical electrodynamics. Canonical geometrical parameters are compiled in Table~\ref{tab:geom}.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Canonical Geometrical Parameters of Chiral Gold Nanorod Helical Superstructures.}
\label{tab:geom}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} \\
\midrule
Number of Nanorods & $N$ & 10 & integer \\
Nanorod Length & $L$ & 60 & nm \\
Nanorod Diameter & $D$ & 15 & nm \\
Nanorod Aspect Ratio & $L/D$ & 4.0 & dimensionless \\
End-Cap Curvature Radius & $R_{\mathrm{cap}}$ & 7.5 & nm \\
Initial Helix Radius & $r_{\mathrm{start}}$ & 20 & nm \\
Final Helix Radius & $r_{\mathrm{end}}$ & 30 & nm \\
Base Helix Pitch & $P_0$ & 100 & nm \\
Pitch Chirp Parameter & $\kappa_{\mathrm{chirp}}$ & 0.25 & dimensionless \\
Azimuthal Rotation Step & $\Delta\phi$ & 45.0 & degrees \\
Total Azimuthal Angle & $\Phi_{\mathrm{tot}}$ & 405.0 & degrees (1.125 turns) \\
Nanorod Tilt Angle & $\theta_{\mathrm{tilt}}$ & 45.0 & degrees \\
Inter-Rod Surface Gap & $g$ & 2.0 & nm \\
Total Axial Length & $L_z$ & 120 & nm \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Physical Validity of the 2.0-nm Gap Regime}

In plasmonic assemblies with nanoscale gaps, classical local electrodynamics can face limitations if quantum mechanical electron tunneling or nonlocal hydrodynamic screening becomes pronounced \cite{savage2012revealing, ciraci2012probing}. Electron tunneling across metal junctions requires wave-function overlap, which typically manifests only at sub-nanometer separations ($g < 0.5$~nm) \cite{savage2012revealing, zhu2016quantum}. For the 2.0-nm gaps considered here, we adopt the local classical model; the resulting force is expected to be substantially less sensitive to quantum tunneling than sub-nanometer gaps. Furthermore, hydrodynamic nonlocal screening studies on noble metal nanostructures establish that nonlocal blueshifts and field spillover effects account for $<3\%$ spectral shifts and $<4\%$ field revision when gaps exceed $1.5$~nm \cite{ciraci2012probing, toscano2015nonlocal}. Consequently, standard local Maxwell electrodynamics with sub-nanometer spatial meshing ($\Delta x = 0.5$~nm) provides high quantitative accuracy for the 2.0-nm gap architecture investigated here.

\subsection{Dielectric Function Model and Size-Dependent Surface Damping}

The complex relative permittivity of gold is parameterized using the empirical data of Johnson and Christy \cite{johnson1972optical}, interpolated with cubic splines across the $\lambda = 600$--$1400$~nm spectrum. At the operating wavelength $\lambda_0 = 1060$~nm, the bulk permittivity is $\epsilon_{\mathrm{Au}} = -48.50 + 3.85i$ (Figure~\ref{fig:permittivity}).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig05/figure.png}
\caption{Gold dielectric permittivity across the 600--1400~nm spectrum. Real ($\epsilon_1$) and imaginary ($\epsilon_2$) permittivity from Johnson and Christy empirical data. At $\lambda_0 = 1060$~nm, $\epsilon_{\mathrm{Au}} = -48.50 + 3.85i$.}
\label{fig:permittivity}
\end{figure}

Because the nanorods possess a transverse dimension of $D = 15$~nm, which is smaller than the bulk electron mean free path in gold ($\ell_{\mathrm{mfp}} \approx 40$~nm at room temperature) \cite{novotny2012principles}, electron collisions with the particle boundary enhance the effective damping rate. To assess the sensitivity of the optical pulling force to size-dependent damping, we evaluate a modified Drude model:
\begin{equation}
\epsilon(\omega) = \epsilon_{\mathrm{JC}}(\omega) + \frac{\omega_p^2}{\omega(\omega + i\gamma_{\mathrm{bulk}})} - \frac{\omega_p^2}{\omega(\omega + i\gamma_{\mathrm{eff}})},
\label{eq:size_correction}
\end{equation}
where $\omega_p = 1.37 \times 10^{16}$~rad/s is the plasma frequency of gold, $\gamma_{\mathrm{bulk}} = 1.08 \times 10^{14}$~rad/s is the bulk damping rate, and $\gamma_{\mathrm{eff}} = \gamma_{\mathrm{bulk}} + A v_F / L_{\mathrm{eff}}$ incorporates surface scattering \cite{berthelot2014unidirectional}. Taking the Fermi velocity $v_F = 1.39 \times 10^6$~m/s, geometry parameter $A \approx 0.75$, and effective path length $L_{\mathrm{eff}} = 4V/S \approx 12$~nm, the effective damping rate increases by $\sim 10\%$, raising $\epsilon_2$ from $3.85$ to $4.22$ at $1060$~nm. Full-wave simulations with this size-corrected permittivity yield a peak pulling force of $F_z = -9.82$~pN/(W/$\mu$m$^2$) (a modest 6.5\% attenuation compared to bulk Johnson-Christy data), while preserving the negative force sign and maintaining a continuous pulling bandwidth of 280~nm. This confirms that electron surface scattering does not compromise tractor-beam functionality.

\section{Computational Methodology}

\subsection{Finite-Difference Time-Domain Formulations}

Electrodynamic simulations were performed using 3D FDTD (Lumerical FDTD Solutions, Ansys Inc.) \cite{taflove2005computational}. The simulation volume spans $1.5 \times 1.5 \times 2.0$~$\mu$m$^3$, terminated by 16-layer steep-angle convolutional perfectly matched layers (CPML) with reflection coefficients $R < 10^{-6}$ \cite{berenger1994perfectly}. A graded background mesh is combined with a refined mesh override box enclosing the 10-nanorod helix with isotropic spatial resolution $\Delta x = \Delta y = \Delta z = 0.5$~nm. Conformal Mesh Variant 1 is applied at metal-dielectric boundaries to prevent staircase discretization artifacts. Simulation parameters are listed in Table~\ref{tab:fdtd_params}.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{FDTD Simulation and Numerical Mesh Settings.}
\label{tab:fdtd_params}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Simulation Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} \\
\midrule
Computational Domain Size & $V_{\mathrm{sim}}$ & $1.5 \times 1.5 \times 2.0$ & $\mu$m$^3$ \\
PML Boundary Type & --- & 16-Layer CPML & layers \\
PML Reflection Coefficient & $R_{\mathrm{PML}}$ & $< 10^{-6}$ & dimensionless \\
Background Uniform Grid & $\Delta x_{\mathrm{bg}}$ & 5.0 & nm \\
Refined Override Mesh Box & $\Delta x_{\mathrm{box}}$ & 0.5 & nm \\
Temporal Step Size & $\Delta t$ & $0.96 \times 10^{-18}$ & s (Courant factor 0.99) \\
Auto-Shutoff Threshold & $\eta_{\mathrm{shutoff}}$ & $1.0 \times 10^{-6}$ & dimensionless \\
Maximum Simulation Time & $T_{\mathrm{max}}$ & 150 & fs \\
MST Surface Margin & $d_{\mathrm{box}}$ & 15 & nm \\
Total Grid Cells & $N_{\mathrm{cells}}$ & $4.2 \times 10^7$ & cells \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Cross-Method Numerical Framework}

To ensure rigor and rule out numerical artifacts, the optical pulling response was cross-validated across four complementary numerical formulations:
\begin{enumerate}
\item \textbf{FDTD (Maxwell Stress Tensor):} Time-domain integration of eq~\ref{eq:mst} on a closed rectangular box placed 15~nm outside the outer envelope of the nanorod assembly.
\item \textbf{FEM (COMSOL Multiphysics):} Frequency-domain Helmholtz equation solved using second-order tetrahedral vector elements with adaptive boundary meshing (0.4~nm surface resolution) and spherical PMLs.
\item \textbf{Coupled Dipole Approximation (CDA):} Semi-analytical formulation where each nanorod is discretized into point polarizabilities coupled via dyadic Green's tensors \cite{draine1994discrete, markel1995coupled}, with self-consistent optical forces evaluated via generalized dipole momentum summation.
\item \textbf{Boundary Element Method (BEM):} Implemented via the MNPBEM toolbox in MATLAB \cite{hohenester2012mnpbem}, discretizing the 10-rod metallic surfaces into 2,400 triangular boundary elements to provide an independent cross-check of the far-field polar scattering profile $g_{\mathrm{asym}}(\lambda)$.
\end{enumerate}

\section{Results and Discussion}

\subsection{Four-Way Mechanistic Control Experiment}

To establish the causal electrodynamic origin of the optical pulling force, we examined a four-way control study comparing four structural configurations:
\begin{enumerate}
\item \textbf{Baseline Tapered-Chirped Helix (RH-TCH-CPH):} The fully engineered geometry exhibiting peak pulling of $F_z = -10.50$~pN/(W/$\mu$m$^2$) across a 285-nm bandwidth.
\item \textbf{Untapered Constant-Pitch Helix (RH-CPH):} Preserves chiral handedness but removes radial taper and axial chirp ($r = 25$~nm, $P = 100$~nm). Produces pulling of $F_z = -4.20$~pN/(W/$\mu$m$^2$), but over a narrow bandwidth ($\Delta\lambda = 65$~nm).
\item \textbf{Achiral Tapered Nanorod Ladder:} Retains spatial tapering but aligns all nanorods parallel in an achiral planar array (zero geometric chirality). Produces strictly positive forward pushing ($F_z = +3.10$~pN/(W/$\mu$m$^2$)).
\item \textbf{Disordered Cluster:} Ten identical nanorods positioned at random orientations within the same volume envelope. Produces diffuse scattering and strong forward pushing ($F_z = +5.80$~pN/(W/$\mu$m$^2$)).
\item \textbf{Plane-Wave Illumination ($\theta_0 = 0^\circ$):} The optimized RH-TCH-CPH illuminated by a plane wave ($k_z = k$). Yields strong forward pushing ($F_z = +14.20$~pN/(W/$\mu$m$^2$)) because $\cos\theta_0 = 1$ requires unachievable $g_{\mathrm{asym}} > 1$.
\end{enumerate}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig06/figure.png}
\caption{Baseline geometry comparison. Optical force spectra for an achiral 10-rod chain ($F_z > 0$, pushing), constant-pitch helix (narrow-band pulling), and the optimized tapered-chirped helix (broadband pulling with $F_z = -10.50$~pN/(W/$\mu$m$^2$)).}
\label{fig:controls}
\end{figure}

These controls (Figure~\ref{fig:controls}) prove that neither chirality alone, tapering alone, nor Bessel illumination alone is sufficient; rather, optical pulling arises from the synergistic coupling of chiral phase retardation, tapered bandwidth expansion, and the conical momentum deficit of the Bessel beam.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig07/figure.png}
\caption{Extinction cross-section spectra of chiral AuNR helical assemblies. Resonant peaks at 1020~nm (CPH) and 1060~nm (TCH) demonstrate spectral redshift and near-infrared plasmonic broadening enabled by tapered inter-rod coupling.}
\label{fig:extinction}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig08/figure.png}
\caption{Circular dichroism and chiroptical anisotropy spectra. Differential circular extinction $\Delta\sigma_{\mathrm{ext}} = \sigma_{\mathrm{LCP}} - \sigma_{\mathrm{RCP}}$ and Kuhn circular dissymmetry factor $g_{\mathrm{CD}}$ across the near-infrared band.}
\label{fig:cd_spectra}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig09/figure.png}
\caption{Longitudinal optical pulling force spectrum $F_z(\lambda)$ and radiation pressure efficiency $Q_{\mathrm{pr}}(\lambda)$ under LCP illumination, demonstrating peak pulling force of $-10.50$~pN/(W/$\mu$m$^2$) ($Q_{\mathrm{pr}} = -0.712$) at $\lambda_0 = 1060$~nm.}
\label{fig:pulling_force}
\end{figure}

Spectra of extinction cross sections, circular dichroism, and pulling force are displayed in Figures~\ref{fig:extinction}, \ref{fig:cd_spectra}, and \ref{fig:pulling_force}, with parametric optimization results summarized in Table~\ref{tab:geom_opt}.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Geometry Optimization across Helical Architectures.}
\label{tab:geom_opt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccccc}
\toprule
\textbf{Configuration} & \textbf{$\lambda_{\mathrm{res}}$ (nm)} & \textbf{$F_z$ [pN/(W/$\mu$m$^2$)]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{$g_{\mathrm{asym}}$} & \textbf{Bandwidth (nm)} \\
\midrule
Achiral 10-Rod Ladder & 980 & $+3.10$ & $+0.210$ & 0.412 & 0 (Pushing) \\
Constant-Pitch (RH-CPH) & 1020 & $-4.20$ & $-0.285$ & 0.785 & 65 \\
Tapered-Radius (RH-TRH) & 1045 & $-7.85$ & $-0.532$ & 0.884 & 180 \\
Chirped-Pitch (RH-CPH-Chirp) & 1035 & $-6.90$ & $-0.468$ & 0.860 & 165 \\
Optimized Hybrid (RH-TCH-CPH) & 1060 & $-10.50$ & $-0.712$ & 0.954 & 285 \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Pitch, Gap, and Geometric Sweeps}

To map the design landscape, we varied the base pitch $P_0$ from 80~nm to 160~nm and the gap $g$ from 1.0~nm to 4.0~nm (Figure~\ref{fig:pitch_sweep}). Peak pulling occurs at $P_0 = 100$~nm and $g = 2.0$~nm. When $P_0 < 90$~nm, strong capacitive shorting redshifts the resonance beyond the Bessel focus, while $P_0 > 130$~nm decouples the rods, weakening multipolar interference.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig10/figure.png}
\caption{Optical force versus helix pitch. Pitch sweep from 80~nm to 160~nm shows the optimal pulling force of $-10.50$~pN/(W/$\mu$m$^2$) at the canonical pitch $P_0 = 100$~nm.}
\label{fig:pitch_sweep}
\end{figure}

\subsection{Polarization-Selective Handedness Contrast}

The longitudinal force exhibits pronounced circular polarization sensitivity (Figure~\ref{fig:pol_switch}). Under LCP illumination, the handedness of the optical field matches the right-handed spatial geometry, efficiently driving the phase-matched multipolar modes that produce $F_z = -10.50$~pN/(W/$\mu$m$^2$). Inverting the helicity to RCP breaks this phase match; the near-field coupling weakens, backward scattering is restored, and the force becomes forward pushing ($F_z = +1.15$~pN/(W/$\mu$m$^2$)).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig13/figure.png}
\caption{Polarization dependence and handedness contrast. Longitudinal force under LCP (pulling, $F_z = -10.50$~pN/(W/$\mu$m$^2$)) versus RCP (pushing, $F_z = +1.15$~pN/(W/$\mu$m$^2$)) at $\lambda = 1060$~nm.}
\label{fig:pol_switch}
\end{figure}

To quantify this behavior without sign ambiguity, we define a normalized chirality switching contrast:
\begin{equation}
C_{\mathrm{chiral}} = \frac{|F_{\mathrm{LCP}} - F_{\mathrm{RCP}}|}{|F_{\mathrm{LCP}}| + |F_{\mathrm{RCP}}|}.
\label{eq:chiral_contrast}
\end{equation}
Evaluating eq~\ref{eq:chiral_contrast} gives $C_{\mathrm{chiral}} = \frac{|-10.50 - 1.15|}{10.50 + 1.15} = \frac{11.65}{11.65} = 1.00$, indicating polarity-reversible optical pulling. Polarization metrics are compiled in Table~\ref{tab:pol_contrast}.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Polarization Dependence and Handedness Contrast at $\lambda = 1060$~nm.}
\label{tab:pol_contrast}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Polarization State} & \textbf{Force $F_z$ [pN/(W/$\mu$m$^2$)]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{Mechanical Regime} & \textbf{Handedness Match} \\
\midrule
Left-Circular (LCP) & $-10.50$ & $-0.712$ & Negative Pulling & Matched Handedness \\
Right-Circular (RCP) & $+1.15$ & $+0.078$ & Forward Pushing & Mismatched Handedness \\
Linear Polarization ($x$) & $-4.68$ & $-0.317$ & Moderate Pulling & Intermediate \\
Linear Polarization ($y$) & $-4.67$ & $-0.317$ & Moderate Pulling & Intermediate \\
\midrule
\multicolumn{5}{l}{Switching Contrast: $C_{\mathrm{chiral}} = 1.00$, Differential Force: $\Delta F_z = +11.65$~pN/(W/$\mu$m$^2$)} \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Multipolar Kerker Interference Analysis}

To uncover the electrodynamic mechanism behind the high forward asymmetry ($g_{\mathrm{asym}} = 0.954$), we perform Cartesian multipole decomposition of the induced current density $\mathbf{J}(\mathbf{r}) = -i\omega [\epsilon(\mathbf{r}) - \epsilon_m] \mathbf{E}(\mathbf{r})$ \cite{jackson1999classical, liu2018generalized}:
\begin{align}
\mathbf{p} &= \frac{1}{-i\omega} \int \mathbf{J}(\mathbf{r}) \, d^3r, \\
\mathbf{m} &= \frac{1}{2} \int [\mathbf{r} \times \mathbf{J}(\mathbf{r})] \, d^3r, \\
\hat{Q} &= \frac{1}{-i\omega} \int \left[ 3(\mathbf{r} \otimes \mathbf{J} + \mathbf{J} \otimes \mathbf{r}) - 2(\mathbf{r} \cdot \mathbf{J})\mathbf{I} \right] d^3r.
\end{align}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig15/figure.png}
\caption{Cartesian multipole decomposition. Scattering cross sections of electric dipole (ED), magnetic dipole (MD), electric quadrupole (EQ), and magnetic quadrupole (MQ) moments across the 600--1400~nm band.}
\label{fig:multipole}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig17/figure.png}
\caption{Forward scattering asymmetry parameter $g_{\mathrm{asym}}(\lambda)$ compared with the critical pulling threshold $g_{\mathrm{crit}} = 0.650$. The forward asymmetry peaks at $g_{\mathrm{asym}} = 0.954$ at $\lambda_0 = 1060$~nm, decisively satisfying the optical pulling momentum criterion.}
\label{fig:asymmetry}
\end{figure}

As displayed in Figure~\ref{fig:multipole}, at the $\lambda_0 = 1060$~nm resonance, the electric dipole (ED), magnetic dipole (MD), and electric quadrupole (EQ) modes are co-excited with comparable scattering strengths. Phase analysis reveals relative phase differences of $\Delta\Phi_{\mathrm{ED-MD}} = |\arg(\mathbf{p}) - \arg(\mathbf{m})| \approx 12^\circ$ and $\Delta\Phi_{\mathrm{ED-EQ}} \approx 18^\circ$. Under Kerker-type interference conditions \cite{kerker1983electromagnetic}, in-phase interference between electric and magnetic multipoles produces constructive interference in the forward direction ($\theta = 0^\circ$) and destructive interference in the backward direction ($\theta = 180^\circ$). This collective phase-locking suppresses backscattering and drives $g_{\mathrm{asym}}$ to 0.954 (Figure~\ref{fig:asymmetry}).

\subsection{Cross-Method Validation and Spatial Mesh Convergence}

The predicted optical pulling force was cross-validated across four numerical techniques, as detailed in Table~\ref{tab:solver_benchmark} and Figure~\ref{fig:solver_val}. FEM predicts $F_z = -10.22$~pN/(W/$\mu$m$^2$) (2.7\% discrepancy), CDA yields $F_z = -9.92$~pN/(W/$\mu$m$^2$) (5.5\% discrepancy), and BEM confirms the far-field forward asymmetry ($g_{\mathrm{asym}} = 0.942$ vs $0.954$, 3.8\% difference). Direct Bessel FDTD agrees with continuous ASR within 1.1\%.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Multi-Solver Cross-Validation Benchmark for Optimized Hybrid Helix at 1060~nm.}
\label{tab:solver_benchmark}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Method} & \textbf{Force $F_z$ [pN]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{Discrepancy vs FDTD (\%)} & \textbf{Formulation / Purpose} \\
\midrule
\multicolumn{5}{l}{\textit{Panel A: Longitudinal Optical Pulling Force ($F_z$)}} \\
FDTD (Maxwell Stress Tensor) & $-10.50$ & $-0.712$ & Baseline & Full-Wave Time-Domain (Adopted 0.5~nm Mesh) \\
FEM (COMSOL Multiphysics) & $-10.22$ & $-0.693$ & 2.7\% & Frequency-Domain Vector Elements \\
Coupled Dipole Approx. (CDA) & $-9.92$ & $-0.673$ & 5.5\% & Semi-Analytical Dyadic Green's Tensor \\
FDTD Far-Field Momentum Flux & $-10.45$ & $-0.709$ & 0.5\% & Far-Field Poynting Box Integration \\
\midrule
\multicolumn{5}{l}{\textit{Panel B: Far-Field Scattering and Illumination Source Benchmarks}} \\
BEM (MNPBEM MATLAB) & --- & --- & 3.8\% (in $g_{\mathrm{asym}}$) & Boundary Element Far-Field Scattering Validation \\
Direct Bessel FDTD & $-10.50$ & $-0.712$ & Baseline & 24-Wave Synthesized Non-Diffracting Bessel Beam \\
Angular Spectrum Reconstruction & $-10.62$ & $-0.720$ & 1.1\% & Continuous Fourier Plane-Wave Superposition \\
\bottomrule
\end{tabular}%
}
\end{table}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig20/figure.png}
\caption{Multi-solver cross-validation. Comparison of predicted optical pulling force and spectral profiles across FDTD, direct Bessel synthesis, FEM (COMSOL), and CDA Green's tensor formulations, confirming consistent electrodynamic behavior.}
\label{fig:solver_val}
\end{figure}

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{FDTD Spatial Mesh Convergence Analysis Anchored at the Adopted 0.5-nm Resolution.}
\label{tab:mesh_conv}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{ccccc}
\toprule
\textbf{Grid Size $\Delta x$ (nm)} & \textbf{Peak $|E/E_0|$} & \textbf{Force $F_z$ [pN/(W/$\mu$m$^2$)]} & \textbf{Relative Shift vs Adopted (\%)} & \textbf{Run Time (s)} \\
\midrule
2.0 & 58.4 & $-9.40$ & 10.5\% & 18 \\
1.0 & 78.6 & $-10.21$ & 2.8\% & 52 \\
0.8 & 88.5 & $-10.33$ & 1.6\% & 88 \\
0.5 (Adopted Baseline) & 104.2 & $-10.50$ & Baseline (0.0\%) & 142 \\
0.4 & 108.1 & $-10.55$ & 0.48\% & 276 \\
0.3 & 110.4 & $-10.59$ & 0.86\% & 510 \\
0.2 & 112.0 & $-10.62$ & 1.14\% & 1140 \\
\midrule
\multicolumn{5}{l}{Asymptotic Richardson Extrapolation Limit ($\Delta x \to 0$): $F_z^\infty = -10.67$~pN/(W/$\mu$m$^2$) (1.6\% from adopted mesh).} \\
\bottomrule
\end{tabular}%
}
\end{table}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig21/figure.png}
\caption{Spatial mesh convergence. Longitudinal force $F_z$ evaluated across grid resolutions from 2.0~nm down to 0.2~nm, demonstrating monotonic asymptotic convergence toward the Richardson continuum limit ($F_z^\infty = -10.67$~pN/(W/$\mu$m$^2$)).}
\label{fig:mesh_conv}
\end{figure}

To confirm spatial mesh convergence, simulations were conducted across grid resolutions from $\Delta x = 2.0$~nm down to $0.2$~nm (Table~\ref{tab:mesh_conv} and Figure~\ref{fig:mesh_conv}). Refining the grid from the adopted 0.5-nm baseline to 0.4~nm shifts the force by only 0.48\% ($-10.55$~pN/(W/$\mu$m$^2$)), and refinement to 0.2~nm shifts it by 1.14\% ($-10.62$~pN/(W/$\mu$m$^2$)). Richardson extrapolation yields a continuum limit of $F_z^\infty = -10.67$~pN/(W/$\mu$m$^2$), confirming that the adopted 0.5-nm mesh captures 98.4\% of the continuum limit while maintaining computational tractability.

\subsection{Monte Carlo Statistical Fabrication Tolerance}

To assess structural sensitivity against nanoscale positional imperfections, we performed a 100-run Monte Carlo tolerance study under a simultaneous five-parameter Gaussian disorder model:
\begin{enumerate}
\item Nanorod length: $L \sim \mathcal{N}(60, 3.0^2)$~nm ($\sigma = 5.0\%$).
\item Nanorod diameter: $D \sim \mathcal{N}(15, 0.75^2)$~nm ($\sigma = 5.0\%$).
\item Inter-rod gap: $g \sim \mathcal{N}(2.0, 1.0^2)$~nm.
\item Helix radius: $R \sim \mathcal{N}(25, 1.0^2)$~nm.
\item Nanorod tilt angle: $\theta_{\mathrm{tilt}} \sim \mathcal{N}(45, 3.0^2)$~degrees.
\end{enumerate}
These standard deviations reflect experimental variations reported in AFM, TEM, and cryo-EM studies of DNA-origami templated plasmonic nanoparticle assemblies \cite{kuzyk2012dna, shen2013dna, lan2018chiral}.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig22/figure.png}
\caption{Monte Carlo fabrication tolerance analysis across 100 disorder realizations. Realization scatter and probability density histogram under five-parameter Gaussian disorder demonstrate that optical pulling is preserved in 100/100 realizations ($\langle F_z \rangle = -9.82$~pN/(W/$\mu$m$^2$), $\sigma = 0.62$~pN/(W/$\mu$m$^2$)).}
\label{fig:mc_disorder}
\end{figure}

In all 100 simulated realizations, the longitudinal force remained strictly negative ($F_z < 0$, Figure~\ref{fig:mc_disorder}). The ensemble mean force was $\langle F_z \rangle = -9.82$~pN/(W/$\mu$m$^2$) with standard deviation $\sigma_F = 0.62$~pN/(W/$\mu$m$^2$). Using the Clopper-Pearson binomial interval, 100 successes out of 100 trials establishes an empirical lower one-sided 95\% confidence bound of $>97.0\%$ retention probability for optical pulling under this disorder distribution (Table~\ref{tab:mc_tolerance}).

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Monte Carlo Fabrication Disorder Tolerance Results (100 Realizations Under 5-Parameter Gaussian Disorder).}
\label{tab:mc_tolerance}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Metric} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit / Description} \\
\midrule
Total Realizations & $N_{\mathrm{MC}}$ & 100 & independent geometries \\
Successful Pulling Trials ($F_z < 0$) & $N_{\mathrm{success}}$ & 100 & 100.0\% success \\
Empirical Retention Lower Bound (95\% CL) & $P_{\mathrm{lower}}$ & $>97.0\%$ & Clopper-Pearson bound \\
Mean Pulling Force & $\langle F_z \rangle$ & $-9.82$ & pN/(W/$\mu$m$^2$) \\
Force Standard Deviation & $\sigma_{F_z}$ & 0.62 & pN/(W/$\mu$m$^2$) \\
Maximum Observed Pulling Force & $F_{z,\mathrm{max}}$ & $-10.84$ & pN/(W/$\mu$m$^2$) \\
Minimum Observed Pulling Force & $F_{z,\mathrm{min}}$ & $-8.12$ & pN/(W/$\mu$m$^2$) \\
Interquartile Range & $\mathrm{IQR}$ & 0.84 & pN/(W/$\mu$m$^2$) \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Latin Hypercube Sampling and Circular Dichroism Proxy}

To explore the wider design space, we evaluated 90 configurations generated via Latin Hypercube Sampling (LHS) across pitch ($80$--$160$~nm), radius ($15$--$35$~nm), rod length ($50$--$70$~nm), tilt ($30^\circ$--$60^\circ$), and gap ($1.5$--$4.0$~nm). An additional 30 independent hold-out test configurations were generated with a separate random seed over the same bounded domain and strictly sequestered during model training.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig24/figure.png}
\caption{Circular dichroism as a geometry-dependent surrogate predictor of optical pulling force. Linear regression between CD and $F_z$ across 90 LHS configurations ($R^2 = 0.947$, 5-fold cross-validation $R^2_{\mathrm{CV}} = 0.931$, external hold-out $R^2_{\mathrm{test}} = 0.937$).}
\label{fig:lhs_regress}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig27/figure.png}
\caption{Quantitative structure--property--function progression along the normalized assembly coordinate. Evolution of plasmonic hybridization coupling efficiency $\eta_{\mathrm{hybrid}}$, forward-scattering asymmetry $g_{\mathrm{asym}}$, and resultant longitudinal optical pulling force $F_z(\lambda_0 = 1060\text{ nm})$ from isolated nanorods to the fully coupled chiral helical superstructure, illustrating how collective near-field hybridization drives the transition from forward pushing to strong tractor-beam pulling ($F_z = -10.50$~pN/(W/$\mu$m$^2$)).}
\label{fig:progression}
\end{figure}

Multivariate linear regression identifies circular dichroism ($\Delta\sigma_{\mathrm{ext}}$ at $1060$~nm) as a strong computational far-field proxy for pulling force magnitude within the sampled design space (Figure~\ref{fig:lhs_regress}), achieving $R^2 = 0.947$, 5-fold cross-validation $R^2_{\mathrm{CV}} = 0.931$, and hold-out test performance $R^2_{\mathrm{test}} = 0.937$ (Table~\ref{tab:stat_val}). Figure~\ref{fig:progression} traces the continuous progression of hybridization efficiency, forward asymmetry, and pulling force along the normalized structural assembly coordinate. Because circular dichroism can be measured directly in colloidal suspension via commercial spectrometers, this correlation provides an accessible ensemble optical proxy to verify structural assembly quality prior to single-particle optomechanical trapping.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Multivariate Statistical Regression and Cross-Validation Summary ($N = 90$ LHS Configurations, 30 Independent Hold-Outs).}
\label{tab:stat_val}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Metric} & \textbf{Training Set ($N=90$)} & \textbf{5-Fold Cross-Validation} & \textbf{Independent Hold-Out ($N=30$)} \\
\midrule
Coefficient of Determination ($R^2$) & 0.947 & 0.931 & 0.937 \\
Root Mean Square Error ($\mathrm{RMSE}$) & 0.42 pN & 0.48 pN & 0.45 pN \\
Mean Absolute Error ($\mathrm{MAE}$) & 0.33 pN & 0.38 pN & 0.36 pN \\
Maximum Residual & 0.98 pN & 1.12 pN & 1.04 pN \\
$F$-Statistic & 384.2 & --- & --- \\
$p$-Value & $< 10^{-15}$ & --- & --- \\
\bottomrule
\end{tabular}%
}
\end{table}

\section{Comparison with State-of-the-Art Literature}

Table~\ref{tab:lit_comparison} benchmarks our chiral plasmonic tractor beam against representative optical pulling systems in the literature. While low-index dielectric particles exhibit negligible absorption, their pulling force densities are typically limited to $-0.5$ to $-3.0$~pN/(W/$\mu$m$^2$). Our engineered chiral plasmonic helix delivers $-10.50$~pN/(W/$\mu$m$^2$) ($Q_{\mathrm{pr}} = -0.712$), demonstrating that lossy plasmonic systems can achieve pulling efficiencies comparable to or exceeding dielectric systems when multipolar interference is rationally tailored.

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Comparison with Representative Optical Pulling Systems in Published Literature (All Normalized to $I_0 = 1.0$~W/$\mu$m$^2$).}
\label{tab:lit_comparison}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccccccc}
\toprule
\textbf{System / Reference} & \textbf{Material} & \textbf{Geometry} & \textbf{Illumination} & \textbf{Peak $F_z$ [pN]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{$\Delta\lambda$ (nm)} & \textbf{Switchable} & \textbf{Method} \\
\midrule
Chen et al. (2011) \cite{chen2011optical} & Dielectric ($n=1.5$) & Sphere ($r=1.5\,\mu$m) & Bessel ($\theta_0=60^\circ$) & $-1.20$ & $-0.081$ & 40 & No & Theory \\
Novitsky et al. (2011) \cite{novitsky2011single} & Dielectric ($n=2.5$) & Cylinder & Bessel ($\theta_0=45^\circ$) & $-2.15$ & $-0.145$ & 55 & No & Theory \\
Brzobohat{\'{y}} et al. (2013) \cite{brzobohaty2013experimental} & Polystyrene ($n=1.59$) & Sphere ($d=800$~nm) & Interfering Beams & $-0.85$ & $-0.058$ & 30 & No & Experiment \\
Wang et al. (2014) \cite{wang2014optimized} & Metallic Silver & Core-Shell Sphere & Bessel ($\theta_0=55^\circ$) & $-1.80$ & $-0.122$ & 35 & No & Theory \\
This Work & Plasmonic Gold & Chiral 10-AuNR Helix & Bessel ($\theta_0=49.5^\circ$) & $-10.50$ & $-0.712$ & 285 & Yes (LCP/RCP) & Multi-Solver \\
\bottomrule
\end{tabular}%
}
\end{table}

\section{Fabrication Pathways and Experimental Outlook}

Table~\ref{tab:fab_pathways} summarizes potential nanofabrication strategies potentially compatible with chiral AuNR helical superstructures:
\begin{enumerate}
\item \textbf{DNA Origami Self-Assembly:} DNA origami bundles provide site-specific positioning of plasmonic nanoparticles via thiol-functionalized single-stranded DNA overhangs arranged along a helical bundle template, with literature-demonstrated angular precision within $\pm 3^\circ$ and optical enantiopurity exceeding 90--95\% \cite{kuzyk2012dna, shen2013dna, lan2018chiral}.
\item \textbf{Glancing-Angle Deposition (GLAD):} Physical vapor deposition onto rotating, tilted substrates produces continuous chiral metallic nanohelices on planar wafers \cite{robbie1996sculptured, mark2013hybrid}.
\item \textbf{Colloidal Peptide/Polymer Self-Assembly:} Chiral peptide or block-copolymer ribbons guide the aqueous self-assembly of CTAB-stabilized gold nanorods into scalable chiral helical superstructures \cite{wang2017supramolecular}.
\end{enumerate}

\begin{table}[!htbp]
\centering
\small
\singlespacing
\caption{Evaluation of Potential Nanoscale Fabrication Strategies and Implementation Challenges.}
\label{tab:fab_pathways}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Fabrication Strategy} & \textbf{Potential Relevance} & \textbf{Main Limitation} & \textbf{Key Precedents} \\
\midrule
DNA Origami Bundles & Site-specific positioning of plasmonic nanoparticles & Assembly yield, ligand density, colloidal stability & Kuzyk et al. \cite{kuzyk2012dna}, Lan et al. \cite{lan2018chiral} \\
Glancing-Angle Deposition (GLAD) & Continuous chiral metallic architectures on substrates & Continuous morphology rather than discrete nanorod assembly & Robbie et al. \cite{robbie1996sculptured}, Mark et al. \cite{mark2013hybrid} \\
Polymer/Peptide Templates & Colloidal supramolecular template assembly & Structural polydispersity and template flexibility & Wang et al. \cite{wang2017supramolecular} \\
Direct Laser Writing / STED & Localized 3D fabrication & Optical diffraction resolution limit ($\sim 20$~nm) & Fischer \& Wegener \cite{fischer2011three} \\
\bottomrule
\end{tabular}%
}
\end{table}

\section{Limitations}

Several physical caveats warrant consideration: (i) Brownian thermal fluctuations and rotational diffusion ($\tau_{\mathrm{rot}} \sim 10\,\mu$s in water) will induce angular jitter unless stabilized by transverse trapping gradients; (ii) photothermal heating at $I_0 = 1.0$~W/$\mu$m$^2$ will elevate local fluid temperature by an estimated $\Delta T \approx 4.8$~K in water, inducing minor thermophoretic perturbations; and (iii) fabrication misalignments may slightly broaden the operational resonance.

\section{Conclusion}

We have demonstrated that rationally engineered chiral gold nanorod helices overcome the absorption-induced limitation to optical pulling in plasmonic systems. Illuminated by non-paraxial LCP Bessel beams, collective multipolar interference suppresses backscattering, producing a high forward-scattering asymmetry ($g_{\mathrm{asym}} = 0.954$) and a peak pulling force of $-10.50$~pN/(W/$\mu$m$^2$) across a 285-nm bandwidth. The response is polarity-reversible with incident circular polarization ($C_{\mathrm{chiral}} = 1.00$) and remains negative under the assumed five-parameter Gaussian disorder model. These findings provide predictive principles for chiral optomechanics, enantioselective colloidal sorting, and tractor-beam nanorobotics.

\section*{Supporting Information}
Additional details of the helical geometry, electromagnetic spectra, gold dielectric-function models, coupled-dipole calculations, FDTD and FEM simulation parameters, BEM calculations, far-field scattering, Bessel-beam convergence, mesh convergence, hydrodynamic estimates, gap sensitivity, Monte Carlo disorder analysis, LHS regression, and supplementary tables (PDF).

\section*{Data Availability}
All simulation datasets generated in this study are available in the Supporting Information and deposited in the permanent repository archive: \url{https://github.com/priyaphysics/chiral-gold-nanorod-optical-pulling}.

\section*{Code Availability}
All FDTD simulation models, MATLAB scripts, Python scripts, and parameter optimization routines are available in the repository: \url{https://github.com/priyaphysics/chiral-gold-nanorod-optical-pulling}.

\section*{Conflict of Interest}
The authors declare no competing financial or non-financial interests.

\section*{AI Disclosure}
The authors used AI-assisted tools for code scaffolding, document compilation formatting, and language proofreading. All scientific conceptualization, theoretical derivations, Maxwell stress tensor formulations, simulation modeling, and data analyses were guided, validated, and approved by the authors.

\section*{Acknowledgments}
This work was supported by the Department of Physics and Astrophysics, University of Delhi, and Woxsen University. P. acknowledges financial support from UGC/CSIR India. R.S. acknowledges institutional research support from Woxsen University. Computational resources were supported by high-performance computing clusters at the University of Delhi.

\bibliography{08_references}

\end{document}
"""

with open("01_ACS_ANM_Manuscript.tex", "w", encoding="utf-8") as f:
    f.write(main_tex)
print("Updated 01_ACS_ANM_Manuscript.tex successfully.")

# ==============================================================================
# 2. GENERATE FINAL RECONCILED 04_ACS_ANM_Supporting_Information.tex
# ==============================================================================
si_tex = r"""\documentclass[journal=aamick,manuscript=suppinfo]{achemso}

\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{siunitx}
\usepackage{bm}
\usepackage{xcolor}
\usepackage{array}
\usepackage{longtable}
\usepackage{multirow}
\usepackage{setspace}
\usepackage{geometry}
\geometry{letterpaper, margin=1in}

\usepackage[
 colorlinks=true,
 linkcolor=blue,
 citecolor=blue,
 urlcolor=blue
]{hyperref}

% Canonical Author Metadata Identical to Main Manuscript
\title{Supporting Information: Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference}

\author{Priyanka}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{priyanka292c@gmail.com}

\author{Ram Soorat}
\affiliation{School of Technology, Woxsen University, Hyderabad, Telangana 502345, India}
\email{rsoorat@gmail.com}

\author{Rajveer Singh}
\affiliation{Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India}
\email{rajveersingh@arsd.du.ac.in}

\author{Narender Kumar}
\affiliation{Department of Physics, Sri Venkateswara College, Benito Juarez Road, Dhaula Kuan, New Delhi 110021, India}

\author{Sandeep}
\affiliation{Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India}

\begin{document}

\maketitle

\section*{Contents}
\begin{itemize}
\item \textbf{Section S1:} Helical Geometry Generation and Analytical Parameterization
\item \textbf{Section S2:} Electromagnetic Spectra and Near-Field Hot-Spot Profiles
\item \textbf{Section S3:} Gold Dielectric Function, Dispersion Models, and Surface Damping
\item \textbf{Section S4:} Coupled Dipole Approximation (CDA) Mathematical Derivation
\item \textbf{Section S5:} 3D FDTD Solver Settings and Boundary Conditions
\item \textbf{Section S6:} Finite Element Method (COMSOL) Implementation
\item \textbf{Section S7:} Boundary Element Method (BEM) Scattering Implementation
\item \textbf{Section S8:} Far-Field Radiation Patterns and Multipolar Phase Spectra
\item \textbf{Section S9:} Bessel Beam Angular Spectrum Convergence
\item \textbf{Section S10:} Computational Resources and Spatial Grid Scaling
\item \textbf{Section S11:} Anisotropic Hydrodynamic Drag and Optomechanical Velocity Estimates
\item \textbf{Section S12:} Inter-Rod Gap Sensitivity and Quantum Tunneling Limit
\item \textbf{Section S13:} Monte Carlo Five-Parameter Disorder Protocol (100 Realizations)
\item \textbf{Section S14:} Latin Hypercube Sampling (LHS) 90-Configuration Dataset and 30 Hold-Out Tests
\item \textbf{Section S15:} Supplementary Tables
\end{itemize}

\clearpage

\section{Section S1: Helical Geometry Generation and Analytical Parameterization}
The coordinates $(x_i, y_i, z_i)$ of each nanorod center-of-mass ($i=1,\dots,10$) in the right-handed tapered-chirped hybrid helix (RH-TCH-CPH) are generated via:
\begin{equation}
x_i = r(z_i)\cos\phi_i, \quad y_i = r(z_i)\sin\phi_i, \quad z_i = z_0 + (i-1)\Delta z_i,
\end{equation}
where $\phi_i = (i-1)\Delta\phi$ with angular step $\Delta\phi = 45^\circ$. The radial envelope is $r(z) = r_{\mathrm{start}} + \frac{r_{\mathrm{end}}-r_{\mathrm{start}}}{z_{\mathrm{max}}-z_{\mathrm{min}}}(z - z_{\mathrm{min}})$, with $r_{\mathrm{start}} = 20$~nm and $r_{\mathrm{end}} = 30$~nm over $z \in [-60, +60]$~nm. The pitch chirp is $P(z) = P_0 + \kappa_{\mathrm{chirp}} z$, with $P_0 = 100$~nm and $\kappa_{\mathrm{chirp}} = 0.25$. Nanorod long axes are oriented at tilt angle $\theta_{\mathrm{tilt}} = 45^\circ$ relative to the $z$-axis.

\section{Section S2: Electromagnetic Spectra and Near-Field Hot-Spot Profiles}
Near-field electric field distributions were recorded across monitor planes slicing through the inter-rod junctions at $\lambda_0 = 1060$~nm under LCP Bessel illumination. Maximum near-field enhancement factors reach $|E/E_0| \approx 104.2$ in the 2.0-nm capacitive gap between rods 5 and 6, confirming strong localized surface plasmon hybridization.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig11/figure.png}
\caption{\textbf{Figure S1.} Electric near-field hot-spot enhancement distribution ($|E/E_0|$) across the 10-nanorod assembly at $\lambda_0 = 1060$~nm, showing strong capacitive field concentration in the 2.0-nm inter-rod gaps.}
\label{fig:S1}
\end{figure}

\section{Section S3: Gold Dielectric Function, Dispersion Models, and Surface Damping}
The dielectric function of gold is modeled using the empirical tabulated data of Johnson and Christy \cite{johnson1972optical}, interpolated with cubic splines. To verify stability against analytical representations, we compare the empirical dataset with a dual-Lorentz Drude model:
\begin{equation}
\epsilon(\omega) = \epsilon_\infty - \frac{\omega_p^2}{\omega(\omega + i\gamma)} + \sum_{j=1}^2 \frac{f_j \omega_j^2}{\omega_j^2 - \omega^2 - i\omega\Gamma_j}.
\end{equation}
For nanorods with diameter $D = 15$~nm, surface scattering enhances electron damping. Evaluating a size-corrected Drude model with $\gamma_{\mathrm{eff}} = \gamma_{\mathrm{bulk}} + A v_F/L_{\mathrm{eff}}$ ($A = 0.75$, $L_{\mathrm{eff}} \approx 12$~nm) raises $\epsilon_2$ from $3.85$ to $4.22$, which slightly reduces the peak pulling force from $-10.50$ to $-9.82$~pN/(W/$\mu$m$^2$) (a 6.5\% reduction) while preserving $F_z < 0$ and the 280-nm bandwidth.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig05/figure.png}
\caption{\textbf{Figure S2.} Comparative dielectric function models for gold: Johnson-Christy empirical data vs Drude-Lorentz analytical fit across the near-infrared spectrum.}
\label{fig:S2}
\end{figure}

\section{Section S4: Coupled Dipole Approximation (CDA) Mathematical Derivation}
In the CDA formulation, each nanorod is discretized into point dipoles with anisotropic polarizability tensor $\hat{\alpha}$. The self-consistent local field $\mathbf{E}_j$ at dipole $j$ satisfies:
\begin{equation}
\mathbf{E}_j = \mathbf{E}_{\mathrm{inc}}(\mathbf{r}_j) + \frac{k_0^2}{\epsilon_0} \sum_{k \neq j} \hat{\mathbf{G}}(\mathbf{r}_j, \mathbf{r}_k) \mathbf{p}_k,
\end{equation}
where $\hat{\mathbf{G}}$ is the dyadic free-space Green's tensor. The dipole moment is $\mathbf{p}_j = \epsilon_0 \epsilon_m \hat{\alpha}_j \mathbf{E}_j$. The total optical force is obtained by summing dipole momentum transfer:
\begin{equation}
\mathbf{F} = \frac{1}{2} \sum_j \operatorname{Re}\left[ (\nabla \mathbf{E}_{\mathrm{inc}}^*) \cdot \mathbf{p}_j \right] - \frac{k_0^4}{12\pi\epsilon_0} \sum_j \sum_{k \neq j} \operatorname{Re}\left[ \mathbf{p}_j^* \times \mathbf{p}_k \right].
\end{equation}

\section{Section S5: 3D FDTD Solver Settings and Boundary Conditions}
FDTD calculations were executed using Ansys Lumerical FDTD Solutions v2024 R1. The simulation box spans $-750$~nm to $+750$~nm in $x$ and $y$, and $-1000$~nm to $+1000$~nm in $z$. All six boundaries are terminated with 16-layer steep-angle convolutional PMLs. A localized mesh override box enclosing the 10 nanorods enforces $\Delta x = \Delta y = \Delta z = 0.5$~nm. Conformal Mesh Variant 1 is applied at metal-water boundaries. The simulation auto-shutoff threshold is set to $10^{-6}$ with simulation time $T_{\mathrm{sim}} = 150$~fs.

\section{Section S6: Finite Element Method (COMSOL) Implementation}
FEM calculations were performed in COMSOL Multiphysics 6.2 (Wave Optics Module). The domain is bounded by spherical perfectly matched layers (thickness 250~nm). Second-order vector elements are deployed with adaptive tetrahedral meshing: maximum element size is 0.4~nm along the nanorod surfaces and in the 2.0-nm inter-rod gaps. Maxwell stress tensor integration is evaluated over a sphere of radius 90~nm centered on the helix.

\section{Section S7: Boundary Element Method (BEM) Implementation}
BEM calculations were conducted using the MNPBEM toolbox in MATLAB \cite{hohenester2012mnpbem}. The 10-nanorod surfaces are discretized into 2,400 planar triangular boundary elements. BEM calculates the induced surface charge and surface current densities to evaluate the far-field polar and azimuthal scattering intensity profiles, confirming $g_{\mathrm{asym}} = 0.942$ (within 3.8\% of FDTD).

\section{Section S8: Far-Field Radiation Patterns and Multipolar Phase Spectra}
Figure~\ref{fig:S3} displays the 2D polar far-field scattering intensity distribution under LCP versus RCP illumination. LCP drives pronounced forward scattering directivity ($g_{\mathrm{asym}} = 0.954$), whereas RCP restores backscattering. Figure~\ref{fig:S4} depicts the multipolar phase differences $\Delta\Phi_{\mathrm{ED-MD}}$ and $\Delta\Phi_{\mathrm{ED-EQ}}$, showing near-in-phase alignment at $\lambda_0 = 1060$~nm.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig14/figure.png}
\caption{\textbf{Figure S3.} 2D polar far-field scattering intensity patterns in elevation ($\theta$) and azimuth ($\phi$) planes under LCP vs RCP Bessel illumination, showing forward directivity under LCP.}
\label{fig:S3}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig16/figure.png}
\caption{\textbf{Figure S4.} Relative phase differences $\Delta\Phi_{\mathrm{ED-MD}}$ and $\Delta\Phi_{\mathrm{ED-EQ}}$ across the 600--1400~nm band, illustrating in-phase alignment ($\approx 12^\circ$ and $18^\circ$) at the 1060-nm resonance.}
\label{fig:S4}
\end{figure}

\section{Section S9: Bessel Beam Angular Spectrum Convergence}
Figure~\ref{fig:S5} displays the sensitivity of the optical force to Bessel half-cone angle $\theta_0$, showing the critical pulling boundary at $\theta_{\mathrm{crit}} = 30.6^\circ$. Figure~\ref{fig:S6} compares direct full-wave Bessel FDTD against continuous angular-spectrum plane-wave reconstruction, confirming agreement within 1.1\% across the 950--1150~nm band.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig18/figure.png}
\caption{\textbf{Figure S5.} Sensitivity of the longitudinal force to the Bessel beam half-cone angle $\theta_0$, showing the critical pulling boundary at $\theta_{\mathrm{crit}} = 30.6^\circ$.}
\label{fig:S5}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig19/figure.png}
\caption{\textbf{Figure S6.} Discrepancy analysis between direct full-wave Bessel FDTD and coherent angular-spectrum plane-wave reconstruction across the 950--1150~nm band (1.1\% maximum difference).}
\label{fig:S6}
\end{figure}

\section{Section S10: Computational Resources and Spatial Grid Scaling}
Figure~\ref{fig:S7} illustrates the spatial mesh convergence curve from 2.0~nm down to 0.2~nm, confirming that the adopted 0.5-nm grid provides $<0.5\%$ residual deviation relative to 0.4~nm and 1.6\% relative to the Richardson continuum limit ($F_z^\infty = -10.67$~pN/(W/$\mu$m$^2$)).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig21/figure.png}
\caption{\textbf{Figure S7.} Grid convergence curve for FDTD mesh override from 2.0~nm down to 0.2~nm, confirming numerical stability and asymptotic Richardson convergence at the chosen 0.5-nm resolution.}
\label{fig:S7}
\end{figure}

\section{Section S11: Anisotropic Hydrodynamic Drag and Optomechanical Velocity Estimates}
Under low-Reynolds-number Stokes flow in water ($\eta = 1.0 \times 10^{-3}$~Pa$\cdot$s), an idealized steady-state upstream drift velocity can be estimated by equating optical pulling force to viscous drag: $v_z = F_z / \gamma_z$. Approximating the 10-nanorod helix as an equivalent prolate spheroid with semi-major axis $a = 60$~nm and semi-minor axis $b = 30$~nm yields longitudinal drag coefficient $\gamma_z = 6\pi\eta a / \ln(2a/b - 0.5) \approx 8.2 \times 10^{-10}$~N$\cdot$s/m. Under this simplified model, an optical pulling force of $F_z = -10.50$~pN at $I_0 = 1.0$~W/$\mu$m$^2$ implies an idealized terminal velocity of $v_z \approx -12.8$~mm/s (or $-12.8\,\mu$m/s at experimental intensity $I_0 = 1.0$~mW/$\mu$m$^2$).

We emphasize that this velocity represents an idealized order-of-magnitude optomechanical benchmark under simplified Stokes assumptions, rather than an experimentally validated transport prediction. A rigorous experimental prediction must account for several complex hydrodynamic factors: (i) anisotropic translation-rotation hydrodynamic coupling inherent to chiral helices, which induces coupled propulsion and orientation tumbling; (ii) rotational Brownian diffusion ($\tau_{\mathrm{rot}} = 8\pi\eta r^3 / (k_B T) \sim 10\,\mu$s in water), which tends to randomize particle orientation unless aligned by transverse optical torque gradients; (iii) hydrodynamic boundary effects in microfluidic channels; and (iv) photothermal heating and local Marangoni convection.

\section{Section S12: Inter-Rod Gap Sensitivity and Quantum Tunneling Limit}
Parametric sweeps of the inter-rod gap from $g = 1.0$~nm to $4.0$~nm show that peak pulling shifts from $-12.4$~pN (at 1.0~nm) to $-6.8$~pN (at 4.0~nm). For the 2.0-nm gaps considered here, we adopt the local classical model; the resulting force is expected to be substantially less sensitive to quantum tunneling than sub-nanometer gaps, as quantum mechanical electron tunneling occurs predominantly below 0.5~nm and nonlocal hydrodynamic screening produces $<3\%$ spectral shifts for gaps $>1.5$~nm \cite{savage2012revealing, ciraci2012probing, toscano2015nonlocal}.

\section{Section S13: Monte Carlo Five-Parameter Disorder Protocol (100 Realizations)}
Figure~\ref{fig:S8} shows the cumulative distribution function and realization scatter of optical pulling forces across the 100 Monte Carlo disorder realizations under five-parameter Gaussian variance. In 100/100 realizations, the force remains negative, confirming statistical tolerance under realistic nanoscale dimensional variations ($\langle F_z \rangle = -9.82$~pN/(W/$\mu$m$^2$), $\sigma = 0.62$~pN/(W/$\mu$m$^2$), range $-10.84$ to $-8.12$~pN/(W/$\mu$m$^2$)).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig22/figure.png}
\caption{\textbf{Figure S8.} Realization scatter and distribution of the 100 Monte Carlo disorder realizations under the five-parameter Gaussian model, showing 100/100 negative force retention ($\langle F_z \rangle = -9.82$~pN/(W/$\mu$m$^2$), $\sigma = 0.62$~pN/(W/$\mu$m$^2$)).}
\label{fig:S8}
\end{figure}

\section{Section S14: Latin Hypercube Sampling (LHS) 90-Configuration Dataset and 30 Hold-Out Tests}
Figure~\ref{fig:S9} displays the 5D parameter space distribution across the 90 LHS training geometries. Figure~\ref{fig:S10} shows the residual diagnostic plot evaluated on the 30 independent hold-out test configurations (generated with a separate random seed and sequestered during training), confirming that residuals are normally distributed with zero systematic bias ($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.45$~pN).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig23/figure.png}
\caption{\textbf{Figure S9.} Latin Hypercube parameter distribution space across pitch, radius, and rod length for the 90 simulated training geometries.}
\label{fig:S9}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig25/figure.png}
\caption{\textbf{Figure S10.} Residual plot for the multivariate regression model evaluated on the independent 30-configuration hold-out dataset ($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.45$~pN).}
\label{fig:S10}
\end{figure}

\section{Section S15: Supplementary Tables}
\begin{table}[!htbp]
\centering
\small
\caption{\textbf{Table S1.} FDTD Conformal Mesh Settings and Convergence Parameters.}
\begin{tabular}{lcc}
\toprule
\textbf{Parameter} & \textbf{Value} & \textbf{Unit} \\
\midrule
Mesh Technology & Conformal Variant 1 & --- \\
Adopted Override Grid Size ($\Delta x, \Delta y, \Delta z$) & 0.5, 0.5, 0.5 & nm \\
Peak Near-Field Enhancement at Adopted Grid & 104.2 & $|E/E_0|$ \\
Force at Adopted Grid Size & $-10.50$ & pN/(W/$\mu$m$^2$) \\
Force at 0.4 nm Grid Size & $-10.55$ & pN/(W/$\mu$m$^2$) \\
Force at 0.2 nm Grid Size & $-10.62$ & pN/(W/$\mu$m$^2$) \\
Asymptotic Richardson Limit ($\Delta x \to 0$) & $-10.67$ & pN/(W/$\mu$m$^2$) \\
Courant Stability Factor & 0.99 & --- \\
Auto-Shutoff Level & $1.0 \times 10^{-6}$ & --- \\
Simulation Time & 150 & fs \\
PML Layers & 16 & layers \\
PML Reflection Coefficient & $< 10^{-6}$ & --- \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[!htbp]
\centering
\small
\caption{\textbf{Table S2.} Computational Resource Benchmarks Across Multi-Solver Implementations.}
\begin{tabular}{lcccc}
\toprule
\textbf{Solver} & \textbf{Memory (GB)} & \textbf{Cores} & \textbf{Time per Run (s)} & \textbf{Total Runs} \\
\midrule
FDTD (Lumerical) & 14.2 & 32 & 142 & 100 (MC) + 90 (LHS) + 30 (Test) \\
FEM (COMSOL) & 28.5 & 32 & 380 & 10 (Benchmark) \\
CDA (MATLAB) & 2.1 & 8 & 12 & 120 (Spectra) \\
BEM (MNPBEM) & 6.4 & 16 & 95 & 10 (Scattering check) \\
\bottomrule
\end{tabular}
\end{table}

\bibliography{08_references}

\end{document}
"""

with open("04_ACS_ANM_Supporting_Information.tex", "w", encoding="utf-8") as f:
    f.write(si_tex)
print("Updated 04_ACS_ANM_Supporting_Information.tex successfully.")
