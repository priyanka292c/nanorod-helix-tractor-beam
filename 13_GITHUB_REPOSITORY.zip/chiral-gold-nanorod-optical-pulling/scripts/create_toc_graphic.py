import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.path import Path

def generate_acs_toc():
    work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
    
    # Standard ACS TOC dimensions: 3.25 inches x 1.75 inches (8.25 cm x 4.45 cm)
    fig = plt.figure(figsize=(3.25, 1.75), dpi=600)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 3.25)
    ax.set_ylim(0, 1.75)
    ax.axis('off')

    # Background subtle elegant styling
    bg = patches.Rectangle((0, 0), 3.25, 1.75, facecolor='#FAFBFD', edgecolor='#1F3A60', linewidth=1.0)
    ax.add_patch(bg)

    # Header banner
    banner = patches.Rectangle((0, 1.48), 3.25, 0.27, facecolor='#0D233A', edgecolor='none')
    ax.add_patch(banner)
    ax.text(1.625, 1.615, 'CHIRAL PLASMONIC TRACTOR BEAM', color='white', 
            fontsize=8.8, fontweight='bold', ha='center', va='center', fontfamily='sans-serif')

    # 1. Left Section: Helical Nanorod Architecture & Bessel Beam
    # Draw helical gold rods
    theta = np.linspace(0, 2.5 * np.pi, 10)
    z_coords = np.linspace(0.28, 1.25, 10)
    r_coords = np.linspace(0.18, 0.28, 10)
    x_center = 0.52
    
    # Incident Bessel beam conical cone representation
    cone_pts = np.array([[x_center - 0.35, 0.22], [x_center + 0.35, 0.22], [x_center, 1.35]])
    cone = patches.Polygon(cone_pts, facecolor='#E6F0FA', edgecolor='#2B6CB0', linestyle='--', linewidth=0.6, alpha=0.55)
    ax.add_patch(cone)
    
    # Draw 10 gold nanorods
    for i in range(10):
        xc = x_center + r_coords[i] * np.cos(theta[i]) * 0.75
        yc = z_coords[i]
        # rod shape (tilted rectangle)
        angle_deg = 45 + 15 * np.sin(theta[i])
        rod = patches.Ellipse((xc, yc), width=0.14, height=0.045, angle=angle_deg,
                              facecolor='#D4AF37', edgecolor='#8C6D1F', linewidth=0.6, zorder=4)
        ax.add_patch(rod)
        
    ax.text(x_center, 0.15, 'LCP Bessel Beam\n($\\theta_0 = 49.5^\\circ$)', 
            fontsize=6.0, fontweight='bold', color='#1A365D', ha='center', va='center', multialignment='center')

    # Arrow 1: Forward Coupling
    ax.annotate('', xy=(1.08, 0.85), xytext=(0.86, 0.85),
                arrowprops=dict(arrowstyle="-|>", color='#0D233A', lw=1.2, mutation_scale=8))

    # 2. Middle Section: Multipolar Forward-Scattering Interference
    mid_box = patches.FancyBboxPatch((1.12, 0.26), 0.95, 1.10, boxstyle="round,pad=0.02,rounding_size=0.06",
                                    facecolor='#FFFFFF', edgecolor='#CBD5E0', linewidth=0.7)
    ax.add_patch(mid_box)
    
    ax.text(1.595, 1.24, 'Multipolar Interference', fontsize=6.6, fontweight='bold', color='#0D233A', ha='center', va='center')
    
    # Schematic multipoles
    ax.text(1.595, 1.07, 'ED + MD + EQ in-phase', fontsize=5.8, color='#2B6CB0', fontweight='bold', ha='center', va='center')
    ax.text(1.595, 0.93, '$\\Delta\\Phi_{\\mathrm{ED-MD}} \\approx 12^\\circ$', fontsize=5.6, color='#4A5568', ha='center', va='center')
    
    # Forward scattering directivity metric
    gasym_box = patches.FancyBboxPatch((1.18, 0.33), 0.83, 0.46, boxstyle="round,pad=0.02,rounding_size=0.04",
                                       facecolor='#EDF2F7', edgecolor='#4A5568', linewidth=0.5)
    ax.add_patch(gasym_box)
    ax.text(1.595, 0.65, 'Forward Scattering', fontsize=5.6, fontweight='bold', color='#1A202C', ha='center')
    ax.text(1.595, 0.49, '$g_{\\mathrm{asym}} = 0.954$', fontsize=7.2, fontweight='bold', color='#2F855A', ha='center')
    ax.text(1.595, 0.37, '(Threshold: $g_{\\mathrm{crit}} = 0.721$)', fontsize=4.8, color='#718096', ha='center')

    # Arrow 2: To Force Output
    ax.annotate('', xy=(2.30, 0.85), xytext=(2.11, 0.85),
                arrowprops=dict(arrowstyle="-|>", color='#0D233A', lw=1.2, mutation_scale=8))

    # 3. Right Section: Giant Optical Pulling & Polarization Switching
    right_box = patches.FancyBboxPatch((2.34, 0.26), 0.83, 1.10, boxstyle="round,pad=0.02,rounding_size=0.06",
                                      facecolor='#FFFFFF', edgecolor='#CBD5E0', linewidth=0.7)
    ax.add_patch(right_box)

    # Negative Force Pulling Badge
    ax.text(2.755, 1.24, 'Optical Pulling Force', fontsize=6.6, fontweight='bold', color='#0D233A', ha='center', va='center')
    
    f_badge = patches.FancyBboxPatch((2.38, 0.76), 0.75, 0.38, boxstyle="round,pad=0.02,rounding_size=0.05",
                                     facecolor='#FFF5F5', edgecolor='#E53E3E', linewidth=0.8)
    ax.add_patch(f_badge)
    ax.text(2.755, 0.98, '$-10.50$ pN/(W/$\\mu$m$^2$)', fontsize=7.2, fontweight='bold', color='#C53030', ha='center', va='center')
    ax.text(2.755, 0.83, 'Bandwidth: 875–1160 nm', fontsize=5.2, color='#742A2A', fontweight='bold', ha='center', va='center')
    
    # Polarization Switch
    pol_box = patches.FancyBboxPatch((2.38, 0.32), 0.75, 0.38, boxstyle="round,pad=0.02,rounding_size=0.05",
                                     facecolor='#EBF8FF', edgecolor='#3182CE', linewidth=0.6)
    ax.add_patch(pol_box)
    ax.text(2.755, 0.58, 'Helicity Reversible', fontsize=5.6, fontweight='bold', color='#2B6CB0', ha='center')
    ax.text(2.755, 0.43, 'LCP: Pulling ($-10.5$ pN)\nRCP: Pushing ($+1.15$ pN)', fontsize=4.8, color='#2C5282', ha='center', multialignment='center')

    # Save to files
    out_png = os.path.join(work_dir, "TOC_Graphic.png")
    out_pdf = os.path.join(work_dir, "TOC_Graphic.pdf")
    out_jpg = os.path.join(work_dir, "TOC_Graphic.jpg")
    out_tif = os.path.join(work_dir, "TOC_Graphic.tif")
    
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.02)
    plt.savefig(out_pdf, bbox_inches='tight', pad_inches=0.02)
    plt.savefig(out_jpg, dpi=600, bbox_inches='tight', pad_inches=0.02)
    plt.savefig(out_tif, dpi=600, bbox_inches='tight', pad_inches=0.02)
    plt.close()
    
    print(f"Generated TOC Graphic: {out_png} ({os.path.getsize(out_png)} bytes)")

if __name__ == "__main__":
    generate_acs_toc()
