import os
import re

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
si_path = os.path.join(work_dir, "04_ACS_ANM_Supporting_Information.tex")

with open(si_path, "r", encoding="utf-8") as f:
    content = f.read()

# Extract all figures from Section S15
pos_s15 = content.find(r'\section{Section S15: Supplementary Figures}')
if pos_s15 == -1:
    print("Could not find Section S15!")
    exit(1)

content_main = content[:pos_s15].rstrip()
figures_block = content[pos_s15:]

# Extract the individual figures
fig_pattern = re.compile(r'(\\begin\{figure\}.*?\\end\{figure\})', re.DOTALL)
figs = fig_pattern.findall(figures_block)
print(f"Extracted {len(figs)} figures from SI.")

# Clean figure strings
clean_figs = []
for f_str in figs:
    f_clean = re.sub(r'\\begin\{figure\}(\[[^\]]*\])?', r'\\begin{figure}[!htbp]', f_str)
    f_clean = re.sub(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}', r'\\includegraphics[width=0.68\\textwidth,height=0.32\\textheight,keepaspectratio]{\1}', f_clean)
    clean_figs.append(f_clean)

# Also extract tables block if any exists after figures
pos_tables = figures_block.find(r'\section{Section S16: Supplementary Tables}')
tables_block = ""
if pos_tables != -1:
    tables_block = figures_block[pos_tables:]

# Define in-line insertion for SI figures
# Fig S1 (clean_figs[0]) -> Section S1
content_main = content_main.replace(
    r"(\pm 10\% chirp, $\delta p = 24$~nm).",
    r"(\pm 10\% chirp, $\delta p = 24$~nm)." + "\n\n" + clean_figs[0]
)

# Fig S2 (clean_figs[1]) -> Section S3
content_main = content_main.replace(
    r"where $A = 0.25$ and $L_{\mathrm{eff}} = 10.0$~nm.",
    r"where $A = 0.25$ and $L_{\mathrm{eff}} = 10.0$~nm." + "\n\n" + clean_figs[1]
)

# Fig S3 & S4 (clean_figs[2], clean_figs[3]) -> Section S8
content_main = content_main.replace(
    r"which exceeds the critical threshold $g_{\mathrm{crit}} = 0.721$.",
    r"which exceeds the critical threshold $g_{\mathrm{crit}} = 0.721$." + "\n\n" + clean_figs[2] + "\n\n" + clean_figs[3]
)

# Fig S5 (clean_figs[4]) -> Section S9
content_main = content_main.replace(
    r"$M = 24$ was selected for all reported simulations, ensuring complete numerical convergence.",
    r"$M = 24$ was selected for all reported simulations, ensuring complete numerical convergence." + "\n\n" + clean_figs[4]
)

# Fig S6 (clean_figs[5]) -> Section S10
content_main = content_main.replace(
    r"enabling rapid execution of the 90-configuration Latin Hypercube Sampling sweep in under 5 minutes.",
    r"enabling rapid execution of the 90-configuration Latin Hypercube Sampling sweep in under 5 minutes." + "\n\n" + clean_figs[5]
)

# Fig S7 (clean_figs[6]) -> Section S12
content_main = content_main.replace(
    r"Furthermore, because all gaps exceed 0.5~nm, non-local quantum electron tunneling effects are negligible .",
    r"Furthermore, because all gaps exceed 0.5~nm, non-local quantum electron tunneling effects are negligible." + "\n\n" + clean_figs[6]
)

# Fig S8 (clean_figs[7]) -> Section S13
content_main = content_main.replace(
    r"yielding $\langle F_z \rangle = -8.92 \pm 1.18$~pN/(W/$\mu$m$^2$).",
    r"yielding $\langle F_z \rangle = -8.92 \pm 1.18$~pN/(W/$\mu$m$^2$)." + "\n\n" + clean_figs[7]
)

# Fig S9 & S10 (clean_figs[8], clean_figs[9]) -> Section S14
content_main = content_main.replace(
    r"($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.488$~pN).",
    r"($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.488$~pN)." + "\n\n" + clean_figs[8] + "\n\n" + clean_figs[9]
)

# Update contents list to reflect in-line figures
content_main = content_main.replace(
    r"\item \textbf{Section S15:} Supplementary Figures (Figures S1--S10)",
    r"% Figures S1--S10 integrated in-line within respective Sections S1--S14"
)

# Re-attach tables block if any, then end document
if tables_block:
    new_si = content_main + "\n\n" + tables_block
else:
    new_si = content_main + "\n\n\\end{document}\n"

with open(si_path, "w", encoding="utf-8") as f:
    f.write(new_si)

print("SUCCESS: 04_ACS_ANM_Supporting_Information.tex refactored with all figures in-line!")
