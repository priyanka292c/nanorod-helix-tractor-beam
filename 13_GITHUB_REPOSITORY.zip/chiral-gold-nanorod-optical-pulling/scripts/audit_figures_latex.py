import re

with open('01_ACS_ANM_Manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# find figures
pattern = r'\\begin\{figure\}.*?\\includegraphics\[.*?\]\{(.*?)\}.*?\\caption\{(.*?)\}.*?\\label\{(.*?)\}.*?\\end\{figure\}'
figs = re.findall(pattern, text, re.DOTALL)
print(f"Total figures found in 01_ACS_ANM_Manuscript.tex: {len(figs)}")
for i, (path, cap, lab) in enumerate(figs, 1):
    cap_clean = re.sub(r'\s+', ' ', cap).strip()[:80]
    print(f"[{i:02d}] Graphic: {path:<25} | Label: {lab:<12} | Caption: {cap_clean}...")

print("\n--- Hardcoded Figure X in text ---")
refs = re.findall(r'Figure\s+(\d+)', text)
print(f"Figure numbers mentioned in text: {sorted(list(set(refs)), key=lambda x: int(x))}")

print("\n--- Figure references with \\ref{} ---")
tex_refs = re.findall(r'\\ref\{(fig:[^}]+)\}', text)
print(f"Tex ref labels: {set(tex_refs)}")
