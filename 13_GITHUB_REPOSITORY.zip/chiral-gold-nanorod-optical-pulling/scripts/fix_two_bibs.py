import os
import re

bib_file = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\08_references.bib"

with open(bib_file, "r", encoding="utf-8") as f:
    text = f.read()

dogariu_clean = """@article{dogariu2013optically,
  author    = {Dogariu, Aristide and Sukhov, Sergey and S{\\'a}enz, Juan Jos{\\'e}},
  title     = {Optically induced 'negative forces'},
  journal   = {Nature Photonics},
  volume    = {7},
  pages     = {24--27},
  year      = {2013},
  doi       = {10.1038/nphoton.2012.315}
}"""

yin_clean = """@article{yin2013interpreting,
  author    = {Yin, Xinghui and Sch{\\"a}ferling, Martin and Metzger, Bernd and Giessen, Harald},
  title     = {Interpreting chiral nanophotonic spectra: The plasmonic Born--Kuhn model},
  journal   = {Nano Letters},
  volume    = {13},
  pages     = {6238--6243},
  year      = {2013},
  doi       = {10.1021/nl403705k}
}"""

text = re.sub(r'@article\{dogariu2013optically,[\s\S]*?doi\s*=\s*\{10\.1038/nphoton\.2012\.315\}\s*\}', dogariu_clean, text)
text = re.sub(r'@article\{yin2013interpreting,[\s\S]*?doi\s*=\s*\{10\.1021/nl403705k\}\s*\}', yin_clean, text)

with open(bib_file, "w", encoding="utf-8") as f:
    f.write(text)

print("Updated dogariu and yin successfully.")
