import re

bib_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\08_references.bib"
with open(bib_path, "r", encoding="utf-8") as f:
    text = f.read()

# Fix garcia2011nonlocal
text = text.replace(
    "author    = {Garc{'i},",
    "author    = {Garc{\\'i}a de Abajo, F. J.},"
)

# Parse each entry and check braces
entries = re.split(r'\n@', text)
clean_blocks = []
for block in entries:
    if not block.strip():
        continue
    # Check brace count
    open_b = block.count('{')
    close_b = block.count('}')
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', block.strip().lstrip('@'))
    key = m.group(2) if m else "UNKNOWN"
    if open_b != close_b:
        print(f"Brace mismatch in key [{key}]: open={open_b}, close={close_b}")
    else:
        # print(f"Key [{key}]: OK")
        pass
    clean_blocks.append(block.strip())

with open(bib_path, "w", encoding="utf-8") as f:
    f.write("% 08_references.bib\n\n")
    for b in clean_blocks:
        if not b.startswith("@"):
            f.write("@" + b + "\n\n")
        else:
            f.write(b + "\n\n")

print(f"Updated {bib_path} successfully.")
