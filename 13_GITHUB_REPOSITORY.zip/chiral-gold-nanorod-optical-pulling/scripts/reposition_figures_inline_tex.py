import os
import re

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
src_path = os.path.join(work_dir, "chiral-gold-nanorod-optical-pulling", "manuscript", "latex", "01_ACS_ANM_Manuscript.tex")
if not os.path.exists(src_path):
    src_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")

with open(src_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Extract all tables
tables = {}
table_pattern = re.compile(r'(\\begin\{table\}.*?\\end\{table\})', re.DOTALL)
found_tables = table_pattern.findall(content)
for tbl in found_tables:
    m = re.search(r'\\label\{(tab:[^}]+)\}', tbl)
    if m:
        tables[m.group(1)] = tbl

print(f"Extracted {len(tables)} tables: {list(tables.keys())}")

# 2. Extract all figures
figures = {}
figure_pattern = re.compile(r'(\\begin\{figure\}.*?\\end\{figure\})', re.DOTALL)
found_figures = figure_pattern.findall(content)
for fig in found_figures:
    m = re.search(r'\\label\{(fig:[^}]+)\}', fig)
    if m:
        figures[m.group(1)] = fig

print(f"Extracted {len(figures)} figures: {list(figures.keys())}")

# 3. Remove trailing tables and figures section from original content
pos_tables = content.find(r'\section*{Tables}')
if pos_tables != -1:
    content_main = content[:pos_tables]
else:
    content_main = content

content_main = content_main.rstrip()

# Ensure each figure has clean sizing: width=0.68\textwidth, height=0.32\textheight, keepaspectratio
def clean_figure(fig_str):
    fig_str = re.sub(r'\\begin\{figure\}(\[[^\]]*\])?', r'\\begin{figure}[!htbp]', fig_str)
    fig_str = re.sub(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}', r'\\includegraphics[width=0.68\\textwidth,height=0.32\\textheight,keepaspectratio]{\1}', fig_str)
    return fig_str

def clean_table(tbl_str):
    tbl_str = re.sub(r'\\begin\{table\}(\[[^\]]*\])?', r'\\begin{table}[!htbp]', tbl_str)
    return tbl_str

clean_figs = {k: clean_figure(v) for k, v in figures.items()}
clean_tbls = {k: clean_table(v) for k, v in tables.items()}

# Exact string replacements:
replacements = [
    # Fig 01
    ("surpassing this threshold by $\\Delta g = 0.233$.",
     "surpassing this threshold by $\\Delta g = 0.233$.\n\n" + clean_figs['fig:fig01']),
     
    # Table 1 and Fig 02
    ("broadening the resonant interaction bandwidth.",
     "broadening the resonant interaction bandwidth.\n\n" + clean_tbls['tab:geom'] + "\n\n" + clean_figs['fig:fig02']),
     
    # Fig 03
    ("guaranteeing the validity of local classical electrodynamics.",
     "guaranteeing the validity of local classical electrodynamics.\n\n" + clean_figs['fig:fig03']),
     
    # Fig 04 & Table 2
    ("producing the required negative momentum recoil.",
     "producing the required negative momentum recoil.\n\n" + clean_tbls['tab:opt_params'] + "\n\n" + clean_figs['fig:fig04']),
     
    # Fig 05 & Table 3
    ("and effective mean free path $L_{\\mathrm{eff}} = 4V/S \\approx 10$~nm.",
     "and effective mean free path $L_{\\mathrm{eff}} = 4V/S \\approx 10$~nm.\n\n" + clean_tbls['tab:fdtd_params'] + "\n\n" + clean_figs['fig:fig05']),
     
    # Fig 06
    ("requires 3D helical structural chirality.",
     "requires 3D helical structural chirality.\n\n" + clean_figs['fig:fig06']),
     
    # Fig 07
    ("expanding the continuous pulling bandwidth to 285~nm (935--1220~nm).",
     "expanding the continuous pulling bandwidth to 285~nm (935--1220~nm).\n\n" + clean_figs['fig:fig07']),
     
    # Fig 08, Fig 09, Table 7
    ("Q_{\\mathrm{pr}} = \\frac{-10.5 \\times 10^{-12}\\,\\mathrm{N}}{\\left(\\frac{1.333 \\times 3.318 \\times 10^{-3}\\,\\mathrm{W}}{3.0 \\times 10^8\\,\\mathrm{m/s}}\\right)} = \\frac{-10.5 \\times 10^{-12}}{1.474 \\times 10^{-11}} = -0.712\n\\label{eq:qpr_calc}\n\\end{equation}",
     "Q_{\\mathrm{pr}} = \\frac{-10.5 \\times 10^{-12}\\,\\mathrm{N}}{\\left(\\frac{1.333 \\times 3.318 \\times 10^{-3}\\,\\mathrm{W}}{3.0 \\times 10^8\\,\\mathrm{m/s}}\\right)} = \\frac{-10.5 \\times 10^{-12}}{1.474 \\times 10^{-11}} = -0.712\n\\label{eq:qpr_calc}\n\\end{equation}\n\n" + clean_figs['fig:fig08'] + "\n\n" + clean_figs['fig:fig09'] + "\n\n" + clean_tbls['tab:pol_contrast']),
     
    # Fig 10 & Table 6
    ("transverse plasmonic wavelength in water.",
     "transverse plasmonic wavelength in water.\n\n" + clean_tbls['tab:geom_opt'] + "\n\n" + clean_figs['fig:fig10']),
     
    # Fig 11 (Fig13)
    ("enabling polarization-controlled directional switching.",
     "enabling polarization-controlled directional switching.\n\n" + clean_figs['fig:fig13']),
     
    # Fig 12 (Fig15) & Table 8
    ("as plotted in Figure 17.",
     "as plotted in Figure 17.\n\n" + clean_tbls['tab:stat_val'] + "\n\n" + clean_figs['fig:fig15']),
     
    # Fig 13 (Fig17)
    ("excessive beam diffraction loss.",
     "excessive beam diffraction loss.\n\n" + clean_figs['fig:fig17']),
     
    # Fig 14 (Fig20) & Table 4, 5
    ("is an authentic electrodynamic phenomenon.",
     "is an authentic electrodynamic phenomenon.\n\n" + clean_tbls['tab:solver_benchmark'] + "\n\n" + clean_tbls['tab:mesh_conv'] + "\n\n" + clean_figs['fig:fig20']),
     
    # Fig 15 (Fig22) & Table 9
    ("proving extraordinary structural robustness.",
     "proving extraordinary structural robustness.\n\n" + clean_tbls['tab:mc_tolerance'] + "\n\n" + clean_figs['fig:fig22']),
     
    # Fig 16 (Fig24)
    ("predictor for tractor-beam performance.",
     "predictor for tractor-beam performance.\n\n" + clean_figs['fig:fig24']),
     
    # Table 10
    ("when multipolar interference is rationally engineered.",
     "when multipolar interference is rationally engineered.\n\n" + clean_tbls['tab:lit_comparison']),
     
    # Fig 17 (Fig27) & Table 11
    ("in aqueous suspension.",
     "in aqueous suspension.\n\n" + clean_figs['fig:fig27'] + "\n\n" + clean_tbls['tab:fab_pathways'])
]

new_content = content_main
for target, repl in replacements:
    if target in new_content:
        new_content = new_content.replace(target, repl, 1)
        print(f"Successfully replaced anchor: {target[:40]}...")
    else:
        print(f"WARNING: Anchor not found: {target[:40]}...")

if r'\bibliography{08_references}' not in new_content:
    new_content += '\n\n\\bibliography{08_references}\n'

new_content += '\n\\end{document}\n'

out_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(new_content)

print(f"SUCCESS: All 17 figures and 11 tables positioned in-line in 01_ACS_ANM_Manuscript.tex!")
