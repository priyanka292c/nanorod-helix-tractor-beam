import os
import docx
from docx.shared import Inches, Pt, RGBColor

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

def build_cover_letter_docx():
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)
        
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    
    p = doc.add_paragraph()
    r = p.add_run("Professor Xing Yi Ling\nEditor-in-Chief, ACS Applied Nano Materials\nAmerican Chemical Society\nOctober 10, 2026")
    r.bold = True
    p.paragraph_format.space_after = Pt(14)
    
    p_subj = doc.add_paragraph()
    r_subj = p_subj.add_run("Subject: Submission of Original Research Article — “Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”")
    r_subj.bold = True
    p_subj.paragraph_format.space_after = Pt(12)
    
    p_sal = doc.add_paragraph("Dear Professor Ling and Editorial Board,")
    p_sal.paragraph_format.space_after = Pt(8)
    
    body_paragraphs = [
        "We are pleased to submit our original research manuscript entitled “Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference” for publication as a full-length research article in ACS Applied Nano Materials.",
        "The manuscript is well aligned with the scope of ACS Applied Nano Materials because it connects an engineered metallic nanomaterial architecture with a quantified optomechanical function and a mechanistic plasmonic design framework. Optical tractor beams—light fields that pull nanoscale objects against the photon momentum vector—have been historically confined to idealized, non-absorbing dielectric particles. Implementing optical pulling in plasmonic metallic nanostructures has remained an elusive goal because noble metals suffer from intrinsic ohmic dissipation, conveying a mandatory forward radiation push. Our manuscript directly addresses this challenge by introducing a rationally engineered metallic architecture: 3D helical superstructures of high-aspect-ratio gold nanorods (L = 60 nm, D = 15 nm). We demonstrate how collective plasmonic hybridization in these metamolecules overcomes the absorption barrier to deliver sustained, polarization-switchable optomechanical pulling.",
        "Key Novelties and Quantitative Advances:",
        "1. Optical Pulling in Lossy Plasmonic Assemblies: We demonstrate that a right-handed tapered-chirped hybrid helix (RH-TCH-CPH) immersed in water and illuminated by a non-paraxial left-circularly polarized (LCP) Bessel beam (θ0 = 49.5°) produces a peak pulling force of -10.50 pN/(W/μm²) at λ0 = 1060 nm, corresponding to a high negative radiation-pressure efficiency of Qpr = -0.712.",
        "2. Broadband Performance: The assembly delivers a continuous negative-force pulling bandwidth of 285 nm (875–1160 nm), providing broad spectral flexibility across the near-infrared operating window.",
        "3. Generalized Multipolar Forward-Scattering Interference: Phase-resolved Cartesian multipole decomposition demonstrates that near-in-phase co-excitation of electric dipole, magnetic dipole, and electric quadrupole moments (ΔΦ_ED-MD ≈ 12°, ΔΦ_ED-EQ ≈ 18°) suppresses backward scattering (analogous to generalized Kerker conditions in lossy multiparticle systems), driving the forward asymmetry parameter to gasym = 0.954, well above the critical analytical threshold gcrit,abs = 0.721.",
        "4. Polarization Selectivity: Switching the illumination handedness to right-circular polarization (RCP) reverses the force to forward pushing (+1.15 pN/(W/μm²)), providing polarity-reversible optical pulling (Cchiral = 1.00), providing computational design principles for future experimental studies of polarization-selective directional manipulation and sorting.",
        "5. Rigorous Multi-Method Computational Validation: The electrodynamic response and optical pulling force are cross-checked using FDTD (Maxwell Stress Tensor), FEM (COMSOL Multiphysics, 2.7% agreement), and Coupled Dipole Approximation (CDA, 5.5% agreement) calculations, with BEM used to independently verify far-field scattering asymmetry (gasym, 3.8% agreement), and direct full-wave Bessel FDTD compared against angular-spectrum reconstruction (1.1% discrepancy).",
        "6. Fabrication Robustness and Statistical Modeling: A 100-run Monte Carlo tolerance study shows pulling retention in 100/100 realizations under simultaneous 5-parameter Gaussian disorder (>97.0% lower confidence bound). Linear regression across 90 Latin Hypercube configurations identifies circular dichroism as a robust far-field computational proxy (R² = 0.947, 5-fold CV R²_CV = 0.931, external hold-out R²_test = 0.937).",
        "Why This Work Matters for Applied Nano Materials: This study is not merely a numerical parameter optimization; it establishes the fundamental physical chain connecting gold nanorod synthesis, chiral self-assembly (potentially compatible with DNA-origami-assisted assembly or related nanofabrication strategies), multipolar scattering control, and non-contact nanomechanical actuation. This framework provides design principles that may motivate future experimental studies of polarization-selective chiral manipulation, optomechanical microfluidics, and light-driven nanomechanical systems.",
        "Supporting Information containing the detailed geometry parameterization, solver settings, multipolar analysis, mesh convergence, Bessel-beam validation, disorder analysis, and statistical regression data is provided.",
        "This manuscript has not been published previously and is not under consideration elsewhere. All authors have approved the manuscript and agree with its submission to ACS Applied Nano Materials.",
        "Thank you very much for your time and consideration of our work."
    ]
    
    for bp in body_paragraphs:
        p = doc.add_paragraph(bp)
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing = 1.15
        
    p_close = doc.add_paragraph("Sincerely yours,\n\nRam Soorat, Ph.D. (Corresponding Author)\nAssistant Professor, School of Technology\nWoxsen University, Hyderabad, Telangana 502345, India\nEmail: rsoorat@gmail.com\n\nOn behalf of all co-authors:\nPriyanka (University of Delhi)\nRajveer Singh (Atma Ram Sanatan Dharma College, University of Delhi)\nNarender Kumar (Sri Venkateswara College, University of Delhi)\nSandeep (Deen Dayal Upadhyaya College, University of Delhi)")
    p_close.paragraph_format.space_before = Pt(12)
    
    out_path = os.path.join(work_dir, "06_ACS_ANM_Cover_Letter.docx")
    doc.save(out_path)
    print(f"Saved {out_path} ({os.path.getsize(out_path)} bytes)")

if __name__ == "__main__":
    build_cover_letter_docx()
