import os

out_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\cover_letter.tex"

content = r"""\documentclass[11pt,letterpaper]{article}

\usepackage{geometry}
\geometry{letterpaper, margin=1in}
\usepackage{hyperref}
\usepackage{setspace}
\usepackage{xcolor}

\begin{document}
\thispagestyle{empty}

\noindent
\textbf{Professor Kirk S. Schanze} \\
Editor-in-Chief, \textit{ACS Applied Nano Materials} \\
American Chemical Society \\
\today

\vspace{1em}
\noindent
\textbf{Subject:} Submission of Original Research Article: \textit{“Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”}

\vspace{1em}
\noindent
Dear Professor Schanze and Editorial Board,

\vspace{0.8em}
We are pleased to submit our original research manuscript entitled \textbf{“Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”} for publication as a full-length research article in \textit{ACS Applied Nano Materials}.

\paragraph{Scope and Applied Nanomaterial Alignment:}
\textit{ACS Applied Nano Materials} serves as the premier forum for engineering functional nanomaterials tailored for advanced physical applications. Optical tractor beams---light fields that pull nanoscale objects against the photon momentum vector---have been historically confined to idealized, non-absorbing dielectric particles. Implementing optical pulling in plasmonic metallic nanostructures has remained an elusive goal because noble metals suffer from intrinsic ohmic dissipation ($\sigma_{\mathrm{abs}} > 0$), which conveys a mandatory forward radiation push. Our manuscript directly addresses this challenge by introducing a rationally engineered metallic architecture: 3D helical superstructures of high-aspect-ratio gold nanorods ($L=60$~nm, $D=15$~nm). We demonstrate how collective plasmonic hybridization in these metamolecules overcomes the absorption barrier to deliver sustained, polarization-switchable optomechanical pulling.

\paragraph{Key Novelties and Quantitative Advances:}
\begin{enumerate}
\item \textbf{First Demonstration in Lossy Plasmonic Assemblies:} We show that a right-handed tapered-chirped hybrid helix (RH-TCH-CPH) immersed in water and illuminated by a non-paraxial left-circularly polarized (LCP) Bessel beam ($\theta_0 = 49.5^\circ$) produces a peak pulling force of \textbf{$-10.5$~pN/(W/$\mu$m$^2$)} at $\lambda_0 = 1060$~nm, corresponding to a high negative radiation-pressure efficiency of $Q_{\mathrm{pr}} = -0.712$.
\item \textbf{Broadband Performance:} The assembly delivers a continuous negative-force pulling bandwidth of \textbf{285~nm} (935--1220~nm), providing broad spectral flexibility.
\item \textbf{Multipolar Kerker Interference Mechanism:} Phase-resolved Cartesian multipole decomposition demonstrates that near-in-phase co-excitation of electric dipole, magnetic dipole, and electric quadrupole moments ($\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$) suppresses backward scattering, driving the forward asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, well above the critical analytical threshold $g_{\mathrm{crit}} = 0.721$.
\item \textbf{Polarization Selectivity:} Switching the illumination to right-circular polarization (RCP) reverses the force to forward pushing ($+2.4$~pN), providing instantaneous, dynamic directional control.
\item \textbf{Rigorous Multi-Solver Validation:} The predicted pulling force is independently cross-validated across four distinct computational formulations: FDTD (Maxwell Stress Tensor), FEM (COMSOL Multiphysics, 2.7\% agreement), Coupled Dipole Approximation (CDA, 5.5\% agreement), and direct full-wave Bessel FDTD (1.1\% discrepancy vs ASR).
\item \textbf{Fabrication Robustness and Statistical Modeling:} A 100-run Monte Carlo tolerance study shows pulling retention in \textbf{100/100 realizations} under simultaneous 5-parameter Gaussian disorder ($>97\%$ lower confidence bound). Multivariate regression across 90 Latin Hypercube configurations validates circular dichroism as a robust far-field predictor ($R^2 = 0.947$, 5-fold CV $R^2_{\mathrm{CV}} = 0.931$, external hold-out $R^2_{\mathrm{test}} = 0.937$).
\end{enumerate}

\paragraph{Why This Work Matters for Applied Nano Materials:}
This study is not merely a numerical parameter optimization; it establishes the fundamental physical chain connecting gold nanorod synthesis, chiral self-assembly (compatible with DNA origami and glancing-angle deposition), multipolar scattering control, and non-contact nanomechanical actuation. This framework provides actionable design rules for enantioselective chiral sorting, optomechanical microfluidics, and light-driven nanorobotics.

\vspace{0.8em}
\noindent
This manuscript has not been published previously and is not under consideration elsewhere. All authors have approved the manuscript and agree with its submission to \textit{ACS Applied Nano Materials}.

\vspace{1.5em}
\noindent
Sincerely yours,

\vspace{1.2em}
\noindent
\textbf{Ram Soorat, Ph.D.} (\textit{Corresponding Author}) \\
Assistant Professor, School of Technology \\
Woxsen University, Hyderabad, Telangana 502345, India \\
Email: \texttt{rsoorat@gmail.com}

\vspace{1em}
\noindent
\textbf{On behalf of all co-authors:} \\
Priyanka (University of Delhi) \\
Rajveer Singh (Atma Ram Sanatan Dharma College, University of Delhi) \\
Narender Kumar (Sri Venkateswara College, University of Delhi) \\
Sandeep (Deen Dayal Upadhyaya College, University of Delhi)

\end{document}
"""

with open(out_path, "w", encoding="utf-8") as f:
    f.write(content)

print(f"Saved {out_path} ({len(content)} chars)")
