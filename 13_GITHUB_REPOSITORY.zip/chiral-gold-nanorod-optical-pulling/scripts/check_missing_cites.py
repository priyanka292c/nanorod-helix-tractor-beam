import re

with open('08_references.bib', 'r', encoding='utf-8') as f:
    bib_text = f.read()

bib_keys = set(re.findall(r'@\w+\s*\{\s*([^,\s]+)', bib_text))
print(f"Total keys in 08_references.bib: {len(bib_keys)}")

with open('01_ACS_ANM_Manuscript.tex', 'r', encoding='utf-8') as f:
    main_tex = f.read()

main_cites = set()
for c in re.findall(r'\\cite\{([^}]+)\}', main_tex):
    for k in c.split(','):
        main_cites.add(k.strip())

print(f"Total keys cited in 01_ACS_ANM_Manuscript.tex: {len(main_cites)}")
missing_in_main = main_cites - bib_keys
print(f"Missing in bib for main: {missing_in_main}")

with open('04_ACS_ANM_Supporting_Information.tex', 'r', encoding='utf-8') as f:
    si_tex = f.read()

si_cites = set()
for c in re.findall(r'\\cite\{([^}]+)\}', si_tex):
    for k in c.split(','):
        si_cites.add(k.strip())

print(f"Total keys cited in 04_ACS_ANM_Supporting_Information.tex: {len(si_cites)}")
missing_in_si = si_cites - bib_keys
print(f"Missing in bib for SI: {missing_in_si}")
