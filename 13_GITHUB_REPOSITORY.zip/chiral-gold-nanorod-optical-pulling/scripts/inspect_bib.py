import re
import os

bib_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant\references.bib"
with open(bib_path, "r", encoding="utf-8") as f:
    text = f.read()

entries = re.split(r'\n@', text)
items = []
for block in entries:
    if not block.strip():
        continue
    lines = block.split('\n')
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', lines[0].strip().lstrip('@'))
    if m:
        etype = m.group(1)
        key = m.group(2)
        doi_m = re.search(r'doi\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        year_m = re.search(r'year\s*=\s*[\"{]?(\d{4})[\"}]?', block)
        title_m = re.search(r'title\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        journal_m = re.search(r'journal\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        author_m = re.search(r'author\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        
        doi = doi_m.group(1).strip() if doi_m else None
        year = year_m.group(1).strip() if year_m else None
        title = title_m.group(1).strip() if title_m else None
        journal = journal_m.group(1).strip() if journal_m else None
        items.append({'key': key, 'etype': etype, 'doi': doi, 'year': year, 'title': title, 'journal': journal, 'raw': block})

print(f"Total parsed BibTeX entries: {len(items)}")
has_doi = [it for it in items if it['doi']]
print(f"Entries with DOI: {len(has_doi)}")
no_doi = [it for it in items if not it['doi']]
print(f"Entries without DOI: {len(no_doi)}")
for nd in no_doi:
    print(f"  No DOI: [{nd['key']}] ({nd['etype']}) {nd['title']}")

years = [int(it['year']) for it in items if it['year']]
recent_2020 = [y for y in years if y >= 2020]
print(f"Year span: {min(years)} - {max(years)}")
print(f"Total entries published >= 2020: {len(recent_2020)}")
print(f"Total entries published < 2020: {len(years) - len(recent_2020)}")

arxiv_items = [it for it in items if 'arxiv' in it['raw'].lower()]
print(f"Entries mentioning arXiv: {len(arxiv_items)}")
for ar in arxiv_items:
    print(f"  arXiv item: {ar['key']}")

# Check duplicate DOIs
doi_counts = {}
for it in items:
    if it['doi']:
        d = it['doi'].lower().strip()
        doi_counts[d] = doi_counts.get(d, 0) + 1
duplicates = {d: c for d, c in doi_counts.items() if c > 1}
print(f"Duplicate DOIs count: {len(duplicates)}")
for d, c in duplicates.items():
    dup_keys = [it['key'] for it in items if it['doi'] and it['doi'].lower().strip() == d]
    print(f"  Duplicate DOI {d} ({c} times): {dup_keys}")
