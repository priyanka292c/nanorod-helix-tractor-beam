import pandas as pd
import numpy as np

df = pd.read_csv('figures/Fig22/processed_data.csv')
print(f"Total rows in Fig22 CSV: {len(df)}")
df100 = df.iloc[:100]
print("--- First 100 rows statistics ---")
print(f"Mean Fz: {df100['Fz_pN'].mean():.4f}")
print(f"Std Fz:  {df100['Fz_pN'].std():.4f}")
print(f"Min Fz:  {df100['Fz_pN'].min():.4f}")
print(f"Max Fz:  {df100['Fz_pN'].max():.4f}")
print(f"Negative count: {(df100['Fz_pN'] < 0).sum()} / 100")
