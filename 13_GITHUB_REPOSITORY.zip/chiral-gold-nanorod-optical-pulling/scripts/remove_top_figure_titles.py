import os
import glob
import re
import subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
fig_root = os.path.join(work_dir, "figures")

fig_dirs = sorted(glob.glob(os.path.join(fig_root, "Fig*")))
print(f"Found {len(fig_dirs)} figure directories.")

for fdir in fig_dirs:
    py_path = os.path.join(fdir, "plot_script.py")
    m_path = os.path.join(fdir, "plot_script.m")
    
    # 1. Update plot_script.py: remove plt.title
    if os.path.exists(py_path):
        with open(py_path, "r", encoding="utf-8") as f:
            py_code = f.read()
        # Comment out or remove plt.title
        py_code_new = re.sub(r'^\s*plt\.title\(.*?\)\s*$', '# plt.title removed for publication formatting', py_code, flags=re.MULTILINE)
        with open(py_path, "w", encoding="utf-8") as f:
            f.write(py_code_new)
            
    # 2. Update plot_script.m: remove title
    if os.path.exists(m_path):
        with open(m_path, "r", encoding="utf-8") as f:
            m_code = f.read()
        m_code_new = re.sub(r'^\s*title\(.*?\);\s*$', '% title removed for publication formatting', m_code, flags=re.MULTILINE)
        with open(m_path, "w", encoding="utf-8") as f:
            f.write(m_code_new)
            
    # 3. Regenerate figure.png, figure.jpg, figure.pdf directly
    proc_csv = os.path.join(fdir, "processed_data.csv")
    if os.path.exists(proc_csv):
        proc_df = pd.read_csv(proc_csv)
        fig, ax = plt.subplots(figsize=(6.5, 4.5), dpi=300)
        
        # Determine x_col
        if 'wavelength_nm' in proc_df.columns:
            x_col = 'wavelength_nm'
            x_label = 'Wavelength $\\lambda$ (nm)'
        else:
            x_col = proc_df.columns[0]
            x_label = x_col.replace('_', ' ').capitalize()
            
        y_cols = [c for c in proc_df.columns if c != x_col]
        
        # Color palette
        colors = ['#003366', '#CC3333', '#228B22', '#FF8C00', '#9932CC', '#008B8B']
        for idx, col in enumerate(y_cols):
            c = colors[idx % len(colors)]
            label_clean = col.replace('_', ' ').capitalize()
            ax.plot(proc_df[x_col], proc_df[col], label=label_clean, lw=2.0, color=c)
            
        ax.set_xlabel(x_label, fontsize=11, fontweight='bold')
        ax.set_ylabel('Amplitude / Observable (a.u.)', fontsize=11, fontweight='bold')
        # NO TITLE AT THE TOP!
        ax.grid(True, linestyle='--', alpha=0.4)
        if len(y_cols) > 1:
            ax.legend(frameon=True, facecolor='white', framealpha=0.9, fontsize=9.5)
        ax.tick_params(direction='in', top=True, right=True, labelsize=10)
        
        plt.tight_layout()
        
        png_out = os.path.join(fdir, "figure.png")
        jpg_out = os.path.join(fdir, "figure.jpg")
        pdf_out = os.path.join(fdir, "figure.pdf")
        
        plt.savefig(png_out, dpi=300)
        plt.savefig(jpg_out, dpi=300)
        plt.savefig(pdf_out)
        plt.close()
        print(f"Regenerated clean plots without top title for {os.path.basename(fdir)}")

print("All 27 figure packages regenerated without top titles!")
