import pypdf, re

def search_pdf(pdf_path, terms):
    reader = pypdf.PdfReader(pdf_path)
    full_text = ' '.join([p.extract_text() or '' for p in reader.pages])
    print(f'=== Checking {pdf_path} ===')
    for t in terms:
        m = re.search(re.escape(t), full_text, re.IGNORECASE)
        print(f'  [{"PASS" if m else "FAIL"}] "{t}"')

search_pdf('03_ACS_ANM_Manuscript.pdf', [
    'fixed polar tilt angle',
    'linear interpolation in rod index',
    'rejection sampling',
    '-55.00',
    '-10.50'
])

search_pdf('05_ACS_ANM_Supporting_Information.pdf', [
    'fixed polar tilt angle',
    'Table S1',
    '0.707',
    'truncated Gaussian',
    'rejection sampling'
])

search_pdf('07_ACS_ANM_Cover_Letter.pdf', [
    'may motivate future experimental studies',
    'polarization-selective chiral manipulation',
    'Xing Yi Ling',
    '-10.50'
])
