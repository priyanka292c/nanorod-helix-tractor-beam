import re

with open('04_ACS_ANM_Supporting_Information.tex', 'r', encoding='utf-8') as f:
    text = f.read()

figs = re.findall(r'\\begin\{figure\}.*?\\includegraphics\[.*?\]\{(.*?)\}.*?\\caption\{(.*?)\}.*?\\label\{(.*?)\}.*?\\end\{figure\}', text, re.DOTALL)
print(f"Total figures found in 04_ACS_ANM_Supporting_Information.tex: {len(figs)}")
for i, (path, cap, lab) in enumerate(figs, 1):
    cap_clean = re.sub(r'\s+', ' ', cap).strip()[:80]
    print(f"[S{i:02d}] Graphic: {path:<25} | Label: {lab:<12} | Caption: {cap_clean}...")

print("\n--- Figure references in SI text ---")
refs = re.findall(r'Figure\s+(S?\d+)', text)
print(f"Figures mentioned in SI: {sorted(list(set(refs)))}")
tex_refs = re.findall(r'\\ref\{(fig:[^}]+)\}', text)
print(f"Tex ref labels in SI: {set(tex_refs)}")
