import os
import pypdf

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

deliverables = [
    "01_ACS_ANM_Manuscript.tex",
    "02_ACS_ANM_Manuscript.docx",
    "03_ACS_ANM_Manuscript.pdf",
    "04_ACS_ANM_Supporting_Information.tex",
    "05_ACS_ANM_Supporting_Information.pdf",
    "06_ACS_ANM_Cover_Letter.docx",
    "07_ACS_ANM_Cover_Letter.pdf",
    "08_references.bib",
    "09_reference_validation_report.csv",
    "10_figure_validation_report.csv",
    "11_simulation_validation_report.csv",
    "12_FINAL_AUDIT_REPORT.pdf",
    "13_GITHUB_REPOSITORY.zip",
    "14_ACS_ANM_COMPLETE_PACKAGE.zip"
]

print(f"Auditing all {len(deliverables)} Part 50 Deliverables in {work_dir}:\n")
all_pass = True
for idx, fn in enumerate(deliverables, 1):
    fpath = os.path.join(work_dir, fn)
    if os.path.exists(fpath):
        sz = os.path.getsize(fpath)
        extra = ""
        if fn.endswith(".pdf"):
            reader = pypdf.PdfReader(fpath)
            extra = f" ({len(reader.pages)} pages)"
        print(f"  {idx:02d}. [PASS] {fn:<40} : {sz:>10,} bytes{extra}")
    else:
        print(f"  {idx:02d}. [FAIL] {fn:<40} : NOT FOUND")
        all_pass = False

print("\n" + "="*70)
if all_pass:
    print("STATUS: ALL 14 FINAL DELIVERABLES VERIFIED AND PRESENT (100% COMPLETE)")
else:
    print("STATUS: VERIFICATION FAILED FOR ONE OR MORE DELIVERABLES")
print("="*70)
