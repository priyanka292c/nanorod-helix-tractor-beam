import os

si_tex_content = r"""\documentclass[journal=aamick,manuscript=suppinfo]{achemso}

\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{siunitx}
\usepackage{bm}
\usepackage{xcolor}
\usepackage{array}
\usepackage{longtable}
\usepackage{multirow}
\usepackage{setspace}
\usepackage{geometry}
\geometry{letterpaper, margin=1in}

\usepackage[
 colorlinks=true,
 linkcolor=blue,
 citecolor=blue,
 urlcolor=blue
]{hyperref}

\title{Supporting Information: Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference}

\author{Priyanka}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{priyanka292c@gmail.com}

\author{Ram Soorat}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}

\author{S. D. Sharma}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{sdsharma@physics.du.ac.in}

\begin{document}

\maketitle

\section*{Contents}
\begin{itemize}
\item \textbf{Section S1:} Helical Geometry Generation and Analytical Parameterization
\item \textbf{Section S2:} Electromagnetic Spectra and Near-Field Hot-Spot Profiles
\item \textbf{Section S3:} Gold Dielectric Function, Dispersion Models, and Surface Damping
\item \textbf{Section S4:} Coupled Dipole Approximation (CDA) Mathematical Derivation
\item \textbf{Section S5:} 3D FDTD Solver Settings and Boundary Conditions
\item \textbf{Section S6:} Finite Element Method (COMSOL) Implementation
\item \textbf{Section S7:} Boundary Element Method (BEM) Scattering Implementation
\item \textbf{Section S8:} Far-Field Radiation Patterns and Multipolar Phase Spectra
\item \textbf{Section S9:} Bessel Beam Angular Spectrum Convergence
\item \textbf{Section S10:} Computational Resources and Spatial Grid Scaling
\item \textbf{Section S11:} Anisotropic Hydrodynamic Drag and Optomechanical Velocity Estimates
\item \textbf{Section S12:} Inter-Rod Gap Sensitivity and Quantum Tunneling Limit
\item \textbf{Section S13:} Monte Carlo Five-Parameter Disorder Protocol (100 Realizations)
\item \textbf{Section S14:} Latin Hypercube Sampling (LHS) 90-Configuration Dataset and 30 Hold-Out Tests
\item \textbf{Section S15:} Supplementary Tables
\end{itemize}

\clearpage

\section{Section S1: Helical Geometry Generation and Analytical Parameterization}
The coordinates $(x_i, y_i, z_i)$ of each nanorod center-of-mass ($i=1,\dots,10$) in the right-handed tapered-chirped hybrid helix (RH-TCH-CPH) are generated via:
\begin{equation}
x_i = r(z_i)\cos\phi_i, \quad y_i = r(z_i)\sin\phi_i, \quad z_i = z_0 + (i-1)\Delta z_i,
\end{equation}
where $\phi_i = (i-1)\Delta\phi$ with angular step $\Delta\phi = 45^\circ$. The radial envelope is $r(z) = r_{\mathrm{start}} + \frac{r_{\mathrm{end}}-r_{\mathrm{start}}}{z_{\mathrm{max}}-z_{\mathrm{min}}}(z - z_{\mathrm{min}})$, with $r_{\mathrm{start}} = 20$~nm and $r_{\mathrm{end}} = 30$~nm over $z \in [-60, +60]$~nm. The pitch chirp is $P(z) = P_0 + \kappa_{\mathrm{chirp}} z$, with $P_0 = 100$~nm and $\kappa_{\mathrm{chirp}} = 0.25$. Nanorod long axes are oriented at tilt angle $\theta_{\mathrm{tilt}} = 45^\circ$ relative to the $z$-axis.

\section{Section S2: Electromagnetic Spectra and Near-Field Hot-Spot Profiles}
Near-field electric field distributions were recorded across monitor planes slicing through the inter-rod junctions at $\lambda_0 = 1060$~nm under LCP Bessel illumination. Maximum near-field enhancement factors reach $|E/E_0| \approx 104.2$ in the 2.0-nm capacitive gap between rods 5 and 6, confirming strong localized surface plasmon hybridization.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig11/figure.png}
\caption{\textbf{Figure S1.} Electric near-field hot-spot enhancement distribution ($|E/E_0|$) across the 10-nanorod assembly at $\lambda_0 = 1060$~nm, showing strong capacitive field concentration in the 2.0-nm inter-rod gaps.}
\label{fig:S1}
\end{figure}

\section{Section S3: Gold Dielectric Function, Dispersion Models, and Surface Damping}
The dielectric function of gold is modeled using the empirical tabulated data of Johnson and Christy \cite{johnson1972optical}, interpolated with cubic splines. To verify stability against analytical representations, we compare the empirical dataset with a dual-Lorentz Drude model:
\begin{equation}
\epsilon(\omega) = \epsilon_\infty - \frac{\omega_p^2}{\omega(\omega + i\gamma)} + \sum_{j=1}^2 \frac{f_j \omega_j^2}{\omega_j^2 - \omega^2 - i\omega\Gamma_j}.
\end{equation}
For nanorods with diameter $D = 15$~nm, surface scattering enhances electron damping. Evaluating a size-corrected Drude model with $\gamma_{\mathrm{eff}} = \gamma_{\mathrm{bulk}} + A v_F/L_{\mathrm{eff}}$ ($A = 0.75$, $L_{\mathrm{eff}} \approx 12$~nm) raises $\epsilon_2$ from $3.85$ to $4.22$, which slightly reduces the peak pulling force from $-10.50$ to $-9.82$~pN/(W/$\mu$m$^2$) (a 6.5\% reduction) while preserving $F_z < 0$ and the 280-nm bandwidth.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig05/figure.png}
\caption{\textbf{Figure S2.} Comparative dielectric function models for gold: Johnson-Christy empirical data vs Drude-Lorentz analytical fit across the near-infrared spectrum.}
\label{fig:S2}
\end{figure}

\section{Section S4: Coupled Dipole Approximation (CDA) Mathematical Derivation}
In the CDA formulation, each nanorod is discretized into point dipoles with anisotropic polarizability tensor $\hat{\alpha}$. The self-consistent local field $\mathbf{E}_j$ at dipole $j$ satisfies:
\begin{equation}
\mathbf{E}_j = \mathbf{E}_{\mathrm{inc}}(\mathbf{r}_j) + \frac{k_0^2}{\epsilon_0} \sum_{k \neq j} \hat{\mathbf{G}}(\mathbf{r}_j, \mathbf{r}_k) \mathbf{p}_k,
\end{equation}
where $\hat{\mathbf{G}}$ is the dyadic free-space Green's tensor. The dipole moment is $\mathbf{p}_j = \epsilon_0 \epsilon_m \hat{\alpha}_j \mathbf{E}_j$. The total optical force is obtained by summing dipole momentum transfer:
\begin{equation}
\mathbf{F} = \frac{1}{2} \sum_j \operatorname{Re}\left[ (\nabla \mathbf{E}_{\mathrm{inc}}^*) \cdot \mathbf{p}_j \right] - \frac{k_0^4}{12\pi\epsilon_0} \sum_j \sum_{k \neq j} \operatorname{Re}\left[ \mathbf{p}_j^* \times \mathbf{p}_k \right].
\end{equation}

\section{Section S5: 3D FDTD Solver Settings and Boundary Conditions}
FDTD calculations were executed using Ansys Lumerical FDTD Solutions v2024 R1. The simulation box spans $-750$~nm to $+750$~nm in $x$ and $y$, and $-1000$~nm to $+1000$~nm in $z$. All six boundaries are terminated with 16-layer steep-angle convolutional PMLs. A localized mesh override box enclosing the 10 nanorods enforces $\Delta x = \Delta y = \Delta z = 0.5$~nm. Conformal Mesh Variant 1 is applied at metal-water boundaries. The simulation auto-shutoff threshold is set to $10^{-6}$ with simulation time $T_{\mathrm{sim}} = 150$~fs.

\section{Section S6: Finite Element Method (COMSOL) Implementation}
FEM calculations were performed in COMSOL Multiphysics 6.2 (Wave Optics Module). The domain is bounded by spherical perfectly matched layers (thickness 250~nm). Second-order vector elements are deployed with adaptive tetrahedral meshing: maximum element size is 0.4~nm along the nanorod surfaces and in the 2.0-nm inter-rod gaps. Maxwell stress tensor integration is evaluated over a sphere of radius 90~nm centered on the helix.

\section{Section S7: Boundary Element Method (BEM) Implementation}
BEM calculations were conducted using the MNPBEM toolbox in MATLAB. The 10-nanorod surfaces are discretized into 2,400 planar triangular boundary elements. BEM calculates the induced surface charge and surface current densities to evaluate the far-field polar and azimuthal scattering intensity profiles, confirming $g_{\mathrm{asym}} = 0.942$ (within 3.8\% of FDTD).

\section{Section S8: Far-Field Radiation Patterns and Multipolar Phase Spectra}
Figure~\ref{fig:S3} displays the 2D polar far-field scattering intensity distribution under LCP versus RCP illumination. LCP drives pronounced forward scattering directivity ($g_{\mathrm{asym}} = 0.954$), whereas RCP restores backscattering. Figure~\ref{fig:S4} depicts the multipolar phase differences $\Delta\Phi_{\mathrm{ED-MD}}$ and $\Delta\Phi_{\mathrm{ED-EQ}}$, showing near-in-phase alignment at $\lambda_0 = 1060$~nm.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig14/figure.png}
\caption{\textbf{Figure S3.} 2D polar far-field scattering intensity patterns in elevation ($\theta$) and azimuth ($\phi$) planes under LCP vs RCP Bessel illumination, showing forward directivity under LCP.}
\label{fig:S3}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig16/figure.png}
\caption{\textbf{Figure S4.} Relative phase differences $\Delta\Phi_{\mathrm{ED-MD}}$ and $\Delta\Phi_{\mathrm{ED-EQ}}$ across the 600--1400~nm band, illustrating in-phase alignment ($\approx 12^\circ$ and $18^\circ$) at the 1060-nm resonance.}
\label{fig:S4}
\end{figure}

\section{Section S9: Bessel Beam Angular Spectrum Convergence}
Figure~\ref{fig:S5} displays the sensitivity of the optical force to Bessel half-cone angle $\theta_0$, showing the critical pulling boundary at $\theta_{\mathrm{crit}} = 30.6^\circ$. Figure~\ref{fig:S6} compares direct full-wave Bessel FDTD against continuous angular-spectrum plane-wave reconstruction, confirming agreement within 1.1\% across the 950--1150~nm band.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig18/figure.png}
\caption{\textbf{Figure S5.} Sensitivity of the longitudinal force to the Bessel beam half-cone angle $\theta_0$, showing the critical pulling boundary at $\theta_{\mathrm{crit}} = 30.6^\circ$.}
\label{fig:S5}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig19/figure.png}
\caption{\textbf{Figure S6.} Discrepancy analysis between direct full-wave Bessel FDTD and coherent angular-spectrum plane-wave reconstruction across the 950--1150~nm band (1.1\% maximum difference).}
\label{fig:S6}
\end{figure}

\section{Section S10: Computational Resources and Spatial Grid Scaling}
Figure~\ref{fig:S7} illustrates the spatial mesh convergence curve from 2.0~nm down to 0.4~nm, confirming that the adopted 0.5-nm grid provides $<0.5\%$ residual deviation relative to 0.4~nm and 1.6\% relative to the Richardson continuum limit.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig21/figure.png}
\caption{\textbf{Figure S7.} Grid convergence curve for FDTD mesh override from 2.0~nm down to 0.2~nm, confirming numerical stability and asymptotic Richardson convergence at the chosen 0.5-nm resolution.}
\label{fig:S7}
\end{figure}

\section{Section S11: Anisotropic Hydrodynamic Drag and Optomechanical Velocity Estimates}
Under low-Reynolds-number Stokes flow in water ($\eta = 1.0 \times 10^{-3}$~Pa$\cdot$s), an idealized steady-state upstream drift velocity can be estimated by equating optical pulling force to viscous drag: $v_z = F_z / \gamma_z$. Approximating the 10-nanorod helix as an equivalent prolate spheroid with semi-major axis $a = 60$~nm and semi-minor axis $b = 30$~nm yields longitudinal drag coefficient $\gamma_z = 6\pi\eta a / \ln(2a/b - 0.5) \approx 8.2 \times 10^{-10}$~N$\cdot$s/m. Under this simplified model, an optical pulling force of $F_z = -10.5$~pN at $I_0 = 1.0$~W/$\mu$m$^2$ implies an idealized terminal velocity of $v_z \approx -12.8$~mm/s (or $-12.8\,\mu$m/s at experimental intensity $I_0 = 1.0$~mW/$\mu$m$^2$).

We emphasize that this velocity represents an idealized order-of-magnitude optomechanical benchmark. A rigorous experimental prediction must account for several complex hydrodynamic factors: (i) anisotropic translation-rotation hydrodynamic coupling inherent to chiral helices, which induces coupled propulsion and orientation tumbling; (ii) rotational Brownian diffusion ($\tau_{\mathrm{rot}} = 8\pi\eta r^3 / (k_B T) \sim 10\,\mu$s in water), which tends to randomize particle orientation unless aligned by transverse optical torque gradients; (iii) hydrodynamic boundary effects in microfluidic channels; and (iv) photothermal heating and local Marangoni convection.

\section{Section S12: Inter-Rod Gap Sensitivity and Quantum Tunneling Limit}
Parametric sweeps of the inter-rod gap from $g = 1.0$~nm to $4.0$~nm show that peak pulling shifts from $-12.4$~pN (at 1.0~nm) to $-6.8$~pN (at 4.0~nm). At $g = 2.0$~nm, the classical local dielectric approximation is fully justified, as quantum mechanical electron tunneling occurs predominantly below 0.5~nm and nonlocal hydrodynamic screening produces $<3\%$ spectral shifts for gaps $>1.5$~nm.

\section{Section S13: Monte Carlo Five-Parameter Disorder Protocol (100 Realizations)}
Figure~\ref{fig:S8} shows the cumulative distribution function (CDF) of optical pulling forces across the 100 Monte Carlo disorder realizations under five-parameter Gaussian variance. In 100/100 realizations, the force remains negative, confirming statistical tolerance under realistic nanoscale dimensional variations.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig22/figure.png}
\caption{\textbf{Figure S8.} Cumulative distribution function (CDF) of the 100 Monte Carlo disorder realizations under the five-parameter Gaussian model, showing 100/100 negative force retention.}
\label{fig:S8}
\end{figure}

\section{Section S14: Latin Hypercube Sampling (LHS) 90-Configuration Dataset and 30 Hold-Out Tests}
Figure~\ref{fig:S9} displays the 5D parameter space distribution across the 90 LHS training geometries. Figure~\ref{fig:S10} shows the residual diagnostic plot evaluated on the 30 independent hold-out test configurations (generated with a separate random seed and sequestered during training), confirming that residuals are normally distributed with zero systematic bias ($R^2_{\mathrm{test}} = 0.937$).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig23/figure.png}
\caption{\textbf{Figure S9.} Latin Hypercube parameter distribution space across pitch, radius, and rod length for the 90 simulated training geometries.}
\label{fig:S9}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.32\textheight,keepaspectratio]{figures/Fig25/figure.png}
\caption{\textbf{Figure S10.} Residual plot for the multivariate regression model evaluated on the independent 30-configuration hold-out dataset ($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.45$~pN).}
\label{fig:S10}
\end{figure}

\section{Section S15: Supplementary Tables}
\begin{table}[!htbp]
\centering
\small
\caption{\textbf{Table S1.} FDTD Conformal Mesh Settings and Boundary Parameters.}
\begin{tabular}{lcc}
\toprule
\textbf{Parameter} & \textbf{Value} & \textbf{Unit} \\
\midrule
Mesh Technology & Conformal Variant 1 & --- \\
Override Grid Size ($\Delta x, \Delta y, \Delta z$) & 0.5, 0.5, 0.5 & nm \\
Courant Stability Factor & 0.99 & --- \\
Auto-Shutoff Level & $1.0 \times 10^{-6}$ & --- \\
Simulation Time & 150 & fs \\
PML Layers & 16 & layers \\
PML Reflection Coefficient & $< 10^{-6}$ & --- \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[!htbp]
\centering
\small
\caption{\textbf{Table S2.} Computational Resource Benchmarks Across Multi-Solver Implementations.}
\begin{tabular}{lcccc}
\toprule
\textbf{Solver} & \textbf{Memory (GB)} & \textbf{Cores} & \textbf{Time per Run (s)} & \textbf{Total Runs} \\
\midrule
FDTD (Lumerical) & 14.2 & 32 & 142 & 100 (MC) + 90 (LHS) + 30 (Test) \\
FEM (COMSOL) & 28.5 & 32 & 380 & 10 (Benchmark) \\
CDA (MATLAB) & 2.1 & 8 & 12 & 120 (Spectra) \\
BEM (MNPBEM) & 6.4 & 16 & 95 & 10 (Scattering check) \\
\bottomrule
\end{tabular}
\end{table}

\bibliography{08_references}

\end{document}
"""

with open("04_ACS_ANM_Supporting_Information.tex", "w", encoding="utf-8") as f:
    f.write(si_tex_content)

print("Saved updated 04_ACS_ANM_Supporting_Information.tex successfully.")
