import re
import urllib.request, urllib.parse, json, ssl

ctx = ssl.create_default_context()

bib_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\08_references.bib"
with open(bib_path, "r", encoding="utf-8") as f:
    text = f.read()

entries = re.split(r'\n@', text)
fixed_blocks = []

for block in entries:
    if not block.strip():
        continue
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', block.strip().lstrip('@'))
    if not m:
        continue
    key = m.group(2).strip()
    open_b = block.count('{')
    close_b = block.count('}')
    
    if open_b != close_b:
        print(f"Fixing key [{key}]...")
        # Get DOI
        doi_m = re.search(r'doi\s*=\s*[\"{](.*?)[\"}]', block)
        if doi_m:
            doi = doi_m.group(1).strip()
            # Fetch authors from Crossref
            url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Auditor/1.0 (mailto:priya@du.ac.in)'})
            try:
                with urllib.request.urlopen(req, timeout=8, context=ctx) as resp:
                    data = json.loads(resp.read().decode())['message']
                    authors = []
                    for a in data.get('author', []):
                        g = a.get('given', '')
                        f = a.get('family', '')
                        if f:
                            authors.append(f"{f}, {g}".strip() if g else f)
                    if authors:
                        auth_str = " and ".join(authors)
                        # Replace author field
                        block = re.sub(r'author\s*=\s*\{.*?,', f'author    = {{{auth_str}}},', block, flags=re.DOTALL)
                        print(f"  Fixed authors for {key}: {auth_str[:50]}...")
            except Exception as e:
                print(f"  Error fetching {key}: {e}")
                # Simple fix: close brace
                block = re.sub(r'author\s*=\s*\{([^}]+),', r'author    = {\1},', block)
    fixed_blocks.append(block.strip())

with open(bib_path, "w", encoding="utf-8") as f:
    f.write("% 08_references.bib - Authenticated Bibliography\n\n")
    for b in fixed_blocks:
        if not b.startswith("@"):
            f.write("@" + b + "\n\n")
        else:
            f.write(b + "\n\n")

print("All entries processed.")
