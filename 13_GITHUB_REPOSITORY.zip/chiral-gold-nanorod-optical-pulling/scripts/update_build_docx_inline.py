import os
import re
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def set_table_borders(table):
    tblPr = table._tbl.tblPr
    tblBorders = OxmlElement('w:tblBorders')
    for b_name in ['top', 'bottom']:
        node = OxmlElement(f'w:{b_name}')
        node.set(qn('w:val'), 'single')
        node.set(qn('w:sz'), '8')
        node.set(qn('w:space'), '0')
        node.set(qn('w:color'), '000000')
        tblBorders.append(node)
    insideH = OxmlElement('w:insideH')
    insideH.set(qn('w:val'), 'single')
    insideH.set(qn('w:sz'), '4')
    insideH.set(qn('w:space'), '0')
    insideH.set(qn('w:color'), 'CCCCCC')
    tblBorders.append(insideH)
    tblPr.append(tblBorders)

def set_row_cant_split(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement('w:cantSplit'))

def set_row_header(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement('w:tblHeader'))

def clean_latex_text(text):
    text = re.sub(r'\\cite\{[^}]+\}', '', text)
    text = re.sub(r'\\ref\{[^}]+\}', '', text)
    text = re.sub(r'\\label\{[^}]+\}', '', text)
    text = re.sub(r'\\textbf\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\textit\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\emph\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mu', r'μ', text)
    text = re.sub(r'\\lambda', r'λ', text)
    text = re.sub(r'\\theta', r'θ', text)
    text = re.sub(r'\\phi', r'ϕ', text)
    text = re.sub(r'\\epsilon', r'ε', text)
    text = re.sub(r'\\sigma', r'σ', text)
    text = re.sub(r'\\Delta', r'Δ', text)
    text = re.sub(r'\\times', r'×', text)
    text = re.sub(r'\\approx', r'≈', text)
    text = re.sub(r'\\pm', r'±', text)
    text = re.sub(r'\\le', r'≤', text)
    text = re.sub(r'\\ge', r'≥', text)
    text = re.sub(r'\\sim', r'~', text)
    text = re.sub(r'\\%', r'%', text)
    text = re.sub(r'\\&', r'&', text)
    text = re.sub(r'\$([^$]+)\$', r'\1', text)
    text = re.sub(r'\\mathrm\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathbf\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathit\{([^}]+)\}', r'\1', text)
    text = re.sub(r'\\mathcal\{([^}]+)\}', r'\1', text)
    text = text.replace('{', '').replace('}', '')
    text = text.replace('\\', '')
    return text.strip()

def parse_latex_table(tbl_tex):
    cap_m = re.search(r'\\caption\{([^}]+)\}', tbl_tex)
    title = cap_m.group(1) if cap_m else "Table"
    title = clean_latex_text(title)
    
    # Extract tabular
    tabular_m = re.search(r'\\begin\{tabular\}\{[^}]+\}(.*?)\\end\{tabular\}', tbl_tex, re.DOTALL)
    if not tabular_m:
        return title, [], []
    tab_body = tabular_m.group(1)
    rows_raw = [r.strip() for r in tab_body.split(r'\\') if r.strip()]
    
    headers = []
    rows = []
    for r_raw in rows_raw:
        # clean commands like \toprule, \midrule, \bottomrule, \hline
        cleaned_row = re.sub(r'\\(toprule|midrule|bottomrule|hline)', '', r_raw).strip()
        if not cleaned_row:
            continue
        cells = [clean_latex_text(c.strip()) for c in cleaned_row.split('&')]
        if not headers:
            headers = cells
        else:
            rows.append(cells)
    return title, headers, rows

def build_manuscript_docx():
    print("Building 02_ACS_ANM_Manuscript.docx with in-line figures and tables...")
    doc = docx.Document()
    
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)
        
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    
    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_title = p_title.add_run("Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference")
    r_title.bold = True
    r_title.font.size = Pt(18)
    p_title.paragraph_format.space_after = Pt(14)
    
    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_auth = p_auth.add_run("Priyanka,¹ Ram Soorat,²,* Rajveer Singh,³ Narender Kumar,⁴ and Sandeep⁵")
    r_auth.bold = True
    r_auth.font.size = Pt(12)
    p_auth.paragraph_format.space_after = Pt(4)
    
    # Affiliation
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_aff = p_aff.add_run(
        "¹Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\n"
        "²School of Technology, Woxsen University, Hyderabad, Telangana 502345, India\n"
        "³Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India\n"
        "⁴Department of Physics, Sri Venkateswara College, Benito Juarez Road, Dhaula Kuan, New Delhi 110021, India\n"
        "⁵Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India\n"
        "*Corresponding Author: rsoorat@gmail.com"
    )
    r_aff.italic = True
    r_aff.font.size = Pt(9.5)
    p_aff.paragraph_format.space_after = Pt(14)
    
    # TOC Graphic Box
    p_toc_lbl = doc.add_paragraph()
    r_toc_lbl = p_toc_lbl.add_run("TABLE OF CONTENTS (TOC) GRAPHIC")
    r_toc_lbl.bold = True
    r_toc_lbl.font.size = Pt(10)
    p_toc_lbl.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    toc_img_path = os.path.join(work_dir, "TOC_Graphic.png")
    if os.path.exists(toc_img_path):
        p_toc_img = doc.add_paragraph()
        p_toc_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_toc_img.add_run().add_picture(toc_img_path, width=Inches(3.25), height=Inches(1.75))
        p_toc_img.paragraph_format.space_after = Pt(14)
        
    # Abstract
    p_abs_hd = doc.add_paragraph()
    r_abs_hd = p_abs_hd.add_run("ABSTRACT")
    r_abs_hd.bold = True
    r_abs_hd.font.size = Pt(12)
    p_abs_hd.paragraph_format.space_after = Pt(6)
    
    abstract_text = (
        "Optical pulling forces—the backward dragging of matter against incident photon momentum flux—remain challenging to achieve "
        "in lossy plasmonic nanomaterials due to intrinsic absorption-induced forward radiation pressure. Here, we demonstrate that a "
        "chiral gold nanorod (AuNR) helical superstructure immersed in water generates strong, polarization-selective optical pulling "
        "under non-paraxial left-circularly polarized (LCP) Bessel beam illumination (θ0 = 49.5°). Arranging ten Au nanorods (L = 60 nm, "
        "D = 15 nm) into a tapered-chirped hybrid helix drives near-in-phase co-excitation of electric dipole, magnetic dipole, and electric "
        "quadrupole moments (ΔΦ_ED-MD ≈ 12°, ΔΦ_ED-EQ ≈ 18°). This generalized multipolar interference suppresses backward scattering, "
        "elevating the forward-scattering asymmetry parameter to gasym = 0.954, well above the absorption-corrected threshold gcrit,abs = 0.721. "
        "Full-wave finite-difference time-domain (FDTD) simulations yield a peak optical pulling force of Fz = -10.50 pN/(W/μm²) at λ0 = 1060 nm "
        "across a continuous 285-nm negative-force band (λ = 875–1160 nm). Switching to right-circular polarization (RCP) reverses the momentum "
        "balance into forward pushing (Fz = +1.15 pN/(W/μm²)), providing polarity-reversible optical pulling (Cchiral = 1.00). The mechanism is "
        "cross-validated using finite element methods (FEM, 2.7% discrepancy), coupled dipole approximations (CDA, 5.5%), and boundary element "
        "scattering calculations (BEM, 3.8% in far-field asymmetry), offering foundational guidelines for chiral optomechanical manipulation."
    )
    p_abs = doc.add_paragraph(abstract_text)
    p_abs.paragraph_format.space_after = Pt(8)
    p_abs.paragraph_format.line_spacing = 1.15
    
    # Keywords
    p_kw = doc.add_paragraph()
    r_kwh = p_kw.add_run("Keywords: ")
    r_kwh.bold = True
    p_kw.add_run("Gold nanorods, Chiral plasmonics, Optical pulling, Bessel beams, Collective multipolar interference, Nanophotonics, Optical manipulation.")
    p_kw.paragraph_format.space_after = Pt(18)
    
    # Read in-line sections from 01_ACS_ANM_Manuscript.tex
    tex_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")
    with open(tex_path, "r", encoding="utf-8") as f:
        tex_content = f.read()
        
    # Split into structural blocks: headings, figures, tables, text
    token_pattern = re.compile(
        r'(\\section\{[^}]+\}|\\subsection\{[^}]+\}|\\subsubsection\{[^}]+\}|\\begin\{figure\}[\s\S]*?\\end\{figure\}|\\begin\{table\}[\s\S]*?\\end\{table\})'
    )
    tokens = token_pattern.split(tex_content)
    
    for tok in tokens:
        tok_str = tok.strip()
        if not tok_str:
            continue
            
        if tok_str.startswith(r'\section{'):
            m = re.search(r'\\section\{([^}]+)\}', tok_str)
            sec_title = clean_latex_text(m.group(1)) if m else ""
            if sec_title.lower() in ['abstract', 'keywords']:
                continue
            p = doc.add_paragraph()
            r = p.add_run(sec_title.upper())
            r.bold = True
            r.font.size = Pt(13)
            p.paragraph_format.space_before = Pt(16)
            p.paragraph_format.space_after = Pt(6)
            
        elif tok_str.startswith(r'\subsection{'):
            m = re.search(r'\\subsection\{([^}]+)\}', tok_str)
            subsec_title = clean_latex_text(m.group(1)) if m else ""
            p = doc.add_paragraph()
            r = p.add_run(subsec_title)
            r.bold = True
            r.font.size = Pt(11.5)
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(4)
            
        elif tok_str.startswith(r'\subsubsection{'):
            m = re.search(r'\\subsubsection\{([^}]+)\}', tok_str)
            subsubsec_title = clean_latex_text(m.group(1)) if m else ""
            p = doc.add_paragraph()
            r = p.add_run(subsubsec_title)
            r.bold = True
            r.italic = True
            r.font.size = Pt(11)
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(3)
            
        elif tok_str.startswith(r'\begin{figure}'):
            # In-line Figure!
            cap_m = re.search(r'\\caption\{([^}]+)\}', tok_str)
            fcaption = clean_latex_text(cap_m.group(1)) if cap_m else "Figure"
            img_m = re.search(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}', tok_str)
            if img_m:
                fpath = img_m.group(1)
                full_img_path = os.path.join(work_dir, fpath)
                if os.path.exists(full_img_path):
                    p_img = doc.add_paragraph()
                    p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p_img.paragraph_format.keep_with_next = True
                    p_img.paragraph_format.space_before = Pt(12)
                    p_img.paragraph_format.space_after = Pt(4)
                    p_img.add_run().add_picture(full_img_path, width=Inches(5.0))
                    
                    p_cap = doc.add_paragraph()
                    p_cap.paragraph_format.keep_with_next = False
                    p_cap.paragraph_format.space_after = Pt(14)
                    p_cap.paragraph_format.line_spacing = 1.15
                    r_cap = p_cap.add_run(fcaption)
                    r_cap.font.size = Pt(9.5)
                    r_cap.font.name = 'Times New Roman'
                    
        elif tok_str.startswith(r'\begin{table}'):
            # In-line Table!
            title, headers, rows = parse_latex_table(tok_str)
            if headers and rows:
                p_tbl_title = doc.add_paragraph()
                p_tbl_title.paragraph_format.keep_with_next = True
                p_tbl_title.paragraph_format.space_before = Pt(14)
                p_tbl_title.paragraph_format.space_after = Pt(4)
                r_tt = p_tbl_title.add_run(title)
                r_tt.bold = True
                r_tt.font.size = Pt(10.5)
                
                table = doc.add_table(rows=len(rows)+1, cols=len(headers))
                table.alignment = WD_TABLE_ALIGNMENT.CENTER
                set_table_borders(table)
                
                num_cols = len(headers)
                col_w = Inches(6.5 / num_cols)
                
                # Header row
                hdr_cells = table.rows[0].cells
                for col_idx, header_text in enumerate(headers):
                    hdr_cells[col_idx].text = header_text
                    p_cell = hdr_cells[col_idx].paragraphs[0]
                    p_cell.runs[0].bold = True
                    p_cell.runs[0].font.size = Pt(9.5)
                    set_cell_margins(hdr_cells[col_idx], top=80, bottom=80, left=100, right=100)
                    
                # Data rows
                for row_idx, row_data in enumerate(rows):
                    row_cells = table.rows[row_idx+1].cells
                    for col_idx, cell_value in enumerate(row_data):
                        if col_idx < len(row_cells):
                            row_cells[col_idx].text = cell_value
                            p_cell = row_cells[col_idx].paragraphs[0]
                            if p_cell.runs:
                                p_cell.runs[0].font.size = Pt(9)
                            set_cell_margins(row_cells[col_idx], top=60, bottom=60, left=100, right=100)
                            
                for r_idx, row in enumerate(table.rows):
                    set_row_cant_split(row)
                    if r_idx == 0:
                        set_row_header(row)
                    for c_idx, cell in enumerate(row.cells):
                        cell.width = col_w
                doc.add_paragraph().paragraph_format.space_after = Pt(8)
                
        else:
            # Body text
            lines = [l for l in tok_str.splitlines() if not l.strip().startswith('%')]
            body = '\n'.join(lines)
            body = re.sub(r'\\begin\{equation\}[\s\S]*?\\end\{equation\}', '', body)
            body = re.sub(r'\\begin\{align\}[\s\S]*?\\end\{align\}', '', body)
            body = re.sub(r'\\bibliography\{[^}]+\}', '', body)
            body = re.sub(r'\\end\{document\}', '', body)
            
            raw_paras = body.split('\n\n')
            for rp in raw_paras:
                cleaned = clean_latex_text(rp)
                if len(cleaned) > 20 and not cleaned.startswith('\\'):
                    p = doc.add_paragraph(cleaned)
                    p.paragraph_format.space_after = Pt(6)
                    p.paragraph_format.line_spacing = 1.15
                    
    # References section
    p_ref_hd = doc.add_paragraph()
    r = p_ref_hd.add_run("REFERENCES")
    r.bold = True
    r.font.size = Pt(13)
    p_ref_hd.paragraph_format.space_before = Pt(20)
    p_ref_hd.paragraph_format.space_after = Pt(8)
    
    bbl_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.bbl")
    if os.path.exists(bbl_path):
        with open(bbl_path, "r", encoding="utf-8") as f:
            bbl_text = f.read()
        entries = re.split(r'\\bibitem(?:\[[^\]]*\])?\{[^}]+\}', bbl_text)[1:]
        for idx, entry in enumerate(entries):
            clean_entry = clean_latex_text(entry.strip())
            clean_entry = re.sub(r'\\newblock', ' ', clean_entry)
            clean_entry = re.sub(r'\s+', ' ', clean_entry)
            if clean_entry:
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Inches(0.3)
                p.paragraph_format.first_line_indent = Inches(-0.3)
                p.paragraph_format.space_after = Pt(4)
                p.paragraph_format.line_spacing = 1.1
                
                r_num = p.add_run(f"[{idx+1}] ")
                r_num.bold = True
                r_num.font.size = Pt(9.5)
                
                r_txt = p.add_run(clean_entry)
                r_txt.font.size = Pt(9.5)
                
    docx_out = os.path.join(work_dir, "02_ACS_ANM_Manuscript.docx")
    doc.save(docx_out)
    print(f"SUCCESS: Saved {docx_out} with fully in-line figures and tables ({os.path.getsize(docx_out)} bytes)")

build_manuscript_docx()
