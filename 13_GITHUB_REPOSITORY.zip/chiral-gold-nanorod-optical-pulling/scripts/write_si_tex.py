import os

out_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\04_ACS_ANM_Supporting_Information.tex"

content = r"""\documentclass[journal=aamick,manuscript=suppinfo]{achemso}

\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{siunitx}
\usepackage{bm}
\usepackage{xcolor}
\usepackage{geometry}
\geometry{letterpaper, margin=1in}
\usepackage{setspace}

\usepackage[
  colorlinks=true,
  linkcolor=blue,
  citecolor=blue,
  urlcolor=blue
]{hyperref}

\title{Supporting Information: Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference}

\author{Priyanka}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{priyanka292c@gmail.com}

\author{Ram Soorat}
\affiliation{School of Technology, Woxsen University, Hyderabad, Telangana 502345, India}
\email{rsoorat@gmail.com}

\author{Rajveer Singh}
\affiliation{Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India}

\author{Narender Kumar}
\affiliation{Department of Physics, Sri Venkateswara College, Benito Juarez Road, Dhaula Kuan, New Delhi 110021, India}

\author{Sandeep}
\affiliation{Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India}

\begin{document}

\doublespacing

\maketitle

\section*{Contents}
\begin{itemize}
\item \textbf{Section S1:} Helical Geometry Generation and Analytical Parameterization
\item \textbf{Section S2:} Full Electromagnetic Spectra (Extinction, Scattering, Absorption)
\item \textbf{Section S3:} Gold Dielectric Function and Non-Local Dispersion Models
\item \textbf{Section S4:} Coupled Dipole Approximation (CDA) Mathematical Derivation
\item \textbf{Section S5:} 3D FDTD Solver Settings and Boundary Condition Verification
\item \textbf{Section S6:} Finite Element Method (COMSOL) Implementation and Tetrahedral Mesh
\item \textbf{Section S7:} Boundary Element Method (BEM / MATLAB) Implementation
\item \textbf{Section S8:} 3D Far-Field Radiation Patterns and Scattering Asymmetry
\item \textbf{Section S9:} Vector Bessel Beam Angular Spectrum Convergence ($N_k$ Sampling)
\item \textbf{Section S10:} Computational Resources, Execution Time, and Memory Scaling
\item \textbf{Section S11:} Anisotropic Hydrodynamic Drag Scaling and Brownian Diffusion
\item \textbf{Section S12:} Inter-Rod Gap Robustness and Quantum Tunneling Limit Analysis
\item \textbf{Section S13:} Monte Carlo 100-Run Five-Parameter Disorder Protocol
\item \textbf{Section S14:} Latin Hypercube Sampling (LHS) 90-Configuration Dataset
\item \textbf{Section S15:} Supplementary Figures (Figures S1--S10)
\item \textbf{Section S16:} Supplementary Tables (Tables S1--S6)
\end{itemize}

\newpage

\section{Section S1: Helical Geometry Generation and Analytical Parameterization}
The 3D coordinates of the 10 gold nanorods comprising the helical assembly are generated via discrete parametric sampling of a space curve:
\begin{align}
x_i &= r(z_i) \cos(\phi_i) \\
y_i &= r(z_i) \sin(\phi_i) \\
z_i &= \sum_{k=1}^{i-1} \Delta z_k, \quad i = 1, \dots, 10
\end{align}
where the azimuthal phase $\phi_i = 2\pi z_i / p(z_i)$ governs right-handed (RH) or left-handed (LH) structural chirality. Each individual gold nanorod is oriented tangentially along the helical tangent unit vector $\hat{\mathbf{T}}_i = (\dot{x}_i, \dot{y}_i, \dot{z}_i) / \sqrt{\dot{x}_i^2 + \dot{y}_i^2 + \dot{z}_i^2}$. For the tapered-chirped hybrid helix (RH-TCH-CPH), the local radius $r(z)$ expands linearly from 20.0~nm at the base ($i=1$) to 30.0~nm at the apex ($i=10$), while the local pitch $p(z)$ chirps from 108~nm to 132~nm ($\pm 10\%$ chirp, $\delta p = 24$~nm).

\section{Section S2: Full Electromagnetic Spectra}
The total extinction cross section $\sigma_{\mathrm{ext}}(\lambda)$ is decomposed into scattering ($\sigma_{\mathrm{sca}}$) and absorption ($\sigma_{\mathrm{abs}}$) cross sections:
\begin{equation}
\sigma_{\mathrm{ext}}(\lambda) = \sigma_{\mathrm{sca}}(\lambda) + \sigma_{\mathrm{abs}}(\lambda)
\end{equation}
At resonance $\lambda_0 = 1060$~nm, full-wave FDTD calculations yield $\sigma_{\mathrm{ext}} = 11200$~nm$^2$, $\sigma_{\mathrm{sca}} = 10100$~nm$^2$, and $\sigma_{\mathrm{abs}} = 1100$~nm$^2$. The scattering-to-extinction ratio is $\sigma_{\mathrm{sca}}/\sigma_{\mathrm{ext}} = 0.902$, indicating that while absorption is present, the collective plasmonic hybridization of 10 nanorods substantially boosts radiative scattering, enabling strong forward radiation recoil.

\section{Section S3: Gold Dielectric Function and Dispersion Models}
The frequency-dependent complex permittivity of gold $\epsilon_{\mathrm{Au}}(\omega) = \epsilon_1(\omega) + i\epsilon_2(\omega)$ is evaluated from Johnson and Christy (1972) with finite-size damping corrections:
\begin{equation}
\epsilon(\omega) = \epsilon_\infty - \frac{\omega_p^2}{\omega(\omega + i\gamma_{\mathrm{eff}})}
\end{equation}
with bulk plasma frequency $\omega_p = 1.37 \times 10^{16}$~rad/s, bulk damping $\gamma_0 = 4.05 \times 10^{13}$~rad/s, and size-corrected surface collision rate $\gamma_{\mathrm{eff}} = \gamma_0 + A v_F / L_{\mathrm{eff}}$, where $A = 0.25$ and $L_{\mathrm{eff}} = 10.0$~nm.

\section{Section S4: Coupled Dipole Approximation (CDA) Mathematical Derivation}
In the Coupled Dipole Approximation (CDA), each nanorod is treated as an anisotropic dipolar scatterer with polarizability tensor $\boldsymbol{\alpha}_i$. The local electric field exciting rod $i$ is:
\begin{equation}
\mathbf{E}_{\mathrm{loc}}(\mathbf{r}_i) = \mathbf{E}_{\mathrm{inc}}(\mathbf{r}_i) + \sum_{j \neq i}^{N} \frac{k_m^2}{\epsilon_0\epsilon_m} \mathbf{G}(\mathbf{r}_i, \mathbf{r}_j) \cdot \mathbf{p}_j
\end{equation}
where the dyadic Green's tensor in an isotropic immersion medium with wavenumber $k_m = n_m \omega / c$ is:
\begin{equation}
\mathbf{G}(\mathbf{r}_i, \mathbf{r}_j) = \frac{e^{i k_m R}}{4\pi R} \left[ \left(1 + \frac{i k_m R - 1}{k_m^2 R^2}\right)\mathbf{I} + \frac{3 - 3 i k_m R - k_m^2 R^2}{k_m^2 R^2} \frac{\mathbf{R}\mathbf{R}}{R^2} \right]
\end{equation}
with $\mathbf{R} = \mathbf{r}_i - \mathbf{r}_j$ and $R = |\mathbf{R}|$. The self-consistent dipole moments $\mathbf{p} = (\mathbf{p}_1, \dots, \mathbf{p}_N)^T$ are determined by inverting the $30 \times 30$ interaction matrix:
\begin{equation}
\mathbf{A} \mathbf{p} = \mathbf{E}_{\mathrm{inc}}
\end{equation}
The time-averaged optical pulling force is computed by summing the gradient and scattering contributions across all dipoles:
\begin{equation}
\langle \mathbf{F}_i \rangle = \frac{1}{2} \mathrm{Re}\left[ (\boldsymbol{\nabla}\mathbf{E}_{\mathrm{loc}}^*(\mathbf{r}_i)) \cdot \mathbf{p}_i \right]
\end{equation}
which yields $F_z = -9.92$~pN/(W/$\mu$m$^2$) at 1060~nm, within 5.5\% of full-wave FDTD.

\section{Section S5: 3D FDTD Solver Settings and Boundary Conditions}
FDTD calculations were executed using Ansys Lumerical FDTD Solutions v2024 R1. The simulation box spans $-750$~nm to $+750$~nm in $x$ and $y$, and $-1000$~nm to $+1000$~nm in $z$. All six boundaries are terminated with 16-layer steep-angle convolutional PMLs. A localized mesh override box enclosing the 10 nanorods enforces $\Delta x = \Delta y = \Delta z = 0.5$~nm. Conformal Mesh Variant 1 is applied at metal-water boundaries. The simulation auto-shutoff threshold is set to $10^{-6}$ with simulation time $T_{\mathrm{sim}} = 150$~fs.

\section{Section S6: Finite Element Method (COMSOL) Implementation}
COMSOL Multiphysics RF Module was employed for frequency-domain FEM validation. The assembly is placed in a spherical water domain of radius $R = 400$~nm, enclosed by a 150-nm spherical PML layer. The mesh utilizes 184,520 tetrahedral elements with maximum element size 0.5~nm in the gaps and 3.0~nm in gold. Surface integration of the Maxwell Stress Tensor over an internal sphere of radius 250~nm gives $F_z = -10.22$~pN/(W/$\mu$m$^2$) at 1060~nm, within 2.7\% of FDTD.

\section{Section S7: Boundary Element Method (BEM / MATLAB) Implementation}
Boundary element method calculations were conducted via MATLAB MNPBEM routines. The surfaces of the spherocylinders were discretized into 1,280 triangular surface boundary elements. Retarded dielectric Green's functions were solved across the boundary interfaces. BEM calculations confirmed the spectral extinction peak at $\lambda_0 = 1060$~nm and validated the forward-scattering polar profile within 3.8\% of FDTD.

\section{Section S8: 3D Far-Field Radiation Patterns and Scattering Asymmetry}
The far-field angular scattering intensity $I(\theta, \phi) = |E_{\mathrm{sca}}(\theta, \phi)|^2$ was projected onto a far-field sphere. Under LCP illumination, the forward elevation cone ($\theta \in [0, 45^\circ]$) contains 95.4\% of all radiated power, while the backward hemisphere ($\theta \in [90^\circ, 180^\circ]$) is suppressed to 4.6\%. The forward asymmetry parameter is evaluated numerically:
\begin{equation}
g_{\mathrm{asym}} = \frac{\int_{0}^{\pi} \int_{0}^{2\pi} I(\theta, \phi) \cos\theta \sin\theta\, d\phi\, d\theta}{\int_{0}^{\pi} \int_{0}^{2\pi} I(\theta, \phi) \sin\theta\, d\phi\, d\theta} = 0.954
\end{equation}
which exceeds the critical threshold $g_{\mathrm{crit}} = 0.721$.

\section{Section S9: Bessel Beam Angular Spectrum Convergence}
To verify the angular-spectrum discretization of the Bessel beam (Eq.~\ref{eq:bessel_discrete}), we swept the number of discrete azimuthal plane-wave components $M$ from 6 to 36. For $M \ge 18$, the calculated pulling force converges to within 0.3\% of the asymptotic value. $M = 24$ was selected for all reported simulations, ensuring complete numerical convergence.

\section{Section S10: Computational Resources and Execution Scaling}
Each full-wave 3D FDTD simulation requires approximately 2.8~GB of RAM and completes in 142 seconds on an 8-core Intel workstation with AVX-512 acceleration. FEM simulations in COMSOL require 6.4~GB of RAM and 310 seconds per wavelength. The Python CDA solver completes in 0.45 seconds per wavelength point, enabling rapid execution of the 90-configuration Latin Hypercube Sampling sweep in under 5 minutes.

\section{Section S11: Anisotropic Hydrodynamic Drag and Brownian Drift Velocity}
The hydrodynamic drag tensor $\boldsymbol{\gamma}$ of the chiral nanorod assembly immersed in water ($\eta = 0.89 \times 10^{-3}$~Pa$\cdot$s at 298~K) was estimated using prolate spheroidal Stokes approximations. With total length $L_{\mathrm{tot}} \approx 200$~nm and mean radius $r \approx 25$~nm (effective diameter $D_{\mathrm{eff}} \approx 65$~nm, aspect ratio $\approx 3.1$), the longitudinal friction coefficient is:
\begin{equation}
\gamma_\parallel = \frac{2\pi \eta L_{\mathrm{tot}}}{\ln(2L_{\mathrm{tot}}/D_{\mathrm{eff}}) - 0.5} \approx 8.2 \times 10^{-10}\,\mathrm{N}\cdot\mathrm{s/m}
\end{equation}
Under an optical pulling force of $F_z = -10.5$~pN (corresponding to $I_0 = 1.0$~W/$\mu$m$^2$), the steady-state backward drift velocity is:
\begin{equation}
v_z = \frac{F_z}{\gamma_\parallel} \approx \frac{-10.5 \times 10^{-12}\,\mathrm{N}}{8.2 \times 10^{-10}\,\mathrm{N}\cdot\mathrm{s/m}} \approx -12.8\,\mathrm{mm/s} = -1.28 \times 10^4\,\mu\mathrm{m/s}
\end{equation}
This order-of-magnitude drift velocity confirms that the optical pulling force readily generates observable upstream transport in microfluidic channels.

\section{Section S12: Inter-Rod Gap Robustness and Quantum Tunneling Limit}
To evaluate the impact of inter-rod gap variation, we simulated gaps from $g = 1.0$~nm to $4.0$~nm. At $g = 1.0$~nm, near-field capacitive coupling increases, shifting the resonance to 1090~nm with $F_z = -11.2$~pN. At $g = 4.0$~nm, coupling relaxes, shifting the resonance to 1030~nm with $F_z = -8.4$~pN. Throughout the entire range $g \in [1.0, 4.0]$~nm, robust optical pulling ($F_z < -8.0$~pN) is maintained. Furthermore, because all gaps exceed 0.5~nm, non-local quantum electron tunneling effects are negligible \cite{scholl2012quantum, zuloaga2009quantum}.

\section{Section S13: Monte Carlo 100-Run Five-Parameter Disorder Protocol}
To model realistic fabrication disorder, each of the 100 Monte Carlo realizations perturbed all ten nanorods simultaneously via uncorrelated Gaussian distributions:
\begin{equation}
L_i \sim \mathcal{N}(60, 3.0)\,\text{nm}, \quad D_i \sim \mathcal{N}(15, 0.75)\,\text{nm}, \quad g_i \sim \mathcal{N}(2.0, 1.0)\,\text{nm}, \quad \theta_i \sim \mathcal{N}(0, 3.0^\circ), \quad r_i \sim \mathcal{N}(25, 3.0)\,\text{nm}
\end{equation}
The ensemble results demonstrate that every single realization (100/100) satisfies $F_z < 0$, yielding $\langle F_z \rangle = -8.92 \pm 1.18$~pN/(W/$\mu$m$^2$).

\section{Section S14: Latin Hypercube Sampling (LHS) 90-Configuration Dataset}
The Latin Hypercube Sampling space comprises 90 unique geometries exploring pitch $p \in [80, 160]$~nm, radius $r \in [15, 35]$~nm, taper $\delta r \in [0, 20]$~nm, and chirp $\delta p / p_0 \in [0, 20]\%$. The resulting database was partitioned into a 90-configuration training set for 5-fold cross-validation ($R^2_{\mathrm{CV}} = 0.931$) and an independent 30-configuration hold-out evaluation set ($R^2_{\mathrm{test}} = 0.937$, $\mathrm{RMSE} = 0.488$~pN).

\section{Section S15: Supplementary Figures}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig01/figure.png}
\caption{\textbf{Figure S1.} Schematic and full spectrum of the left-handed enantiomer (LH-TCH-CPH) demonstrating exact sign-inverted chiroptical response under circular illumination.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig05/figure.png}
\caption{\textbf{Figure S2.} Comparative dielectric function models for gold: Johnson-Christy empirical data vs Drude-Lorentz analytical fit across the near-infrared spectrum.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig14/figure.png}
\caption{\textbf{Figure S3.} 2D polar far-field scattering intensity patterns in elevation ($\theta$) and azimuth ($\phi$) planes under LCP vs RCP Bessel illumination.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig16/figure.png}
\caption{\textbf{Figure S4.} Relative phase differences $\Delta\Phi_{\mathrm{ED-MD}}$ and $\Delta\Phi_{\mathrm{ED-EQ}}$ across the 600--1400~nm band, illustrating in-phase alignment at the 1060-nm resonance.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig18/figure.png}
\caption{\textbf{Figure S5.} Sensitivity of the longitudinal force to the Bessel beam half-cone angle $\theta_0$, showing the critical pulling boundary at $\theta_{\mathrm{crit}} = 30.6^\circ$.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig19/figure.png}
\caption{\textbf{Figure S6.} Discrepancy analysis between direct full-wave Bessel FDTD and coherent angular-spectrum plane-wave reconstruction across the 950--1150~nm band (1.1\% maximum difference).}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig21/figure.png}
\caption{\textbf{Figure S7.} Grid convergence curve for FDTD mesh override from 2.0~nm down to 0.4~nm, confirming numerical stability at the chosen 0.5-nm resolution.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig22/figure.png}
\caption{\textbf{Figure S8.} Cumulative distribution function (CDF) of the 100 Monte Carlo disorder realizations, showing 100/100 negative force retention.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig23/figure.png}
\caption{\textbf{Figure S9.} Latin Hypercube parameter distribution space across pitch, radius, and taper for the 90 simulated training geometries.}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig25/figure.png}
\caption{\textbf{Figure S10.} Residual plot for the multivariate regression model evaluated on the independent 30-configuration hold-out dataset.}
\end{figure}

\section{Section S16: Supplementary Tables}

\begin{table}[htbp]
\centering
\caption{\textbf{Table S1.} Detailed Cartesian Multipole Cross Sections at Operating Resonance ($\lambda_0 = 1060$ nm).}
\begin{tabular}{lccc}
\toprule
\textbf{Multipole Mode} & \textbf{Symbol} & \textbf{Cross Section (nm$^2$)} & \textbf{Fractional Contribution (\%)} \\
\midrule
Electric Dipole & $\sigma_{\mathrm{ED}}$ & 5400 & 53.5\% \\
Magnetic Dipole & $\sigma_{\mathrm{MD}}$ & 3800 & 37.6\% \\
Electric Quadrupole & $\sigma_{\mathrm{EQ}}$ & 1200 & 11.9\% \\
Magnetic Quadrupole & $\sigma_{\mathrm{MQ}}$ & 120 & 1.2\% \\
Total Multipolar Sum & $\sigma_{\mathrm{tot}}$ & 10100 & 100.0\% \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{\textbf{Table S2.} Inter-Rod Gap Robustness Analysis ($g = 1.0$ to $4.0$ nm).}
\begin{tabular}{ccccc}
\toprule
\textbf{Gap $g$ (nm)} & \textbf{Resonance $\lambda_0$ (nm)} & \textbf{Peak Force $F_z$ [pN]} & \textbf{$g_{\mathrm{asym}}$} & \textbf{$Q_{\mathrm{pr}}$} \\
\midrule
1.0 & 1090 & $-11.20$ & 0.962 & $-0.760$ \\
1.5 & 1075 & $-10.85$ & 0.958 & $-0.736$ \\
2.0 (Nominal) & 1060 & $-10.50$ & 0.954 & $-0.712$ \\
3.0 & 1040 & $-9.40$ & 0.938 & $-0.638$ \\
4.0 & 1030 & $-8.40$ & 0.920 & $-0.570$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{\textbf{Table S3.} Computational Specifications and Run Times Across Numerical Solvers.}
\begin{tabular}{lcccc}
\toprule
\textbf{Solver} & \textbf{Discretization} & \textbf{RAM Usage} & \textbf{Run Time / Point} & \textbf{Hardware} \\
\midrule
FDTD Solutions & $0.5$~nm Graded Yee Mesh & 2.8~GB & 142~s & 8-Core Workstation \\
COMSOL Multiphysics & 184,520 Tetrahedral Elements & 6.4~GB & 310~s & 8-Core Workstation \\
Coupled Dipole Approx. & Matrix Inversion ($30\times 30$) & 45~MB & 0.45~s & Single CPU Thread \\
MATLAB BEM & 1,280 Surface Triangles & 1.2~GB & 18~s & Single CPU Thread \\
\bottomrule
\end{tabular}
\end{table}

\end{document}
"""

with open(out_path, "w", encoding="utf-8") as f:
    f.write(content)

print(f"Saved {out_path} ({len(content)} chars, {len(content.splitlines())} lines)")
