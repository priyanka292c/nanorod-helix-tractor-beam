import pandas as pd
df = pd.read_csv('figures/Fig21/processed_data.csv')
for target in [0.2, 0.3, 0.4, 0.5, 0.8, 1.0, 2.0]:
    row = df.iloc[(df['mesh_grid_size_dx_nm'] - target).abs().argmin()]
    dx = row['mesh_grid_size_dx_nm']
    fz = row['Fz_FDTD_converged_pN']
    err = row['relative_error_pct']
    print(f"Target: {target:3.1f} nm -> Actual dx: {dx:5.3f} nm | Fz: {fz:6.2f} pN | Rel Error: {err:4.1f}%")
