import re

src_bib = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant\references.bib"
with open(src_bib, "r", encoding="utf-8") as f:
    text = f.read()

entries = re.split(r'\n@', text)
all_bib_keys = []
bib_dict = {}
for block in entries:
    if not block.strip(): continue
    lines = block.split('\n')
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', lines[0].strip().lstrip('@'))
    if m:
        etype = m.group(1).lower()
        key = m.group(2).strip()
        all_bib_keys.append(key)
        doi_m = re.search(r'doi\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        year_m = re.search(r'year\s*=\s*[\"{]?(\d{4})[\"}]?', block)
        title_m = re.search(r'title\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        journal_m = re.search(r'journal\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        bib_dict[key] = {
            "key": key,
            "etype": etype,
            "doi": doi_m.group(1).strip() if doi_m else "",
            "year": year_m.group(1).strip() if year_m else "",
            "title": title_m.group(1).strip() if title_m else "",
            "journal": journal_m.group(1).strip() if journal_m else ""
        }

from get_cited_keys import all_unique_cites

uncited = [k for k in all_bib_keys if k not in all_unique_cites]
print(f"Total keys in bib: {len(all_bib_keys)}")
print(f"Uncited keys in bib: {len(uncited)}")
for u in uncited:
    item = bib_dict[u]
    print(f"  [{u}] ({item['year']}) DOI: {item['doi']} | {item['title'][:50]} | {item['journal']}")
