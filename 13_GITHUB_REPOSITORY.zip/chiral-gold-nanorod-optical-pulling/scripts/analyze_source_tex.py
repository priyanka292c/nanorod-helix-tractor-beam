import re

src_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant"

def analyze_tex(filename):
    with open(f"{src_dir}\\{filename}", "r", encoding="utf-8") as f:
        text = f.read()
    
    print(f"=== {filename} ({len(text)} chars, {len(text.splitlines())} lines) ===")
    sections = re.findall(r'\\(section|subsection|subsubsection)\*?\{([^}]+)\}', text)
    for stype, sname in sections:
        indent = "  " if stype == "subsection" else ("    " if stype == "subsubsection" else "")
        print(f"{indent}- [{stype}] {sname}")
    
    figures = re.findall(r'\\begin\{figure\*?\}.*?\\caption\{([^}]+)\}.*?\\end\{figure\*?\}', text, re.DOTALL)
    print(f"Total figure environments: {len(figures)}")
    
    tables = re.findall(r'\\begin\{table\*?\}.*?\\caption\{([^}]+)\}.*?\\end\{table\*?\}', text, re.DOTALL)
    print(f"Total table environments: {len(tables)}")
    
    equations = re.findall(r'\\begin\{(equation|align|split|gather)\*?\}(.*?)\\end\{\1\*?\}', text, re.DOTALL)
    print(f"Total equation environments: {len(equations)}")
    print()

analyze_tex("main.tex")
analyze_tex("supplementary.tex")
