import os
import re

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"
tex_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")

with open(tex_path, "r", encoding="utf-8") as f:
    text = f.read()

# 1. Remove '(plotted in Fig XX)' from captions
text = re.sub(r'\(plotted in Fig \d+\)', '', text)
text = text.replace('  ', ' ')

# 2. Standardize Fig03 and Fig17 if they still have the old template
text = text.replace(
    r"""\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig03/figure.png}
\caption{Coordinate system and geometric parameters. Canonical dimensions of the Au nanorod assembly, including aspect ratio ($\text{AR}=4.0$) and inter-rod nominal gap ($g=2.0$~nm). As shown in Figure 3, parameters are optimized for near-field capacitive hybridization.}
\label{fig:fig03}
\end{figure}""",
    r"""\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.38\textheight,keepaspectratio]{figures/Fig03/figure.png}
{\singlespacing
\caption{Coordinate system and geometric parameters. Canonical dimensions of the Au nanorod assembly, including aspect ratio ($\text{AR}=4.0$) and inter-rod nominal gap ($g=2.0$~nm). As shown in Figure 3, parameters are optimized for near-field capacitive hybridization.}
\label{fig:fig03}
}
\end{figure}"""
)

text = text.replace(
    r"""\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig17/figure.png}
\caption{Forward scattering asymmetry parameter $g_{\mathrm{asym}}(\lambda)$ compared with the critical pulling threshold $g_{\mathrm{crit}} = 0.721$. As shown in Figure 13, $g_{\mathrm{asym}}$ peaks at 0.954, decisively fulfilling the optical pulling momentum criterion.}
\label{fig:fig17}
\end{figure}""",
    r"""\begin{figure}[!htbp]
\centering
\includegraphics[width=0.68\textwidth,height=0.38\textheight,keepaspectratio]{figures/Fig17/figure.png}
{\singlespacing
\caption{Forward scattering asymmetry parameter $g_{\mathrm{asym}}(\lambda)$ compared with the critical pulling threshold $g_{\mathrm{crit}} = 0.721$. As shown in Figure 13, $g_{\mathrm{asym}}$ peaks at 0.954, decisively fulfilling the optical pulling momentum criterion.}
\label{fig:fig17}
}
\end{figure}"""
)

with open(tex_path, "w", encoding="utf-8") as f:
    f.write(text)

print("Cleaned figure captions and standardized all figures in 01_ACS_ANM_Manuscript.tex!")
