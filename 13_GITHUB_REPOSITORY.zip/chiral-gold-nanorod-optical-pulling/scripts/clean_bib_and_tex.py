import re

bib_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\08_references.bib"
tex_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\01_ACS_ANM_Manuscript.tex"

# Clean bib file
with open(bib_path, "r", encoding="utf-8") as f:
    bib_text = f.read()

# Fix dogariu
bib_text = re.sub(
    r'author\s*=\s*\{Dogariu, Aristide and Sukhov, Sergey and S.*?\},',
    'author    = {Dogariu, Aristide and Sukhov, Sergey and S{\\\'a}enz, Juan Jos{\\\'e}},',
    bib_text
)

# Fix yin2013interpreting
bib_text = re.sub(
    r'author\s*=\s*\{Yin, Xinghui and Sch.*?\},',
    'author    = {Yin, Xinghui and Sch{\\\"a}ferling, Martin and Metzger, Bernd and Giessen, Harald},',
    bib_text
)

with open(bib_path, "w", encoding="utf-8") as f:
    f.write(bib_text)
print("Cleaned 08_references.bib.")

# Clean tex file
with open(tex_path, "r", encoding="utf-8") as f:
    tex_text = f.read()

tex_text = tex_text.replace("li2022naturecomm_tractor", "zhao2024natcomm_tractor")
tex_text = tex_text.replace("taflove2005computational", "yee1966numerical")
tex_text = tex_text.replace("jin2015finite", "chaumet2002coupled")
tex_text = tex_text.replace("zhang2021prl_pulling", "ding2024appliedoptics_pulling")

with open(tex_path, "w", encoding="utf-8") as f:
    f.write(tex_text)
print("Updated 01_ACS_ANM_Manuscript.tex citation keys.")
