import os

script_path = r"C:\Users\I7\.gemini\antigravity-ide\brain\d76ce4c8-2e78-4d3e-a196-e5bd03adf4b5\scratch\regenerate_dense_500_datapoints.py"

with open(script_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
skip = False
paren_count = 0
removed_count = 0

for line in lines:
    stripped = line.strip()
    # Check if comment relates to annotation badge
    if stripped.startswith("# Annotation showing mesh size") or stripped.startswith("# Prominent text box showing solvers"):
        continue
    if not skip and (stripped.startswith("ax.text(") or stripped.startswith("ax1.text(")):
        skip = True
        paren_count = line.count("(") - line.count(")")
        removed_count += 1
        if paren_count <= 0:
            skip = False
        continue
    if skip:
        paren_count += line.count("(") - line.count(")")
        if paren_count <= 0:
            skip = False
        continue
    new_lines.append(line)

print(f"Removed {removed_count} text badge annotations. Writing updated script...")

with open(script_path, "w", encoding="utf-8") as f:
    f.writelines(new_lines)

print("SUCCESS: Updated regenerate_dense_500_datapoints.py without text box badges!")
