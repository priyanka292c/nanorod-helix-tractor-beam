import os
import re

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

def fix_main_manuscript():
    tex_path = os.path.join(work_dir, "01_ACS_ANM_Manuscript.tex")
    with open(tex_path, "r", encoding="utf-8") as f:
        text = f.read()

    # 1. Fix all tables in 01_ACS_ANM_Manuscript.tex
    def replace_table(m):
        caption = m.group(1).strip()
        label = m.group(2).strip()
        tabular_body = m.group(3).strip()
        return f"""\\begin{{table}}[!htbp]
\\centering
\\small
\\singlespacing
\\caption{{{caption}}}
\\label{{{label}}}
\\resizebox{{\\columnwidth}}{{!}}{{%
{tabular_body}%
}}
\\end{{table}}
"""

    text = re.sub(
        r'\\begin\{table\}\[htbp\]\s*\\centering\s*\\caption\{([^}]+)\}\s*\\label\{([^}]+)\}\s*(\\begin\{tabular\}[\s\S]*?\\end\{tabular\})\s*\\end\{table\}',
        replace_table,
        text
    )

    # Add \clearpage between tables to prevent stacking
    # We can separate tables with \clearpage
    table_pattern = r'(\\end\{table\}\n)'
    # Every 2 tables, let's add a \clearpage
    parts = re.split(table_pattern, text)
    # Let's count tables and add clearpage every 2 tables
    new_parts = []
    tbl_count = 0
    in_tables_sec = False
    for p in parts:
        if "\\section*{Tables}" in p:
            in_tables_sec = True
        if "\\section*{Figures}" in p:
            in_tables_sec = False
        if p == "\\end{table}\n":
            tbl_count += 1
            if in_tables_sec and tbl_count % 2 == 0:
                new_parts.append(p + "\\clearpage\n")
            else:
                new_parts.append(p)
        else:
            new_parts.append(p)
    text = "".join(new_parts)

    # 2. Fix all figures in 01_ACS_ANM_Manuscript.tex
    def replace_figure(m):
        img_path = m.group(1).strip()
        caption = m.group(2).strip()
        label = m.group(3).strip()
        return f"""\\begin{{figure}}[!htbp]
\\centering
\\includegraphics[width=0.68\\textwidth,height=0.38\\textheight,keepaspectratio]{{{img_path}}}
{{\\singlespacing
\\caption{{{caption}}}
\\label{{{label}}}
}}
\\end{{figure}}
"""

    text = re.sub(
        r'\\begin\{figure\}\[htbp\]\s*\\centering\s*\\includegraphics\[[^\]]+\]\{([^}]+)\}\s*\\caption\{([^}]+)\}\s*\\label\{([^}]+)\}\s*\\end\{figure\}',
        replace_figure,
        text
    )

    # Add \clearpage between figures every 2 figures
    fig_parts = re.split(r'(\\end\{figure\}\n)', text)
    new_fig_parts = []
    fig_count = 0
    in_figs_sec = False
    for fp in fig_parts:
        if "\\section*{Figures}" in fp:
            in_figs_sec = True
        if fp == "\\end{figure}\n":
            fig_count += 1
            if in_figs_sec and fig_count % 2 == 0:
                new_fig_parts.append(fp + "\\clearpage\n")
            else:
                new_fig_parts.append(fp)
        else:
            new_fig_parts.append(fp)
    text = "".join(new_fig_parts)

    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(text)
    print("Updated 01_ACS_ANM_Manuscript.tex layout successfully.")

def fix_si_manuscript():
    si_path = os.path.join(work_dir, "04_ACS_ANM_Supporting_Information.tex")
    with open(si_path, "r", encoding="utf-8") as f:
        text = f.read()

    # 1. Fix overfull equation in Section S13
    old_eq = r"""\begin{equation}
L_i \sim \mathcal{N}(60, 3.0)\,\text{nm}, \quad D_i \sim \mathcal{N}(15, 0.75)\,\text{nm}, \quad g_i \sim \mathcal{N}(2.0, 1.0)\,\text{nm}, \quad \theta_i \sim \mathcal{N}(0, 3.0^\circ), \quad r_i \sim \mathcal{N}(25, 3.0)\,\text{nm}
\end{equation}"""
    
    new_eq = r"""\begin{align}
L_i &\sim \mathcal{N}(60, 3.0)\,\text{nm}, \quad D_i \sim \mathcal{N}(15, 0.75)\,\text{nm}, \quad g_i \sim \mathcal{N}(2.0, 1.0)\,\text{nm}, \nonumber \\
\theta_i &\sim \mathcal{N}(0, 3.0^\circ), \quad r_i \sim \mathcal{N}(25, 3.0)\,\text{nm}
\end{align}"""
    text = text.replace(old_eq, new_eq)

    # 2. Fix Section S7 overfull section title if needed
    text = text.replace(
        r"\section{Section S7: Boundary Element Method (BEM / MATLAB MNPBEM)}",
        r"\section{Section S7: Boundary Element Method (BEM / MNPBEM)}"
    )

    # 3. Fix tables in Section S16
    def replace_si_table(m):
        caption = m.group(1).strip()
        tabular_body = m.group(2).strip()
        return f"""\\begin{{table}}[!htbp]
\\centering
\\small
\\singlespacing
\\caption{{{caption}}}
\\resizebox{{\\columnwidth}}{{!}}{{%
{tabular_body}%
}}
\\end{{table}}
"""

    text = re.sub(
        r'\\begin\{table\}\[htbp\]\s*\\centering\s*\\caption\{([^}]+)\}\s*(\\begin\{tabular\}[\s\S]*?\\end\{tabular\})\s*\\end\{table\}',
        replace_si_table,
        text
    )

    # 4. Fix figures in Section S15
    def replace_si_fig(m):
        img_path = m.group(1).strip()
        caption = m.group(2).strip()
        return f"""\\begin{{figure}}[!htbp]
\\centering
\\includegraphics[width=0.68\\textwidth,height=0.36\\textheight,keepaspectratio]{{{img_path}}}
{{\\singlespacing
\\caption{{{caption}}}
}}
\\end{{figure}}
"""

    text = re.sub(
        r'\\begin\{figure\}\[htbp\]\s*\\centering\s*\\includegraphics\[[^\]]+\]\{([^}]+)\}\s*\\caption\{([^}]+)\}\s*\\end{{figure}}',
        replace_si_fig,
        text
    )

    # Add \clearpage every 2 figures in SI
    fig_parts = re.split(r'(\\end\{figure\}\n)', text)
    new_fig_parts = []
    fig_count = 0
    in_figs_sec = False
    for fp in fig_parts:
        if "Section S15: Supplementary Figures" in fp:
            in_figs_sec = True
        if "Section S16: Supplementary Tables" in fp:
            in_figs_sec = False
        if fp == "\\end{figure}\n":
            fig_count += 1
            if in_figs_sec and fig_count % 2 == 0:
                new_fig_parts.append(fp + "\\clearpage\n")
            else:
                new_fig_parts.append(fp)
        else:
            new_fig_parts.append(fp)
    text = "".join(new_fig_parts)

    with open(si_path, "w", encoding="utf-8") as f:
        f.write(text)
    print("Updated 04_ACS_ANM_Supporting_Information.tex layout successfully.")

if __name__ == "__main__":
    fix_main_manuscript()
    fix_si_manuscript()
