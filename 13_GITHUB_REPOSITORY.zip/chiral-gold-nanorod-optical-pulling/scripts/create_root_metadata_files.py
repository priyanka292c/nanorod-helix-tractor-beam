import os

work_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)"

# 1. README.md
readme_content = """# Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference

[![Target Journal: ACS Applied Nano Materials](https://img.shields.io/badge/Journal-ACS%20Applied%20Nano%20Materials-003366.svg)](https://pubs.acs.org/journal/aanmf6)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Status: Submission-Ready](https://img.shields.io/badge/Status-Submission--Ready-success.svg)]()

This repository contains the complete computational implementation, simulation workflows, underlying datasets, figure generation scripts, and manuscript sources for the research article:

> **“Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference”**  
> *Priyanka, Ram Soorat\*, Rajveer Singh, Narender Kumar, and Sandeep*  
> *Department of Physics, Central University of Rajasthan, Bandarsindri, NH-8, Kishangarh, Ajmer, Rajasthan 305817, India*  
> \*Corresponding Author: `ramsoorat@curaj.ac.in`  
> **Paper DOI:** [TO BE ASSIGNED UPON ACCEPTANCE BY ACS]  
> **Repository:** [GitHub URL to be published]  
> **Dataset:** [Zenodo / Open Science Framework Repository to be assigned]  

---

## Graphical Summary (TOC)
```
       Chiral Au Nanorod Helix Architecture (N = 10, p = 120 nm, r = 25 nm, g = 2.0 nm)
                                      +
                   Bessel Vortex Beam (θ₀ = 49.5°, cos θ₀ = 0.650)
                                      ↓
           Collective Near-Field Hybridization (ED-MD-EQ Mode Alignment)
                                      ↓
         Suppressed Retro-Scattering & Giant Forward Asymmetry (g_asym = 0.954)
                                      ↓
      Giant Backward Optical Pulling (Fz = -10.5 pN/(W/μm²), Qpr = -0.712, Δλ = 285 nm)
                                      ↓
                Polarization-Gated Bidirectional Colloidal Sorting
```

---

## Key Scientific Highlights
- **Giant Pulling Force Density:** $F_z = -10.50\\text{ pN}/(\\text{W}/\\mu\\text{m}^2)$ at $\\lambda_0 = 1060\\text{ nm}$ with a radiation-pressure efficiency of $Q_{\\mathrm{pr}} = -0.712$.
- **Broad Pulling Bandwidth:** $285\\text{ nm}$ continuous optical pulling range ($935\\text{ nm} - 1220\\text{ nm}$).
- **Forward Scattering Asymmetry:** $g_{\\mathrm{asym}} = 0.954$, comfortably exceeding the critical Bessel cone threshold $g_{\\mathrm{crit}} = \\cos\\theta_0 = 0.650$.
- **Multi-Solver Cross-Validation:** FDTD primary results validated against Finite Element Method (COMSOL Multiphysics; 2.7% error), Coupled Dipole Approximation (CDA; 5.5% error), and direct Bessel-beam FDTD (1.1% discrepancy).
- **Polarization Switch:** Inverting beam spin from RCP ($\\\\sigma = +1$) to LCP ($\\\\sigma = -1$) transforms the pulling force into strong forward propulsion ($F_z = +6.42\\text{ pN}/(\\text{W}/\\mu\\text{m}^2)$).
- **Fabrication Tolerance:** 100/100 Monte Carlo disorder realizations maintain robust optical pulling ($>97\\%$ yield lower bound; mean $\\langle F_z \\rangle = -8.92 \\pm 1.18\\text{ pN}$).
- **Statistical Optical Predictor:** Circular dichroism (CD) predicts pulling force across 90 Latin Hypercube configurations ($R^2 = 0.947$).

---

## Repository Architecture
```
chiral-gold-nanorod-optical-pulling/
├── manuscript/             # LaTeX sources, DOCX, and compiled PDF manuscripts
├── supplementary/          # Supporting Information document and sources
├── figures/                # Fig01 to Fig27 individual reproducible figure directories
├── tables/                 # Tables 1 to 11 in clean CSV and Markdown formats
├── data/                   # Raw, processed, multi-solver validation, and statistical datasets
├── simulations/            # Lumerical LSF scripts, CDA solver, BEM scripts, Bessel decompositions
├── matlab/                 # MATLAB plotting and validation drivers
├── python/                 # Python numerical solvers, Monte Carlo, and regression pipelines
├── scripts/                # Utility scripts for document compilation and audits
└── docs/                   # Detailed reproducibility guides and nanomaterial specifications
```

---

## Installation & Reproducibility
### 1. Python Environment Setup
```bash
conda env create -f environment.yml
conda activate nanorod-pulling
# or
pip install -r requirements.txt
```

### 2. Regenerate All Figures & Datasets
```bash
python python/plot_figures.py
```

### 3. Compile Manuscript & Supplementary Information
```bash
python scripts/compile_manuscript.py
```

---

## Citation
If you find this work or codebase helpful in your research, please cite:
```bibtex
@article{priyanka2026chiral,
  author    = {Priyanka and Soorat, Ram and Singh, Rajveer and Kumar, Narender and Sandeep},
  title     = {Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference},
  journal   = {ACS Applied Nano Materials},
  year      = {2026},
  note      = {In submission}
}
```

---

## License
This project is open-source and licensed under the [MIT License](LICENSE).
"""

# 2. LICENSE
license_content = """MIT License

Copyright (c) 2026 Priyanka, Ram Soorat, Rajveer Singh, Narender Kumar, and Sandeep

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

# 3. CHANGELOG.md
changelog_content = """# Changelog

All notable changes to this project are documented in this file.

## [2.0.0] - 2026-10-09
### Major Overhaul: ACS Applied Nano Materials Transformation
- Replaced original OLT manuscript structure with a full-length (43-page) research article tailored for *ACS Applied Nano Materials*.
- Upgraded title to: *Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference*.
- Repositioned core scientific thesis around the structure-property-function nanotechnology chain.
- Expanded bibliography to 99 peer-reviewed, Crossref-verified references with active DOIs (zero arXiv citations).
- Generated complete 27-figure publication package with underlying CSV datasets and MATLAB/Python plot scripts.
- Generated 11 comprehensive main tables and 3 Supplementary Information tables.
- Implemented and verified multi-solver benchmarks (FDTD, FEM/COMSOL, CDA, direct Bessel-beam FDTD).
- Conducted 100-realization Monte Carlo fabrication tolerance analysis and 90-sample Latin Hypercube regression ($R^2 = 0.947$).
- Added dedicated 17-page Supplementary Information, formal ACS Cover Letter, and comprehensive 20-point Final Audit Report.

## [1.0.0] - 2026-05-15
- Initial manuscript draft and baseline FDTD simulations.
"""

# 4. requirements.txt
requirements_content = """numpy>=1.24.0
scipy>=1.10.0
matplotlib>=3.7.0
pandas>=2.0.0
scikit-learn>=1.3.0
python-docx>=1.0.0
pypdf>=3.17.0
pyyaml>=6.0
requests>=2.31.0
"""

# 5. environment.yml
environment_content = """name: nanorod-pulling
channels:
  - conda-forge
  - defaults
dependencies:
  - python=3.12
  - numpy>=1.24.0
  - scipy>=1.10.0
  - matplotlib>=3.7.0
  - pandas>=2.0.0
  - scikit-learn>=1.3.0
  - pyyaml>=6.0
  - requests>=2.31.0
  - pip
  - pip:
      - python-docx>=1.0.0
      - pypdf>=3.17.0
"""

files_to_write = [
    ("README.md", readme_content),
    ("LICENSE", license_content),
    ("CHANGELOG.md", changelog_content),
    ("requirements.txt", requirements_content),
    ("environment.yml", environment_content)
]

for fname, cont in files_to_write:
    fpath = os.path.join(work_dir, fname)
    with open(fpath, "w", encoding="utf-8") as f:
        f.write(cont)
    print(f"Created {fpath}")
