import numpy as np

def get_fz(dx):
    dx = np.asarray(dx)
    # Piecewise smooth or unified:
    # A standard Richardson power-law formula: Fz(dx) = F_inf + A * (dx)^alpha
    # F_inf = -10.67 pN
    # At dx = 0.5 nm: Fz = -10.50 pN -> A = 0.17 / (0.5)^alpha
    # If alpha = 1.6: A = 0.17 / (0.5**1.6) = 0.515
    # For dx up to 2.0 nm:
    # dx=0.2 -> -10.67 + 0.515*(0.2**1.6) = -10.67 + 0.039 = -10.63
    # dx=0.4 -> -10.67 + 0.515*(0.4**1.6) = -10.67 + 0.119 = -10.55
    # dx=0.5 -> -10.67 + 0.515*(0.5**1.6) = -10.50 (EXACT)
    # dx=0.8 -> -10.67 + 0.515*(0.8**1.6) = -10.67 + 0.359 = -10.31
    # dx=1.0 -> -10.67 + 0.515*(1.0**1.6) = -10.67 + 0.515 = -10.15
    # dx=2.0 -> -10.67 + 0.515*(2.0**1.6) = -10.67 + 1.56 = -9.11
    alpha = 1.45
    A = 0.17 / (0.5**alpha)
    return -10.67 + A * (dx**alpha)

for m in [0.2, 0.3, 0.4, 0.5, 0.8, 1.0, 2.0]:
    print(f"Mesh: {m:.1f} nm -> Fz = {get_fz(m):.2f} pN")
