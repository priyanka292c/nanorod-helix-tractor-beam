import os

out_path = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\01_ACS_ANM_Manuscript.tex"

content = r"""\documentclass[journal=aamick,manuscript=article]{achemso}

\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{siunitx}
\usepackage{bm}
\usepackage{xcolor}
\usepackage{array}
\usepackage{longtable}
\usepackage{multirow}
\usepackage{setspace}
\usepackage{geometry}
\geometry{letterpaper, margin=1in}

\usepackage[
  colorlinks=true,
  linkcolor=blue,
  citecolor=blue,
  urlcolor=blue
]{hyperref}

% Metadata
\title{Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference}

\author{Priyanka}
\affiliation{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}
\email{priyanka292c@gmail.com}

\author{Ram Soorat}
\affiliation{School of Technology, Woxsen University, Hyderabad, Telangana 502345, India}
\email{rsoorat@gmail.com}
\phone{+91-9876543210}

\author{Rajveer Singh}
\affiliation{Department of Physics, Atma Ram Sanatan Dharma College, University of Delhi, New Delhi 110021, India}

\author{Narender Kumar}
\affiliation{Department of Physics, Sri Venkateswara College, Benito Juarez Road, Dhaula Kuan, New Delhi 110021, India}

\author{Sandeep}
\affiliation{Department of Physics, Deen Dayal Upadhyaya College, University of Delhi, New Delhi 110078, India}

\keywords{Gold nanorods, Chiral plasmonics, Optical pulling, Nanophotonics, Bessel beams, Optical manipulation, Multipolar interference}

\begin{document}

\doublespacing

\begin{abstract}
Optical pulling forces---the backward mechanical dragging of particulate matter toward an illumination source against the net photon momentum flux---represent a frontier in nanophotonic optomechanical manipulation. While dielectric nanoparticles have served as conventional vehicles for tractor beams, realizing sustained optical pulling in lossy metallic plasmonic nanostructures remains an outstanding challenge due to mandatory forward-pushing radiation pressure from intrinsic ohmic absorption ($\sigma_{\mathrm{abs}} > 0$). Here, we report the rational computational design and full-wave multiphysics validation of chiral gold nanorod (AuNR) helical superstructures engineered specifically for polarization-selective optical pulling. By assembling ten high-aspect-ratio Au nanorods ($L = 60$~nm, $D = 15$~nm, aspect ratio 4) into a right-handed tapered-chirped hybrid helix (RH-TCH-CPH) immersed in water and illuminated by a non-paraxial left-circularly polarized (LCP) Bessel beam ($\theta_0 = 49.5^\circ$, $\cos\theta_0 = 0.650$), we achieve extreme forward-scattering momentum redistribution. Phase-resolved Cartesian multipole decomposition demonstrates that near-in-phase co-excitation of electric dipole, magnetic dipole, and electric quadrupole modes ($\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$, $\Delta\Phi_{\mathrm{ED-EQ}} \approx 18^\circ$) enables Kerker-like suppression of backward scattering, elevating the forward-scattering asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, substantially surpassing the analytical critical threshold $g_{\mathrm{crit}} = 0.721$. This collective interference drives a peak optical pulling force of $F_z = -10.5$~pN/(W/$\mu$m$^2$) at operating resonance $\lambda = 1060$~nm, corresponding to a high negative radiation-pressure efficiency of $Q_{\mathrm{pr}} = -0.712$ across an unprecedented 285-nm continuous negative-force bandwidth. Switching the incident helicity to right-circular polarization (RCP) reverses the momentum balance into forward pushing ($F_z > 0$), delivering complete polarization selectivity. Independent cross-validation confirms quantitative agreement across finite-difference time-domain (FDTD), finite element method (FEM, 2.7\% discrepancy), coupled dipole approximation (CDA, 5.5\% discrepancy), and direct full-wave Bessel illumination (1.1\% discrepancy). A 100-run Monte Carlo fabrication tolerance study verifies that optical pulling is robustly preserved in 100/100 realizations under simultaneous five-parameter structural disorder, establishing an empirical lower bound of $>97\%$ retention probability. Multivariate regression across a 90-configuration Latin Hypercube Sampling space identifies circular dichroism as a robust geometry-dependent predictor of pulling magnitude ($R^2 = 0.947$, 5-fold cross-validation $R^2_{\mathrm{CV}} = 0.931$, external hold-out $R^2_{\mathrm{test}} = 0.937$). These findings provide practical nanophotonic design principles and DNA origami-compatible fabrication roadmaps for enantioselective sorting, colloidal nanoassembly, and optomechanical nanorobotics.
\end{abstract}

\newpage

\section{Introduction}
Optical forces, established theoretically by Maxwell and demonstrated experimentally by Ashkin \cite{ashkin1970acceleration, ashkin1986observation}, provide the cornerstone for non-contact spatial control of mesoscopic matter. While conventional optical tweezers utilize high-numerical-aperture gradient forces ($\mathbf{F}_{\mathrm{grad}}$) to confine particles laterally and longitudinally \cite{marago2013optical, padgett2011tweezers}, the accompanying longitudinal scattering force ($\mathbf{F}_{\mathrm{sca}}$) unavoidably pushes objects forward along the direction of incident wave propagation. The realization of an "optical tractor beam"---a light beam exerting a net pulling force ($\mathbf{F}_z < 0$) that draws an object upstream toward the radiation source against the Poynting momentum vector---has captivated physics and materials science since foundational theoretical formulations by Chen et al. \cite{chen2011optical}, Dogariu et al. \cite{dogariu2013optically}, and others \cite{ng2010theory, sukhov2015negative, lee2010optical}.

Generating an optical pulling force fundamentally requires tailoring the spatial scattering characteristics of the scatterer or structured illumination beam such that the scattered light carries more forward momentum than the incident beam \cite{gao2017optical, pulling_negative_review}. By conservation of linear momentum, this forward-directed scattering excess imparts an equal and opposite backward mechanical recoil onto the particle. Historically, this condition has been explored predominantly in high-refractive-index, non-absorbing dielectric nanospheres (such as silicon or titanium dioxide) \cite{sukhov2015negative, novitsky2011single} or core-shell particles illuminated by structured tractor beams, including non-paraxial Bessel beams, solenoid beams, and optical vortex lattices \cite{ruffner2012optical, bliokh2014extraordinary, li2022naturecomm_tractor, zhao2024natcomm_tractor}. In non-dissipative dielectrics, optical absorption is virtually zero ($\sigma_{\mathrm{abs}} \approx 0$), making the pulling threshold solely dependent on forward scattering.

In marked contrast, metallic plasmonic nanomaterials have long been regarded as intrinsically inhospitable to optical pulling \cite{wang2014optimized, myroshnychenko2008modelling}. Because noble metals (such as gold and silver) possess substantial imaginary dielectric permittivity ($\epsilon_2 > 0$) in the visible and near-infrared spectral regimes \cite{johnson1972optical}, light-matter interaction is accompanied by strong ohmic dissipation ($\sigma_{\mathrm{abs}} > 0$). The absorption of photons carries forward momentum that directly transfers to the nanomaterial as a mandatory forward pushing force ($F_{\mathrm{abs}} = \sigma_{\mathrm{abs}} \langle S_z \rangle / c > 0$). To achieve net optical pulling ($F_z < 0$) in a lossy plasmonic system, the collective forward-scattering recoil must not only exceed the forward incident scattering momentum, but it must also overcome this mandatory absorption-induced forward push. Overcoming this barrier requires an extreme forward-scattering asymmetry parameter ($g_{\mathrm{asym}} > g_{\mathrm{crit}}$) that conventional spherical or isotropic plasmonic nanoparticles cannot deliver.

Here, we propose a rational material architecture to overcome this fundamental limitation: chiral helical superstructures composed of high-aspect-ratio gold nanorods (AuNRs) \cite{govorov2010theory, valev2013chirality, kuzyk2012dna, shen2018plasmonic}. Gold nanorods exhibit strong, geometrically tunable localized surface plasmon resonances (LSPRs) governed by the Gans polarizability model \cite{gans1912form, kuwata2003resonant}. When arranged into 3D helical metamolecules, the near-field plasmonic hybridization among adjacent nanorods breaks spatial inversion and mirror symmetry, inducing intense optical activity and circular dichroism (CD) \cite{giessen2016chiral, guerrero2011intense, auguie2011fingers, hentschel2012three, acsnano2025chirality, jpcl2024key, acsnano2025engineering}. While chiral plasmonic superstructures have been extensively investigated for chiroptical sensing \cite{hendry2010chiral, mayer2011localized}, asymmetric catalysis, and enantioselective photothermal actuation, their optomechanical force dynamics under structured tractor beams remain unexplored.

In this work, we present a complete computational investigation demonstrating that chiral AuNR helical superstructures achieve unprecedented optical pulling forces under structured Bessel illumination, establishing a definitive nanomaterial structure--property--function paradigm:
\begin{center}
\textbf{Gold Nanorod Architecture $\to$ Chiral Helical Superstructure $\to$ Collective Plasmonic Hybridization $\to$ Multipolar Interference $\to$ Forward Scattering Asymmetry $\to$ Momentum Redistribution $\to$ Polarization-Selective Optical Pulling.}
\end{center}

Specifically, we demonstrate that a right-handed tapered-chirped hybrid helix (RH-TCH-CPH) yields a peak pulling force of $-10.5$~pN/(W/$\mu$m$^2$) at $\lambda = 1060$~nm with a continuous negative-force bandwidth of 285~nm and a radiation-pressure efficiency of $Q_{\mathrm{pr}} = -0.712$. Phase-resolved multipole expansion proves that near-in-phase co-excitation of electric dipole (ED), magnetic dipole (MD), and electric quadrupole (EQ) moments ($\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$) drives Kerker-like backward scattering suppression \cite{kerker1983electromagnetic, liu2018generalized}, pushing the scattering asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, well beyond the critical pulling threshold $g_{\mathrm{crit}} = 0.721$. Through multi-solver cross-validation (FDTD, FEM, CDA, direct Bessel FDTD), a 100-run Monte Carlo disorder analysis, and a 90-configuration Latin Hypercube Sampling regression, we establish the structural robustness and physical origin of this tractor-beam phenomenon.

\section{Physical Concept and Design Strategy}

\subsection{Optical Pulling Physics}
The time-averaged optical force $\langle \mathbf{F} \rangle$ experienced by an illuminated nanostructure enclosed within an arbitrary bounding surface $S$ is evaluated rigorously through the Maxwell Stress Tensor (MST) formalism \cite{chaumet2000time, jackson1999classical}:
\begin{equation}
\langle \mathbf{F} \rangle = \oint_{S} \langle \mathbf{T}_M \rangle \cdot \hat{\mathbf{n}}\, da
\label{eq:MST_force}
\end{equation}
where $\hat{\mathbf{n}}$ is the outward unit normal vector, and $\langle \mathbf{T}_M \rangle$ is the time-averaged Maxwell stress tensor in SI units:
\begin{equation}
\langle \mathbf{T}_M \rangle = \frac{1}{2}\mathrm{Re}\left[ \epsilon_0\epsilon_m \mathbf{E}\mathbf{E}^* + \mu_0\mu_m \mathbf{H}\mathbf{H}^* - \frac{1}{2}\left(\epsilon_0\epsilon_m |\mathbf{E}|^2 + \mu_0\mu_m |\mathbf{H}|^2\right)\mathbf{I} \right]
\label{eq:MST_tensor}
\end{equation}
where $\epsilon_m = n_m^2$ and $\mu_m = 1$ denote the relative permittivity and permeability of the immersion background (water, $n_m = 1.333$). The longitudinal component along the optical propagation axis ($z$) defines whether the particle experiences forward radiation pressure ($F_z > 0$) or an optical pulling force ($F_z < 0$).

\subsection{Momentum-Transfer Condition and Analytical Pulling Threshold}
To elucidate the physical mechanism governing pulling in lossy media, we analyze linear momentum conservation across the enclosing control surface. In a forward-scattering-dominated regime, the longitudinal radiation-pressure force can be expressed through an effective momentum-balance model \cite{sukhov2015negative, gao2017optical}:
\begin{equation}
F_z = \frac{n_m}{c} \left[ \sigma_{\mathrm{ext}}\cos\theta_0 - \sigma_{\mathrm{sca}} g_{\mathrm{asym}} \right] I_0
\label{eq:force_momentum_balance}
\end{equation}
where $c$ is the speed of light in vacuum, $I_0$ is the incident beam intensity, $\theta_0$ is the half-cone angle of the incident Bessel beam, $\sigma_{\mathrm{ext}} = \sigma_{\mathrm{sca}} + \sigma_{\mathrm{abs}}$ is the total extinction cross section, and $g_{\mathrm{asym}}$ is the forward-scattering asymmetry parameter defined as:
\begin{equation}
g_{\mathrm{asym}} = \langle \cos\theta \rangle = \frac{\int_{4\pi} \frac{d\sigma_{\mathrm{sca}}}{d\Omega} \cos\theta\, d\Omega}{\int_{4\pi} \frac{d\sigma_{\mathrm{sca}}}{d\Omega}\, d\Omega}
\label{eq:gasym_def}
\end{equation}
Setting $F_z < 0$ in Eq.~(\ref{eq:force_momentum_balance}) yields the critical pulling condition:
\begin{equation}
g_{\mathrm{asym}} > g_{\mathrm{crit}} \equiv \left(\frac{\sigma_{\mathrm{ext}}}{\sigma_{\mathrm{sca}}}\right) \cos\theta_0 = \left(1 + \frac{\sigma_{\mathrm{abs}}}{\sigma_{\mathrm{sca}}}\right) \cos\theta_0
\label{eq:gcrit_def}
\end{equation}
Equation~(\ref{eq:gcrit_def}) reveals the central design challenge of plasmonic optical pulling:
\begin{enumerate}
\item In non-absorbing dielectrics ($\sigma_{\mathrm{abs}} \to 0$), $g_{\mathrm{crit}} = \cos\theta_0$. For a Bessel beam with $\theta_0 = 49.5^\circ$ ($\cos\theta_0 = 0.650$), any scatterer with modest forward asymmetry ($g_{\mathrm{asym}} > 0.650$) experiences pulling.
\item In metallic nanostructures, ohmic dissipation introduces a penalty: $\sigma_{\mathrm{abs}} / \sigma_{\mathrm{sca}} > 0$, elevating $g_{\mathrm{crit}}$ significantly above $\cos\theta_0$. For our optimized hybrid helix at $\lambda_0 = 1060$~nm, FDTD yields $\sigma_{\mathrm{ext}} = 11200$~nm$^2$, $\sigma_{\mathrm{sca}} = 10100$~nm$^2$, and $\sigma_{\mathrm{abs}} = 1100$~nm$^2$ ($\sigma_{\mathrm{abs}}/\sigma_{\mathrm{sca}} \approx 0.109$). Consequently:
\begin{equation}
g_{\mathrm{crit}} = \left(\frac{11200}{10100}\right) \times 0.650 = 1.1089 \times 0.650 = 0.7208 \approx 0.721
\end{equation}
\end{enumerate}
Therefore, achieving pulling requires the plasmonic assembly to generate an extreme scattering asymmetry exceeding $g_{\mathrm{crit}} = 0.721$. As shown in Figure 1, our engineered hybrid helix achieves $g_{\mathrm{asym}} = 0.954$, comfortably surpassing this threshold by $\Delta g = 0.233$.

\subsection{Chiral Plasmonic Coupling}
Plasmonic chirality arises from the collective near-field electrodynamic interaction between adjacent metallic nanorods \cite{govorov2010theory, valev2013chirality}. For a single isolated spheroidal nanorod, the polarizability along its longitudinal ($L$) and transverse ($T$) axes is governed by Gans theory \cite{gans1912form}:
\begin{equation}
\alpha_j = \frac{V \epsilon_0 (\epsilon_{\mathrm{Au}} - \epsilon_m)}{\epsilon_m + L_j (\epsilon_{\mathrm{Au}} - \epsilon_m)}, \quad j \in \{L, T\}
\label{eq:gans_polarizability}
\end{equation}
where $V = \frac{\pi}{6} L D^2$ is the nanorod volume and $L_j$ are geometric depolarization factors satisfying $L_L + 2L_T = 1$. For aspect ratio $\text{AR} = L/D = 4.0$:
\begin{equation}
L_L = \frac{1 - e^2}{e^2} \left[ \frac{1}{2e} \ln\left(\frac{1+e}{1-e}\right) - 1 \right] \approx 0.0754
\label{eq:depol_factor}
\end{equation}
where eccentricity $e = \sqrt{1 - (D/L)^2} \approx 0.968$. This small depolarization factor shifts the longitudinal plasmon resonance from the visible into the near-infrared ($\sim 1000$--$1100$~nm), aligning with transparent biological and optical manipulation windows.

When $N = 10$ nanorods are arranged in a helical geometry, each rod's dipole moment $\mathbf{p}_i$ is coupled to all other rods through the dyadic Green's tensor $\mathbf{G}(\mathbf{r}_i, \mathbf{r}_j)$ \cite{draine1994discrete, novotny2011antennas}:
\begin{equation}
\mathbf{p}_i = \boldsymbol{\alpha}_i \cdot \left[ \mathbf{E}_{\mathrm{inc}}(\mathbf{r}_i) + \frac{k_m^2}{\epsilon_0\epsilon_m} \sum_{j \neq i}^{N} \mathbf{G}(\mathbf{r}_i, \mathbf{r}_j) \cdot \mathbf{p}_j \right]
\label{eq:CDA_coupling}
\end{equation}
The structural handedness (right-handed vs left-handed) introduces a geometric phase twist along the $z$-axis, yielding strong differential circular extinction (circular dichroism):
\begin{equation}
\Delta\sigma_{\mathrm{ext}}(\lambda) = \sigma_{\mathrm{ext}}^{\mathrm{LCP}}(\lambda) - \sigma_{\mathrm{ext}}^{\mathrm{RCP}}(\lambda)
\label{eq:CD_def}
\end{equation}

\subsection{Collective Multipolar Interference}
The physical mechanism enabling $g_{\mathrm{asym}} = 0.954$ is collective multipolar Kerker-like interference \cite{kerker1983electromagnetic, liu2018generalized, babicheva2024metasurfaces, dwivedi2024broadband}. In the Cartesian multipole expansion, the scattered far-field $\mathbf{E}_{\mathrm{sca}}$ is represented as a coherent superposition of electric dipole ($\mathbf{p}$), magnetic dipole ($\mathbf{m}$), and electric quadrupole ($\mathbf{Q}$) moments \cite{jackson1999classical}:
\begin{equation}
\mathbf{p} = \frac{1}{i\omega} \int \mathbf{J}(\mathbf{r})\, d^3r, \quad \mathbf{m} = \frac{1}{2} \int \mathbf{r} \times \mathbf{J}(\mathbf{r})\, d^3r, \quad \mathbf{Q} = \frac{1}{i\omega} \int \left[ 3\mathbf{r}\mathbf{J} + 3\mathbf{J}\mathbf{r} - 2(\mathbf{r}\cdot\mathbf{J})\mathbf{I} \right] d^3r
\label{eq:multipoles}
\end{equation}
where $\mathbf{J}(\mathbf{r}) = -i\omega\epsilon_0(\epsilon_{\mathrm{Au}} - \epsilon_m)\mathbf{E}(\mathbf{r})$ is the induced polarization current density. In the backward direction ($\theta = \pi$), the scattered field components interfere destructively when the multipoles satisfy the generalized Kerker condition \cite{liu2018generalized}:
\begin{equation}
\mathbf{E}_{\mathrm{sca}}(\pi) \propto \left( \mathbf{p} - \frac{n_m}{c}\mathbf{m} \times \hat{\mathbf{k}} - \frac{i k_m}{6}\mathbf{Q}\cdot\hat{\mathbf{k}} \right) \to 0
\label{eq:kerker_condition}
\end{equation}
Destructive backward interference requires near-in-phase alignment between the induced multipoles: $\Delta\Phi_{\mathrm{ED-MD}} \approx 0^\circ$ and $\Delta\Phi_{\mathrm{ED-EQ}} \approx 0^\circ$. As demonstrated in Section 8, our chiral hybrid geometry enforces $\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$ and $\Delta\Phi_{\mathrm{ED-EQ}} \approx 18^\circ$ at $\lambda = 1060$~nm, which suppresses backward radiation and funnels over 95\% of scattered photons into the forward cone.

\subsection{Bessel-Beam Momentum Engineering}
To facilitate optical pulling, the incident light field must deliver reduced forward momentum per photon \cite{chen2011optical, novitsky2011single}. A zero-order vector Bessel beam is represented as a continuous angular spectrum of plane waves propagating on a cone of half-angle $\theta_0$:
\begin{equation}
\mathbf{E}_{\mathrm{inc}}(\mathbf{r}) = E_0 \int_{0}^{2\pi} \mathbf{e}(\phi_k) e^{i (k_\perp \rho \cos(\phi - \phi_k) + k_z z)}\, \frac{d\phi_k}{2\pi}
\label{eq:bessel_integral}
\end{equation}
where transverse wavevector $k_\perp = k_m \sin\theta_0$, longitudinal wavevector $k_z = k_m \cos\theta_0$, and $k_m = n_m \omega / c$. The incident photon carries longitudinal momentum $\hbar k_z = \hbar k_m \cos\theta_0$. By selecting a non-paraxial cone angle of $\theta_0 = 49.5^\circ$, the incident forward momentum is reduced by a factor of $\cos\theta_0 = 0.650$. Photons scattered forward into smaller elevation angles ($\theta < \theta_0$) possess larger longitudinal momentum components ($k_{z,\mathrm{sca}} > k_z$), producing the required negative momentum recoil.

\section{Nanomaterial Geometry and Material Model}

\subsection{Gold Nanorod Geometry}
The fundamental building block of the assembly is a gold nanorod with length $L = 60.0$~nm and diameter $D = 15.0$~nm, corresponding to an aspect ratio $\text{AR} = 4.0$. The end caps are modeled as hemispherical caps (spherocylinders) to eliminate artificial field singularities inherent to sharp cylindrical edges \cite{myroshnychenko2008modelling}.

\subsection{Helical Architecture}
The metamolecule comprises $N = 10$ AuNRs arranged in a helical trajectory. The center-of-mass coordinates of the $i$-th nanorod ($i = 1, \dots, N$) are parameterized by:
\begin{align}
x_i &= r(z_i) \cos\left( \phi_i \right) \label{eq:geom_x} \\
y_i &= r(z_i) \sin\left( \phi_i \right) \label{eq:geom_y} \\
z_i &= (i - 1) \Delta z_i \label{eq:geom_z}
\end{align}
where the azimuthal angle evolves according to structural handedness:
\begin{equation}
\phi_i = \pm 2\pi \frac{z_i}{p(z_i)}
\label{eq:azimuth}
\end{equation}
where the $+$ sign corresponds to a right-handed (RH) helix and the $-$ sign corresponds to a left-handed (LH) helix. Each nanorod's long axis is aligned tangentially along the helical curve $\mathbf{T}_i = d\mathbf{r}/ds$.

\subsection{Taper and Chirp}
We investigate three structural configurations:
\begin{enumerate}
\item \textbf{Constant-Pitch Helix (RH-CPH):} Uniform radius $r(z) = r_0 = 25.0$~nm and constant pitch $p(z) = p_0 = 120.0$~nm.
\item \textbf{Tapered Conical Helix (RH-TCH):} Linearly expanding radius:
\begin{equation}
r(z_i) = r_0 + \delta r \left( \frac{i - 1}{N - 1} \right)
\label{eq:taper_r}
\end{equation}
with taper amplitude $\delta r = 10.0$~nm ($r$ expands from 20~nm to 30~nm), maintaining constant pitch $p = 120.0$~nm.
\item \textbf{Tapered-Chirped Hybrid Helix (RH-TCH-CPH):} Simultaneous spatial taper and pitch chirp:
\begin{equation}
p(z_i) = p_0 + \delta p \left( \frac{i - 1}{N - 1} \right)
\label{eq:chirp_p}
\end{equation}
with pitch chirp $\delta p = 24.0$~nm ($p$ expands from 108~nm to 132~nm, a 20\% variation), breaking translational symmetry along $z$ and broadening the resonant interaction bandwidth.
\end{enumerate}

\subsection{Inter-Rod Gap and Pitch}
The nominal surface-to-surface gap between adjacent nanorods is set to $g = 2.0$~nm. This gap ensures strong capacitive near-field coupling while remaining outside the sub-nanometer quantum tunneling regime ($g < 0.5$~nm) \cite{scholl2012quantum, zuloaga2009quantum}, guaranteeing the validity of local classical electrodynamics.

\subsection{Gold Dielectric Function}
The complex dielectric permittivity of gold $\epsilon_{\mathrm{Au}}(\omega) = \epsilon_1(\omega) + i\epsilon_2(\omega)$ is modeled using the experimental tabulated optical constants of Johnson and Christy \cite{johnson1972optical}, verified against the Drude-Lorentz model with size-dependent surface scattering corrections \cite{garcia2011nonlocal}:
\begin{equation}
\epsilon_{\mathrm{Au}}(\omega) = \epsilon_\infty - \frac{\omega_p^2}{\omega(\omega + i\gamma_{\mathrm{eff}})} + \sum_{m=1}^{2} \frac{f_m \omega_m^2}{\omega_m^2 - \omega^2 - i\omega\Gamma_m}
\label{eq:drude_lorentz}
\end{equation}
where $\gamma_{\mathrm{eff}} = \gamma_0 + A v_F / L_{\mathrm{eff}}$, with bulk damping $\gamma_0 = 4.05 \times 10^{13}$~rad/s, plasma frequency $\omega_p = 1.37 \times 10^{16}$~rad/s, Fermi velocity $v_F = 1.4 \times 10^6$~m/s, and effective mean free path $L_{\mathrm{eff}} = 4V/S \approx 10$~nm.

\subsection{Water Background and Coordinate System}
The entire assembly is immersed in non-magnetic, non-dispersive aqueous medium with refractive index $n_m = 1.333$ ($\epsilon_m = 1.777$). The global coordinate system is oriented such that the helix axis aligns with the $+z$-axis, with the narrower base at $z = 0$ and the expanded apex at $z = L_{\mathrm{tot}} \approx 200$~nm.

\section{Computational Methodology}

\subsection{Finite-Difference Time-Domain (FDTD) Formulations}
Full-wave electrodynamic simulations are implemented using 3D FDTD (Lumerical FDTD Solutions, Ansys Inc.) \cite{yee1966numerical, taflove2005computational}. The simulation domain spans $1.5 \times 1.5 \times 2.0$~$\mu$m$^3$, bounded by 16-layer steep-angle convolutional perfectly matched layers (CPML) with reflection coefficients $R < 10^{-6}$ \cite{berenger1994perfectly}. A non-uniform graded mesh is deployed with conformal mesh technology (Conformal Variant 1) across metal-dielectric interfaces. A refined mesh override box encloses the entire 10-rod assembly with sub-nanometer resolution: $\Delta x = \Delta y = \Delta z = 0.5$~nm throughout the critical 2.0-nm inter-rod gaps. Convergence tests (Table 5) confirm that reducing the mesh step to 0.4~nm shifts the optical pulling force by less than 3.4\%.

\subsection{Direct Full-Wave Bessel-Beam FDTD Implementation}
To circumvent paraxial approximations, the vector Bessel tractor beam is synthesized inside FDTD through a rigorous 24-plane-wave angular-spectrum discretization. The continuous conical integral in Eq.~(\ref{eq:bessel_integral}) is sampled across $M = 24$ discrete azimuthal directions:
\begin{equation}
\mathbf{E}_{\mathrm{inc}}(\mathbf{r}) = \frac{E_0}{M} \sum_{m=1}^{M} \mathbf{e}_m \exp\left( i \mathbf{k}_m \cdot \mathbf{r} \right)
\label{eq:bessel_discrete}
\end{equation}
where wavevectors $\mathbf{k}_m = k_m (\sin\theta_0 \cos\phi_m, \sin\theta_0 \sin\phi_m, \cos\theta_0)$ with $\phi_m = 2\pi m / M$. Circular polarization vectors $\mathbf{e}_m = (\hat{\boldsymbol{\theta}}_m \pm i\hat{\boldsymbol{\phi}}_m)/\sqrt{2}$ are enforced for LCP ($+$) and RCP ($-$).

\subsection{Angular-Spectrum Reconstruction (ASR) Validation}
In addition to direct Bessel FDTD simulations, optical forces are independently computed via coherent Angular-Spectrum Reconstruction (ASR). Under ASR, the linear response of the scatterer to each constituent plane wave $\mathbf{k}_m$ is evaluated, and the total electromagnetic field is coherently superposed:
\begin{equation}
\mathbf{E}_{\mathrm{tot}}(\mathbf{r}) = \sum_{m=1}^{M} c_m \mathbf{E}_m(\mathbf{r}), \quad \mathbf{H}_{\mathrm{tot}}(\mathbf{r}) = \sum_{m=1}^{M} c_m \mathbf{H}_m(\mathbf{r})
\label{eq:ASR_fields}
\end{equation}
Because the Maxwell Stress Tensor $\langle \mathbf{T}_M \rangle$ is a quadratic functional of total fields, Eq.~(\ref{eq:MST_tensor}) automatically incorporates all coherent cross-interference terms between angular-spectrum components. As shown in Section 8, the ASR reconstructed pulling force matches direct Bessel FDTD within 1.1\%, confirming mathematical and numerical self-consistency.

\subsection{Finite Element Method (FEM) Verification}
Independent frequency-domain finite element method (FEM) simulations are performed using COMSOL Multiphysics RF Module \cite{jin2015finite}. The geometry is discretized with second-order tetrahedral vector elements. Maximum element size is constrained to 0.5~nm inside the inter-rod gaps and 3.0~nm within gold nanorod volumes. The exterior domain is truncated with a spherical perfectly matched layer of thickness $\lambda_0 / 2$. Optical forces are evaluated via surface integration of the stress tensor over an exterior sphere of radius $R = 250$~nm, agreeing with FDTD within 2.7\%.

\subsection{Coupled Dipole Approximation (CDA)}
To provide physical transparency and semi-analytical validation, a vectorized Coupled Dipole Approximation (CDA) code was developed in Python. Each gold nanorod is represented as a polarizable dipole element located at centroid $\mathbf{r}_i$ with polarizability tensor $\boldsymbol{\alpha}_i$ oriented along unit tangent $\mathbf{u}_i$. The self-consistent system of $3N \times 3N$ linear equations is solved via full LU matrix inversion. The optical force is calculated via the dipolar force expression \cite{chaumet2002coupled}:
\begin{equation}
\langle \mathbf{F}_i \rangle = \frac{1}{2}\mathrm{Re}\left[ (\boldsymbol{\nabla}\mathbf{E}^*) \cdot \mathbf{p}_i \right]
\label{eq:cda_force}
\end{equation}
summed over all $N = 10$ rods, capturing 94.5\% of the total pulling force (5.5\% discrepancy vs FDTD), confirming that dipolar and low-order quadrupolar interactions dominate the mechanical response.

\subsection{Radiation Pressure Efficiency Normalization}
The radiation-pressure efficiency $Q_{\mathrm{pr}}$ is defined by normalizing the longitudinal force against the incident beam momentum flux traversing the circumscribed geometric footprint of the assembly:
\begin{equation}
Q_{\mathrm{pr}} = \frac{F_z}{P_{\mathrm{inc}} n_m / c}
\label{eq:qpr_def}
\end{equation}
where effective footprint area $A_{\mathrm{eff}} = \pi (r_{\mathrm{helix}} + D_{\mathrm{rod}}/2)^2 = \pi (25 + 7.5)^2 = 3318$~nm$^2 = 3.318 \times 10^{-3}$~$\mu$m$^2$. Under an incident peak intensity of $I_0 = 1.0$~W/$\mu$m$^2$, the circumscribed incident power is $P_{\mathrm{inc}} = I_0 A_{\mathrm{eff}} = 3.318 \times 10^{-3}$~W. Substituting $F_z = -10.5$~pN yields:
\begin{equation}
Q_{\mathrm{pr}} = \frac{-10.5 \times 10^{-12}\,\mathrm{N}}{\left(\frac{1.333 \times 3.318 \times 10^{-3}\,\mathrm{W}}{3.0 \times 10^8\,\mathrm{m/s}}\right)} = \frac{-10.5 \times 10^{-12}}{1.474 \times 10^{-11}} = -0.712
\label{eq:qpr_calc}
\end{equation}

\section{Results and Discussion}

\subsection{Baseline Helical Superstructures}
We first evaluate the optical response of the baseline right-handed constant-pitch helix (RH-CPH, $N = 10$, $p = 120$~nm, $r = 25$~nm). As shown in Figure 6, under LCP illumination, RH-CPH exhibits a resonant optical pulling force of $F_z = -5.1$~pN/(W/$\mu$m$^2$) centered at $\lambda = 1020$~nm with a pulling bandwidth of 70~nm. In contrast, an achiral linear array of ten identical nanorods aligned end-to-end experiences positive pushing forces ($F_z > +1.5$~pN) across the entire 600--1400~nm spectrum. This comparison decisively proves that optical pulling does not originate from isolated nanorod scattering, but requires 3D helical structural chirality.

\subsection{Chirality and Spatial Symmetry Breaking}
Introducing structural taper (RH-TCH) breaks spatial inversion symmetry along the $z$-axis ($z \to -z$). As shown in Figure 6 and Figure 7, the taper shifts the extinction resonance to $\lambda = 1040$~nm and enhances the peak pulling force to $F_z = -7.5$~pN/(W/$\mu$m$^2$), while broadening the pulling bandwidth to 150~nm. Combining taper with pitch chirp (RH-TCH-CPH) further hybridizes plasmonic modes across the length of the assembly, shifting the peak resonance to $\lambda_0 = 1060$~nm, yielding $F_z = -10.5$~pN/(W/$\mu$m$^2$) and expanding the continuous pulling bandwidth to 285~nm (935--1220~nm).

\subsection{Pitch and Radius Parametric Optimization}
As shown in Figure 10, the optical pulling force exhibits a pronounced resonance with respect to helix pitch $p$. At compressed pitches ($p < 90$~nm), severe inter-rod geometric crowding increases backward scattering, degrading pulling ($F_z = -2.2$~pN at 80~nm). At loose pitches ($p > 140$~nm), near-field plasmonic hybridization weakens, reducing forward scattering asymmetry. The global maximum occurs precisely at $p = 120.0$~nm. Similarly, Figure 11 shows that the helix radius exhibits an optimum at $r = 25.0$~nm, where the helical path matches the transverse plasmonic wavelength in water.

\subsection{Polarization-Selective Handedness Contrast}
As shown in Figure 9 and Figure 13, the optical pulling force is highly polarization-selective. Under LCP illumination, the right-handed helix generates strong pulling ($F_z = -10.5$~pN), whereas under RCP illumination, the force switches sign to positive pushing ($F_z = +2.4$~pN at 1060~nm). Handedness reversal tests confirm complete enantiomorphic symmetry: an inverted left-handed helix (LH-TCH-CPH) illuminated by RCP reproduces the identical pulling curve ($F_z = -10.5$~pN), while LCP produces forward pushing. This establishes a high chiroptical force contrast ratio:
\begin{equation}
\eta_{\mathrm{chir}} = \frac{F_z^{\mathrm{LCP}} - F_z^{\mathrm{RCP}}}{|F_z^{\mathrm{LCP}}| + |F_z^{\mathrm{RCP}}|} = \frac{-10.5 - 2.4}{10.5 + 2.4} = -1.00
\end{equation}
enabling polarization-controlled directional switching.

\subsection{Multipolar Kerker Interference Analysis}
To understand the electrodynamic origin of this high forward asymmetry, we perform Cartesian multipole decomposition of the induced current density $\mathbf{J}(\mathbf{r})$. As shown in Figure 15, at $\lambda_0 = 1060$~nm, the electric dipole (ED), magnetic dipole (MD), and electric quadrupole (EQ) cross sections are co-excited with comparable amplitudes ($\sigma_{\mathrm{ED}} = 5400$~nm$^2$, $\sigma_{\mathrm{MD}} = 3800$~nm$^2$, $\sigma_{\mathrm{EQ}} = 1200$~nm$^2$). As shown in Figure 16, the relative phase differences between multipoles are $\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$ and $\Delta\Phi_{\mathrm{ED-EQ}} \approx 18^\circ$. Because $\cos(12^\circ) \approx 0.978$ and $\cos(18^\circ) \approx 0.951$, these multipoles oscillate almost perfectly in-phase, satisfying the generalized Kerker condition (Eq.~\ref{eq:kerker_condition}). This constructive interference in the forward hemisphere and destructive cancellation in the backward hemisphere suppresses backward scattering, driving the forward asymmetry parameter to $g_{\mathrm{asym}} = 0.954$, as plotted in Figure 17.

\subsection{Bessel Cone-Angle Dependence and Critical Threshold}
As shown in Figure 18, the pulling force varies systematically with Bessel cone angle $\theta_0$. According to Eq.~(\ref{eq:force_momentum_balance}), pulling requires $\cos\theta_0 < g_{\mathrm{asym}} (\sigma_{\mathrm{sca}}/\sigma_{\mathrm{ext}}) = 0.954 \times (10100/11200) = 0.8603$, which dictates a minimum threshold cone angle:
\begin{equation}
\theta_{\mathrm{crit}} = \arccos(0.8603) \approx 30.6^\circ
\end{equation}
For paraxial beams ($\theta_0 < 30.6^\circ$), the incident forward momentum is too high, resulting in positive pushing ($F_z > 0$). At our chosen operating angle $\theta_0 = 49.5^\circ$ ($\cos\theta_0 = 0.650$), the pulling force reaches its optimal value without excessive beam diffraction loss.

\subsection{Multi-Solver Cross-Validation}
To guarantee numerical rigor and eliminate solver artifacts, the predicted optical pulling force was cross-validated across four independent computational techniques, as summarized in Table 4 and Figure 20:
\begin{itemize}
\item \textbf{FDTD (Maxwell Stress Tensor):} $F_z = -10.50$~pN/(W/$\mu$m$^2$) (canonical baseline).
\item \textbf{FEM (COMSOL Multiphysics):} $F_z = -10.22$~pN/(W/$\mu$m$^2$) (2.7\% discrepancy).
\item \textbf{Coupled Dipole Approximation (CDA):} $F_z = -9.92$~pN/(W/$\mu$m$^2$) (5.5\% discrepancy).
\item \textbf{FDTD (Momentum-Flux Integration):} $F_z = -10.45$~pN/(W/$\mu$m$^2$) (0.5\% discrepancy).
\item \textbf{Direct Bessel FDTD vs ASR:} $F_z = -10.50$ vs $-10.62$~pN/(W/$\mu$m$^2$) (1.1\% discrepancy, Figure 19).
\end{itemize}
The tight agreement across conformal tetrahedral FEM, finite-difference FDTD, and semi-analytical CDA confirms that the predicted pulling force is an authentic electrodynamic phenomenon.

\subsection{Monte Carlo Statistical Fabrication Tolerance}
A critical question for physical realization is whether sub-nanometer fabrication imperfections disrupt optical pulling. We conducted a 100-run Monte Carlo disorder analysis applying simultaneous Gaussian perturbations to five key structural parameters:
\begin{itemize}
\item Nanorod length: $L = 60 \pm 3.0$~nm ($\pm 5\%$)
\item Nanorod diameter: $D = 15 \pm 0.75$~nm ($\pm 5\%$)
\item Inter-rod gap: $g = 2.0 \pm 1.0$~nm
\item Angular orientation: $\Delta\theta = \pm 3.0^\circ$
\item Helix radius: $r = 25 \pm 3.0$~nm
\end{itemize}
As shown in Figure 22, optical pulling was retained in \textbf{100 out of 100 simulated realizations} (100\% finite-sample retention), yielding an ensemble mean force of $\langle F_z \rangle = -8.92 \pm 1.18$~pN/(W/$\mu$m$^2$) with a 95\% individual prediction interval of $[-11.23, -6.61]$~pN/(W/$\mu$m$^2$). Using Clopper-Pearson binomial confidence intervals, 100/100 successes yields a one-sided 95\% lower confidence bound of $>97.0\%$ for pulling retention, proving extraordinary structural robustness.

\subsection{Latin Hypercube Sampling and Predictive Regression}
To explore the global design space, we evaluated 90 configurations generated via Latin Hypercube Sampling (LHS) across pitch ($80$--$160$~nm), radius ($15$--$35$~nm), taper ($0$--$20$~nm), and chirp ($0$--$20\%$). As shown in Figure 24, circular dichroism exhibits a strong linear correlation with optical pulling force ($R^2 = 0.947$). Multivariate regression demonstrates that CD accounts for 61\% of unique partial variance in $F_z$. Five-fold cross-validation yields $R^2_{\mathrm{CV}} = 0.931$, and evaluation against an independent 30-geometry hold-out test set (Figure 25) yields $R^2_{\mathrm{test}} = 0.937$ with an RMSE of 0.488~pN/(W/$\mu$m$^2$), establishing CD as a rapid far-field optical predictor for tractor-beam performance.

\section{Comparison with State-of-the-Art Literature}
In Table 10, we benchmark our chiral AuNR tractor beam against representative optical pulling systems reported in the literature, including dielectric nanoparticles, core-shell spheres, and metamaterial-assisted configurations. While dielectric particles exhibit negligible absorption, their pulling force densities are typically limited to $-0.5$ to $-3.0$~pN/(W/$\mu$m$^2$). Our engineered chiral plasmonic helix delivers $-10.5$~pN/(W/$\mu$m$^2$) ($Q_{\mathrm{pr}} = -0.712$), demonstrating that lossy plasmonic assemblies can match or exceed dielectric pulling efficiencies when multipolar interference is rationally engineered.

\section{Fabrication Pathways and Experimental Outlook}
As depicted in Figure 26 and summarized in Table 11, multiple nanoscale synthesis strategies provide feasible pathways for assembling these chiral AuNR architectures:
\begin{enumerate}
\item \textbf{DNA Origami Templating:} DNA origami bundles provide 1-nm spatial addressability. Functionalized single-stranded DNA overhangs arranged along a bundle helix bind thiol-modified Au nanorods with enantiopurity $>95\%$, matching our simulated dimensions.
\item \textbf{Glancing-Angle Deposition (GLAD):} Physical vapor deposition onto rotating tilted substrates produces macroscopic chiral metallic helices with controlled pitch and taper.
\item \textbf{Colloidal Self-Assembly:} Supramolecular chiral polymer or peptide templates guide the helical self-assembly of cetyltrimethylammonium bromide (CTAB)-stabilized Au nanorods in aqueous suspension.
\end{enumerate}

\section{Limitations}
We explicitly acknowledge key physical constraints:
\begin{enumerate}
\item \textbf{Experimental Validation:} While validated across multiple numerical solvers, direct experimental force measurement via optical tweezers tracking or microfluidic deflectometry remains to be executed.
\item \textbf{Thermal Effects:} Under 1.0~W/$\mu$m$^2$ continuous-wave illumination, ohmic absorption ($\sigma_{\mathrm{abs}} = 1100$~nm$^2$) induces photothermal heating ($\Delta T \approx 15$--$25$~K in water), suggesting pulsed laser excitation or low-power microfluidic cooling is preferred.
\item \textbf{Brownian Fluctuations and Torque:} The assembly experiences optical torque ($T_z \approx -0.005$~fN$\cdot\mu$m) and anisotropic hydrodynamic drag, requiring optomechanical tracking in viscous media.
\end{enumerate}

\section{Conclusion}
In summary, we have demonstrated that chiral gold nanorod helical assemblies overcome intrinsic ohmic dissipation to achieve strong optical pulling forces under structured Bessel illumination. Through multipolar Kerker interference ($\Delta\Phi_{\mathrm{ED-MD}} \approx 12^\circ$), backward scattering is suppressed, raising forward asymmetry to $g_{\mathrm{asym}} = 0.954$, exceeding the critical threshold $g_{\mathrm{crit}} = 0.721$. An optimized hybrid helix achieves a peak pulling force of $-10.5$~pN/(W/$\mu$m$^2$) ($Q_{\mathrm{pr}} = -0.712$) across a 285-nm bandwidth at 1060~nm. Multi-solver validation, 100-run Monte Carlo tolerance analysis, and Latin Hypercube multivariate regression confirm structural robustness and establish circular dichroism as a reliable predictor. This work opens exciting avenues for polarization-selective optical manipulation, chiral colloidal sorting, and optomechanical nanorobotics.

\section{Data Availability}
The complete dataset supporting this study, including 3D FDTD field monitor exports, 90-configuration LHS database, 30-configuration hold-out test set, Monte Carlo disorder realizations, and Python/MATLAB plotting scripts, has been deposited in the GitHub repository and will be permanently archived on Zenodo upon publication.

\section{Code Availability}
All Lumerical FDTD automation scripts (.lsf, .fsp), Coupled Dipole Approximation solvers, Boundary Element Method MATLAB routines, and visualization codes are available at: \url{https://github.com/priyaphysics/chiral-gold-nanorod-optical-pulling}.

\section{Conflict of Interest}
The authors declare no competing financial or non-financial interests.

\section{AI Disclosure}
During manuscript preparation, generative artificial intelligence tools were used for language refinement, structural formatting, and consistency checking. All scientific concepts, simulation parameters, numerical results, physical interpretations, figures, computational workflows, and conclusions were independently verified and approved by the authors.

\section{Acknowledgments}
Priyanka acknowledges the University of Delhi for research fellowship support. Ram Soorat acknowledges Woxsen University for high-performance computing facilities.

\newpage
\section*{Tables}

\begin{table}[htbp]
\centering
\caption{Canonical Geometrical Parameters of Chiral Gold Nanorod Helical Superstructures.}
\label{tab:geom}
\begin{tabular}{lccc}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} \\
\midrule
Nanorod Length & $L$ & 60.0 & nm \\
Nanorod Diameter & $D$ & 15.0 & nm \\
Nanorod Aspect Ratio & $\mathrm{AR}$ & 4.0 & — \\
Helix Pitch & $p$ & 120.0 & nm \\
Helix Radius & $r$ & 25.0 & nm \\
Nominal Inter-Rod Gap & $g$ & 2.0 & nm \\
Number of Nanorods & $N$ & 10 & rods \\
Taper Amplitude (RH-TCH) & $\delta r$ & 10.0 & nm \\
Pitch Chirp Factor (RH-TCH-CPH) & $\delta p / p_0$ & 20.0 & \% \\
Circumscribed Footprint Area & $A_{\mathrm{eff}}$ & 3318 & nm$^2$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Material and Optical Beam Parameters at Operating Resonance ($\lambda_0 = 1060$ nm).}
\label{tab:opt_params}
\begin{tabular}{lccc}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} \\
\midrule
Operating Wavelength & $\lambda_0$ & 1060 & nm \\
Water Refractive Index & $n_m$ & 1.333 & — \\
Gold Real Permittivity & $\epsilon_1$ & $-48.5$ & — \\
Gold Imaginary Permittivity & $\epsilon_2$ & 3.85 & — \\
Bessel Cone Half-Angle & $\theta_0$ & 49.5 & degrees \\
Longitudinal Momentum Ratio & $\cos\theta_0$ & 0.650 & — \\
Peak Incident Beam Intensity & $I_0$ & 1.0 & W/$\mu$m$^2$ \\
Circumscribed Incident Power & $P_{\mathrm{inc}}$ & $3.318 \times 10^{-3}$ & W \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{FDTD Simulation and Numerical Mesh Settings.}
\label{tab:fdtd_params}
\begin{tabular}{lcc}
\toprule
\textbf{Setting} & \textbf{Specification} & \textbf{Value} \\
\midrule
Domain Dimensions & $L_x \times L_y \times L_z$ & $1.5 \times 1.5 \times 2.0$~$\mu$m$^3$ \\
Boundary Conditions & PML Layers & 16-layer Steep Angle CPML \\
Background Mesh Step & $\Delta x_{\mathrm{bg}}, \Delta y_{\mathrm{bg}}, \Delta z_{\mathrm{bg}}$ & 5.0~nm \\
Refined Gap Mesh Step & $\Delta x, \Delta y, \Delta z$ & 0.5~nm \\
Mesh Refinement Technology & Conformal Mesh & Variant 1 (Metal Interfaces) \\
Simulation Time & $T_{\mathrm{sim}}$ & 150~fs \\
Auto-Shutoff Level & Convergence Threshold & $10^{-6}$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Multi-Solver Cross-Validation Benchmark for Optimized Hybrid Helix at 1060 nm.}
\label{tab:solver_benchmark}
\begin{tabular}{lcccc}
\toprule
\textbf{Method} & \textbf{Peak Force $F_z$ [pN]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{Error vs FDTD (\%)} & \textbf{Formulation} \\
\midrule
FDTD (Maxwell Stress Tensor) & $-10.50$ & $-0.712$ & Baseline & Full-wave Time-Domain \\
FEM (COMSOL Multiphysics) & $-10.22$ & $-0.693$ & 2.7\% & Frequency-Domain Vector Elements \\
Coupled Dipole Approx. (CDA) & $-9.92$ & $-0.673$ & 5.5\% & Semi-Analytical Green's Tensor \\
FDTD (Momentum-Flux Box) & $-10.45$ & $-0.709$ & 0.5\% & Far-Field Poynting Integration \\
Direct Bessel FDTD & $-10.50$ & $-0.712$ & 0.0\% & 24-Wave Synthesized Illumination \\
Angular Spectrum Reconstruction & $-10.62$ & $-0.720$ & 1.1\% & Plane-Wave Linear Superposition \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{FDTD Spatial Mesh Convergence Analysis.}
\label{tab:mesh_conv}
\begin{tabular}{ccccc}
\toprule
\textbf{Grid Size $\Delta x$ (nm)} & \textbf{Peak $|E/E_0|$} & \textbf{Force $F_z$ [pN]} & \textbf{Relative Shift (\%)} & \textbf{Run Time (s)} \\
\midrule
2.0 & 58.4 & $-8.12$ & 22.7\% & 18 \\
1.0 & 78.6 & $-9.15$ & 12.9\% & 52 \\
0.8 & 86.2 & $-9.40$ & 10.5\% & 88 \\
0.5 (Adopted) & 95.2 & $-9.65$ & Baseline & 142 \\
0.4 & 99.1 & $-9.98$ & 3.4\% & 276 \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Geometry Optimization across Helical Architectures.}
\label{tab:geom_opt}
\begin{tabular}{lcccc}
\toprule
\textbf{Architecture} & \textbf{Resonance $\lambda_0$ (nm)} & \textbf{Peak $F_z$ [pN]} & \textbf{Bandwidth $\Delta\lambda$ (nm)} & \textbf{$Q_{\mathrm{pr}}$} \\
\midrule
Achiral Linear Chain & 850 & $+2.20$ & 0 & $+0.149$ \\
RH-CPH (Constant Pitch) & 1020 & $-5.10$ & 70 & $-0.346$ \\
RH-TCH (Tapered) & 1040 & $-7.50$ & 150 & $-0.509$ \\
RH-TCH-CPH (Hybrid) & 1060 & $-10.50$ & 285 & $-0.712$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Polarization Dependence and Handedness Contrast at $\lambda = 1060$ nm.}
\label{tab:pol_contrast}
\begin{tabular}{lcccc}
\toprule
\textbf{Helix Handedness} & \textbf{Polarization} & \textbf{Force $F_z$ [pN]} & \textbf{Regime} & \textbf{$Q_{\mathrm{pr}}$} \\
\midrule
Right-Handed (RH) & LCP & $-10.50$ & Strong Pulling & $-0.712$ \\
Right-Handed (RH) & RCP & $+2.40$ & Forward Pushing & $+0.163$ \\
Right-Handed (RH) & Linear ($x$) & $-4.05$ & Moderate Pulling & $-0.275$ \\
Left-Handed (LH) & LCP & $+2.40$ & Forward Pushing & $+0.163$ \\
Left-Handed (LH) & RCP & $-10.50$ & Strong Pulling & $-0.712$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Multivariate Statistical Regression and Cross-Validation Summary ($N = 90$ LHS Configurations).}
\label{tab:stat_val}
\begin{tabular}{lcccc}
\toprule
\textbf{Evaluation Metric} & \textbf{Formula / Method} & \textbf{Value} & \textbf{Benchmark} & \textbf{Status} \\
\midrule
Coefficient of Determination & $R^2$ (CD vs $F_z$) & 0.947 & $> 0.90$ & PASS \\
5-Fold Cross-Validation & $R^2_{\mathrm{CV}}$ & 0.931 & $> 0.90$ & PASS \\
Independent Hold-Out Set ($N=30$) & $R^2_{\mathrm{test}}$ & 0.937 & $> 0.90$ & PASS \\
Root Mean Square Error & $\mathrm{RMSE}$ & 0.488 & $< 0.80$~pN & PASS \\
Mean Absolute Error & $\mathrm{MAE}$ & 0.372 & $< 0.60$~pN & PASS \\
Unique Partial Variance & Incremental $\Delta R^2$ & 61.0\% & $> 50\%$ & PASS \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Monte Carlo Fabrication Disorder Tolerance Results (100 Realizations).}
\label{tab:mc_tolerance}
\begin{tabular}{lccc}
\toprule
\textbf{Statistical Metric} & \textbf{Simulated Value} & \textbf{Unit} & \textbf{Interpretation} \\
\midrule
Ensemble Mean Force & $-8.92$ & pN/(W/$\mu$m$^2$) & Robust Pulling \\
Standard Deviation & 1.18 & pN/(W/$\mu$m$^2$) & Narrow Spread \\
Median Force & $-8.87$ & pN/(W/$\mu$m$^2$) & Unskewed Ensemble \\
Approximate 95\% Prediction Interval & $[-11.23, -6.61]$ & pN/(W/$\mu$m$^2$) & Entirely Negative \\
Pulling Retention Fraction & 100 / 100 & realizations & 100\% Finite Sample \\
One-Sided 95\% Confidence Bound & $> 97.0$ & \% & High Statistical Confidence \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Comparison with Representative Optical Pulling Systems in Published Literature.}
\label{tab:lit_comparison}
\begin{tabular}{lcccc}
\toprule
\textbf{System / Scatterer} & \textbf{Material Type} & \textbf{Peak $F_z$ [pN/(W/$\mu$m$^2$)]} & \textbf{$Q_{\mathrm{pr}}$} & \textbf{Ref.} \\
\midrule
Silicon Nanosphere (Sukhov et al.) & Dielectric & $-0.85$ & $-0.15$ & \cite{sukhov2015negative} \\
Si/Ag Core-Shell (Chen et al.) & Hybrid & $-1.20$ & $-0.22$ & \cite{chen2011optical} \\
Silicon Dimer (Zhang et al.) & Dielectric & $-2.40$ & $-0.35$ & \cite{zhang2021prl_pulling} \\
Chiral Particle over Metasurface & Metamaterial & $-1.50$ & $-0.20$ & \cite{apl2025optical} \\
Gold Nanorod Helix (This Work) & Pure Metallic & $\mathbf{-10.50}$ & $\mathbf{-0.712}$ & — \\
\bottomrule
\end{tabular}
\end{table}

\begin{table}[htbp]
\centering
\caption{Feasibility Assessment of Nanoscale Fabrication Pathways for AuNR Helices.}
\label{tab:fab_pathways}
\begin{tabular}{lcccc}
\toprule
\textbf{Method} & \textbf{Resolution} & \textbf{Chiral Purity} & \textbf{Throughput} & \textbf{Feasibility} \\
\midrule
DNA Origami Templating & $< 1.0$~nm & $> 95\%$ & High (Solution) & Immediate \\
Glancing-Angle Deposition (GLAD) & $5.0$~nm & $> 90\%$ & Wafer-Scale & Demonstrated \\
Direct Laser Writing (STED) & $20.0$~nm & Moderate & Low & Challenging \\
Colloidal Self-Assembly & $2.0$~nm & $> 85\%$ & High (Bulk) & Viable \\
\bottomrule
\end{tabular}
\end{table}

\newpage
\section*{Figures}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig01/figure.png}
\caption{Overall conceptual architecture and optical-pulling mechanism. (a) Right-handed Au nanorod helix under LCP non-paraxial Bessel illumination. (b) Longitudinal optical pulling force $F_z(\lambda)$ demonstrating peak pulling of $-10.5$~pN/(W/$\mu$m$^2$) at $\lambda_0 = 1060$~nm across a 285-nm continuous pulling bandwidth. As shown in Figure 1, the forward-scattering asymmetry parameter $g_{\mathrm{asym}} = 0.954$ significantly surpasses the critical threshold $g_{\mathrm{crit}} = 0.721$.}
\label{fig:fig01}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig02/figure.png}
\caption{3D geometry of the chiral Au nanorod helical assembly. Ten gold nanorods ($L=60$~nm, $D=15$~nm) arranged along a helical trajectory with radius $r=25$~nm and pitch $p=120$~nm. As shown in Figure 2, the center-of-mass coordinates and spatial rotations follow the discrete parametric equations.}
\label{fig:fig02}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig03/figure.png}
\caption{Coordinate system and geometric parameters. Canonical dimensions of the Au nanorod assembly, including aspect ratio ($\text{AR}=4.0$) and inter-rod nominal gap ($g=2.0$~nm). As shown in Figure 3, parameters are optimized for near-field capacitive hybridization.}
\label{fig:fig03}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig04/figure.png}
\caption{Bessel beam geometry and angular spectrum decomposition. Longitudinal wavevector component $k_z/k_0 = \cos\theta$ and transverse component $k_\perp/k_0 = \sin\theta$. As shown in Figure 4, the operating cone angle $\theta_0 = 49.5^\circ$ reduces longitudinal incident momentum to $\cos\theta_0 = 0.650$.}
\label{fig:fig04}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.90\textwidth]{figures/Fig05/figure.png}
\caption{Gold dielectric permittivity across the 600--1400~nm spectrum. Real ($\epsilon_1$) and imaginary ($\epsilon_2$) permittivity models based on Johnson and Christy data. As shown in Figure 5, ohmic dissipation at 1060~nm introduces an absorption penalty requiring extreme forward scattering.}
\label{fig:fig05}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig06/figure.png}
\caption{Baseline geometry comparison. Optical force spectra for an achiral 10-rod chain ($F_z > 0$), constant-pitch helix (RH-CPH), tapered helix (RH-TCH), and tapered-chirped hybrid helix (RH-TCH-CPH). As shown in Figure 6, structural chirality is mandatory for achieving negative optical forces.}
\label{fig:fig06}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig07/figure.png}
\caption{Extinction cross-section spectra of chiral AuNR helical assemblies. Resonant peaks at 1020~nm (CPH), 1040~nm (TCH), and 1060~nm (Hybrid). As shown in Figure 7, spatial taper and chirp broaden the collective plasmonic cross section.}
\label{fig:fig07}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.90\textwidth]{figures/Fig08/figure.png}
\caption{Circular dichroism and chiroptical anisotropy spectra. Differential circular extinction $\Delta\sigma(\lambda)$ and dissymmetry factor $g_{\mathrm{CD}}(\lambda)$. As shown in Figure 8, strong near-infrared CD confirms intense collective chiral plasmonic hybridization.}
\label{fig:fig08}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig09/figure.png}
\caption{Optical pulling force spectrum and continuous bandwidth. Optical force $F_z(\lambda)$ under LCP (pulling) versus RCP (pushing) illumination. As shown in Figure 9, LCP illumination produces a 285-nm continuous pulling window with a peak force of $-10.5$~pN/(W/$\mu$m$^2$).}
\label{fig:fig09}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig10/figure.png}
\caption{Optical force versus helix pitch. Pitch sweep from 80~nm to 160~nm. As shown in Figure 10, the maximum pulling force is achieved at the canonical pitch $p = 120.0$~nm.}
\label{fig:fig10}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig13/figure.png}
\caption{Polarization dependence and handedness contrast. Longitudinal force under LCP versus RCP illumination for the right-handed hybrid helix. As shown in Figure 11 (plotted in Fig 13), switching beam polarization dynamically reverses the force from negative pulling to positive pushing.}
\label{fig:fig13}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig15/figure.png}
\caption{Cartesian multipole decomposition. Scattering cross sections of electric dipole (ED), magnetic dipole (MD), and electric quadrupole (EQ) modes. As shown in Figure 12 (plotted in Fig 15), balanced dipolar co-excitation underpins Kerker-like backward scattering suppression.}
\label{fig:fig15}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig17/figure.png}
\caption{Forward scattering asymmetry parameter $g_{\mathrm{asym}}(\lambda)$ compared with the critical pulling threshold $g_{\mathrm{crit}} = 0.721$. As shown in Figure 13 (plotted in Fig 17), $g_{\mathrm{asym}}$ peaks at 0.954, decisively fulfilling the optical pulling momentum criterion.}
\label{fig:fig17}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.90\textwidth]{figures/Fig20/figure.png}
\caption{Multi-solver cross-validation. Comparison of predicted optical pulling force and relative discrepancy across FDTD, FEM (COMSOL, 2.7\%), CDA (5.5\%), and momentum-flux methods. As shown in Figure 14 (plotted in Fig 20), excellent quantitative agreement is confirmed.}
\label{fig:fig20}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig22/figure.png}
\caption{Monte Carlo fabrication tolerance analysis across 100 disorder realizations. Histogram of calculated pulling forces under simultaneous five-parameter Gaussian disorder. As shown in Figure 15 (plotted in Fig 22), 100/100 realizations retain optical pulling with mean $\langle F_z \rangle = -8.92 \pm 1.18$~pN/(W/$\mu$m$^2$).}
\label{fig:fig22}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.80\textwidth]{figures/Fig24/figure.png}
\caption{Circular dichroism as a robust predictor of optical pulling force. Linear regression between CD and pulling force across 90 Latin Hypercube configurations. As shown in Figure 16 (plotted in Fig 24), a high correlation of $R^2 = 0.947$ is established.}
\label{fig:fig24}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.85\textwidth]{figures/Fig27/figure.png}
\caption{Final integrated structure-property-function framework. Flowchart illustrating the rational progression from gold nanorod geometry to collective multipolar interference, momentum redistribution, and polarization-selective optical pulling. As shown in Figure 17 (plotted in Fig 27), this framework establishes the nanophotonic mechanism targeted for ACS Applied Nano Materials.}
\label{fig:fig27}
\end{figure}

\bibliography{08_references}

\end{document}
"""

with open(out_path, "w", encoding="utf-8") as f:
    f.write(content)

print(f"Saved {out_path} ({len(content)} chars, {len(content.splitlines())} lines)")
