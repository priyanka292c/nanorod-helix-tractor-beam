import re

src_dir = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant"

with open(f"{src_dir}\\main.tex", "r", encoding="utf-8") as f:
    main_text = f.read()

with open(f"{src_dir}\\supplementary.tex", "r", encoding="utf-8") as f:
    supp_text = f.read()

def get_cites(text):
    raw = re.findall(r'\\cite[a-zA-Z]*\{([^}]+)\}', text)
    keys = []
    for r in raw:
        for k in r.split(','):
            k = k.strip()
            if k:
                keys.append(k)
    return keys

main_cites = get_cites(main_text)
supp_cites = get_cites(supp_text)
all_unique_cites = sorted(list(set(main_cites + supp_cites)))

print(f"Total citation occurrences in main.tex: {len(main_cites)}")
print(f"Unique cited keys in main.tex: {len(set(main_cites))}")
print(f"Unique cited keys in supplementary.tex: {len(set(supp_cites))}")
print(f"Total unique cited keys overall: {len(all_unique_cites)}")
print("Cited keys:", all_unique_cites)
