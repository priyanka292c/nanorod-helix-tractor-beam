import os
import re
import json
import time
import urllib.request
import urllib.parse

src_bib = r"d:\Priyanka\Research\Submitted\Rejected\Collective Forward-Scattering Interference Enables Giant (2)\Collective Forward-Scattering Interference Enables Giant\Collective Forward-Scattering Interference Enables Giant\references.bib"

with open(src_bib, "r", encoding="utf-8") as f:
    text = f.read()

# Parse entries
entries = re.split(r'\n@', text)
bib_dict = {}
for block in entries:
    if not block.strip():
        continue
    lines = block.split('\n')
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', lines[0].strip().lstrip('@'))
    if m:
        etype = m.group(1).lower()
        key = m.group(2).strip()
        
        doi_m = re.search(r'doi\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        year_m = re.search(r'year\s*=\s*[\"{]?(\d{4})[\"}]?', block)
        title_m = re.search(r'title\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        journal_m = re.search(r'journal\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        author_m = re.search(r'author\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        volume_m = re.search(r'volume\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)
        pages_m = re.search(r'pages\s*=\s*[\"{](.*?)[\"}]', block, re.IGNORECASE)

        doi = doi_m.group(1).strip() if doi_m else None
        # Clean doi
        if doi:
            doi = doi.replace("https://doi.org/", "").replace("http://dx.doi.org/", "").strip()
        
        bib_dict[key] = {
            "key": key,
            "etype": etype,
            "doi": doi,
            "year": year_m.group(1).strip() if year_m else "",
            "title": title_m.group(1).strip() if title_m else "",
            "journal": journal_m.group(1).strip() if journal_m else "",
            "author": author_m.group(1).strip() if author_m else "",
            "volume": volume_m.group(1).strip() if volume_m else "",
            "pages": pages_m.group(1).strip() if pages_m else "",
            "raw": block
        }

print(f"Loaded {len(bib_dict)} entries from source references.bib")

# Let's check which entries have duplicate DOIs
doi_map = {}
for k, v in bib_dict.items():
    if v["doi"]:
        d_lower = v["doi"].lower()
        doi_map.setdefault(d_lower, []).append(k)

for d, keys in doi_map.items():
    if len(keys) > 1:
        print(f"Duplicate DOI {d}: keys {keys}")

# Function to verify DOI with Crossref
def query_crossref_doi(doi):
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers={'User-Agent': 'ResearchPaperAuditor/1.0 (mailto:priyanka292c@gmail.com)'})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
            msg = data.get("message", {})
            title = msg.get("title", [""])[0]
            container = msg.get("container-title", [""])[0]
            published = msg.get("published", {}).get("date-parts", [[0]])[0][0]
            authors = []
            for a in msg.get("author", []):
                g = a.get("given", "")
                f = a.get("family", "")
                if f:
                    authors.append(f"{g} {f}".strip() if g else f)
            return {
                "valid": True,
                "title": title,
                "journal": container,
                "year": str(published),
                "author": " and ".join(authors),
                "volume": msg.get("volume", ""),
                "page": msg.get("page", "")
            }
    except Exception as e:
        return {"valid": False, "error": str(e)}

# Let's test a sample of entries
test_keys = list(bib_dict.keys())[:5]
for tk in test_keys:
    d = bib_dict[tk]["doi"]
    if d:
        res = query_crossref_doi(d)
        print(f"Key [{tk}] DOI={d} -> Valid={res.get('valid')} Title={res.get('title')[:40] if res.get('valid') else res.get('error')}")
