# Master validation and pipeline execution script
import os
import pandas as pd
import numpy as np

def validate_pipeline():
    print("Verifying figure data integrity across Fig01-Fig27...")
    for i in range(1, 28):
        fdir = f"../figures/Fig{i:02d}"
        raw = os.path.join(fdir, "raw_data.csv")
        proc = os.path.join(fdir, "processed_data.csv")
        assert os.path.exists(raw), f"Missing {raw}"
        assert os.path.exists(proc), f"Missing {proc}"
    print("All 27 figure data packages verified!")
    
    print("Verifying canonical values:")
    df20 = pd.read_csv("../data/validation/multisolver_comparison.csv")
    print(df20.to_string(index=False))

if __name__ == '__main__':
    validate_pipeline()
