# Figure 23: Latin Hypercube Parameter Space
- Sample size: N = 90 configurations
- Parameter ranges: Pitch 80-160 nm, Radius 15-35 nm, Taper 0-20 nm
