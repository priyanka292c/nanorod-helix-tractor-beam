# Figure 07: Cross-Section Spectra
- Solvers: FDTD, FEEM, BEM MATLAB (mesh = 0.5 nm)
- Data points: 501 points
