# Figure 04: Bessel Angular Spectrum
- Data points: 501 points
