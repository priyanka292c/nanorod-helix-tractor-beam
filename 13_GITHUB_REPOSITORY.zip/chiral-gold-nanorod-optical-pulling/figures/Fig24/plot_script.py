# Publication Plotting Script for Fig24
# Solvers: FDTD, LUMPI, FEEM, BEM MATLAB
# Mesh resolution: 0.5 nm
# Data points: 500 discrete simulation points
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('processed_data.csv')
fig, ax = plt.subplots(figsize=(6.8, 4.6), dpi=300)
x_col = df.columns[0]
markers = ['o', 'd', '^', 's', 'v', 'p', 'h']
colors = ['#003366', '#8B008B', '#228B22', '#D95F02', '#CC3333', '#008B8B', '#8B4513']

for idx, col in enumerate(df.columns[1:]):
    if col in ['mesh_size_nm', 'mesh_nm']:
        continue
    m = markers[idx % len(markers)]
    c = colors[idx % len(colors)]
    lbl = col.replace('_', ' ')
    ax.plot(df[x_col], df[col], label=lbl, color=c, lw=0.9, marker=m, markersize=3.2, markevery=2, alpha=0.85)

ax.set_xlabel(x_col.replace('_', ' '), fontsize=11, fontweight='bold')
ax.set_ylabel('Observable', fontsize=11, fontweight='bold')
ax.grid(True, linestyle='--', alpha=0.4)
ax.legend(frameon=True, facecolor='white', framealpha=0.92, fontsize=8.2)
ax.tick_params(direction='in', top=True, right=True, labelsize=10)
plt.tight_layout()
plt.savefig('figure.png', dpi=300)
plt.savefig('figure.jpg', dpi=300)
plt.savefig('figure.pdf')
plt.close()
