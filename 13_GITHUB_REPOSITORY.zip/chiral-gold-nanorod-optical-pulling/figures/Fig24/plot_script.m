%% MATLAB Plotting Script for Fig24
%% Solvers: FDTD, LUMPI, FEEM, BEM MATLAB | Mesh: 0.5 nm | Data points: 500
data = readtable('processed_data.csv');
figure('Color', 'w');
x = data{:, 1};
for i = 2:width(data)
    if ~strcmp(data.Properties.VariableNames{i}, 'mesh_size_nm') && ~strcmp(data.Properties.VariableNames{i}, 'mesh_nm')
        plot(x, data{:, i}, '-o', 'LineWidth', 0.9, 'MarkerSize', 3.2, 'DisplayName', data.Properties.VariableNames{i});
        hold on;
    end
end
xlabel(data.Properties.VariableNames{1});
ylabel('Observable');
grid on;
legend('Location', 'best');
title(''); % No top title to avoid duplicate captions
saveas(gcf, 'figure_matlab.png');
