# Figure 24: CD Predictor Regression
- Sample size: N = 90 LHS configurations
- R^2 = 0.947, RMSE = 0.42 pN
- Independent hold-out: N = 30 configurations (R^2 = 0.937)
