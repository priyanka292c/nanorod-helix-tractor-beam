# Figure 17: Forward/Backward Scattering Ratio
- Solvers: FDTD, FEEM, BEM MATLAB (mesh = 0.5 nm)
- Data points: 501 points
