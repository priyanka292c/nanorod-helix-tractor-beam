# Figure 19: Direct Bessel FDTD vs ASR
- Data points: 501 points
- Solvers: LUMPI, FDTD
