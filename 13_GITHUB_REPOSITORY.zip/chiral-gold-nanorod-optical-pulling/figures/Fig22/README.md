# Figure 22: Monte Carlo Fabrication Tolerance Analysis
- Total Realizations: 100
- Pulling Success: 100/100 (100%)
- Mean Force: -9.82 pN/(W/um^2)
- Standard Deviation: 0.62 pN/(W/um^2)
- 95% Confidence Lower Bound: >97.0%
