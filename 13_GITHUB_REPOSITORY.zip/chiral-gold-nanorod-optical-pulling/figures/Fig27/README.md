# Figure 27: Integrated Framework Mapping
- Data points: 501 points
- Solvers: FDTD, LUMPI, FEEM, BEM MATLAB
