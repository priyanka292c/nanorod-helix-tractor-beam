# Figure 02: 3D Helical Trajectory
- Data points: 501 points
- Mesh: 0.5 nm conformal
