# Figure 12: Taper Angle Optimization
- Data points: 501 points
- Sweep: 0–20°
