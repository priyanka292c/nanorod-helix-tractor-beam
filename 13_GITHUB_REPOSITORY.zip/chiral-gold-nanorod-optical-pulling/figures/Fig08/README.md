# Figure 08: Circular Dichroism Spectra
- Solvers: FDTD, LUMPI, FEEM, BEM MATLAB (mesh = 0.5 nm)
- Data points: 501 points
