# Figure 18: Bessel Cone Angle Sweep
- Data points: 501 points
