# Figure 03: Gap Near-Field & Capacitance
- Data points: 501 points
- Mesh: 0.5 nm FDTD
