# Figure 10: Pitch Optimization
- Data points: 501 points
- Sweep: 80–160 nm
