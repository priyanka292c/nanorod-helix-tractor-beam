# Figure 14: Far-Field Angular Scattering
- Data points: 361 points
