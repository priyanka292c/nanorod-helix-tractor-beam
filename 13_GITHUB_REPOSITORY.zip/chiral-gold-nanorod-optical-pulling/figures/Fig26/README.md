# Figure 26: Application Drift Velocity
- Data points: 501 points
