# Figure 25: Cross-Validation & Prediction
- Sample size: N = 30 independent hold-out configurations
- R^2_test = 0.937, RMSE = 0.45 pN/(W/um^2)
