# Figure 09: Central Optical Pulling Force & Qpr
- Solvers: FDTD, LUMPI, FEEM, BEM MATLAB (mesh = 0.5 nm)
- Data points: 501 points
- Visible markers: Rendered at every 2nd point (251 visible dots per curve)
