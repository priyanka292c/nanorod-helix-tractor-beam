# Figure 11: Radius Optimization
- Data points: 501 points
- Sweep: 15–35 nm
