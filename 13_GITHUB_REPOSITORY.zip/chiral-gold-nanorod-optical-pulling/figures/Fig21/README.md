# Figure 21: Mesh Convergence Study
- Solvers: FDTD, FEEM, BEM MATLAB
- Mesh range: 0.2 to 4.0 nm (Adopted dx = 0.5 nm)
- Data points: 501 points
