# Figure 15: Multipole Decomposition
- Solvers: FDTD, FEEM, BEM MATLAB (mesh = 0.5 nm)
- Data points: 501 points
