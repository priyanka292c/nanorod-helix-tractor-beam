# Figure 16: Multipolar Phase Coherence
- Data points: 501 points
