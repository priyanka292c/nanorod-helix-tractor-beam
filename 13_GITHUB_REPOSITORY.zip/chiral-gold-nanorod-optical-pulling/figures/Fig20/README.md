# Figure 20: Multi-Solver Cross-Validation Benchmark
- Solvers: FDTD, LUMPI, FEEM (COMSOL), BEM MATLAB (MNPBEM), CDA
- Mesh size: 0.5 nm
- Data points: 501 discrete points
- Visible markers: Rendered at every 2nd point (>250 visible dots per curve)
