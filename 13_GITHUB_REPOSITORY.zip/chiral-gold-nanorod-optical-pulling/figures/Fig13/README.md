# Figure 13: Polarization Switching
- Data points: 501 points
- Mesh: 0.5 nm
