# Figure 06: Structural Progression Comparison
- Data points: 501 points
- Mesh: 0.5 nm FDTD
