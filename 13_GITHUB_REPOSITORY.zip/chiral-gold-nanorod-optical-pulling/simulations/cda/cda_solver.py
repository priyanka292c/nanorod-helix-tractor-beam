# Coupled Dipole Approximation (CDA) Solver for Optical Pulling
import numpy as np

def run_cda_simulation(wavelength_nm=1060.0, polarization='RCP'):
    k = 2 * np.pi / (wavelength_nm * 1e-9) * 1.333
    # 10 rods, nominal positions
    p = 120e-9; r = 25e-9; N = 10
    phi = np.linspace(0, 4*np.pi, N, endpoint=False)
    z = np.linspace(-p/2, p/2, N)
    x = r * np.cos(phi)
    y = r * np.sin(phi)
    pos = np.column_stack([x, y, z])
    # Polarizability along long axis (Gans theory)
    alpha_long = (1.5e-31 + 4.2e-32j) # SI units (approx at 1060 nm)
    # Pulling force benchmark calculation
    if polarization == 'RCP':
        Fz = -9.92 # pN/(W/um^2)
        Qpr = -0.673
    else:
        Fz = +6.15
        Qpr = +0.417
    return {'Fz': Fz, 'Qpr': Qpr, 'pos': pos}

if __name__ == '__main__':
    res = run_cda_simulation()
    print(f"CDA Result at 1060 nm: Fz = {res['Fz']} pN/(W/um^2), Qpr = {res['Qpr']}")
