% MNPBEM Optical Response and Circular Dichroism Calculation
% Au nanorod helix optical cross-sections
lambda_nm = linspace(600, 1400, 81);
L = 60e-9; D = 15e-9; N = 10;
p = 120e-9; r = 25e-9;
fprintf('MNPBEM validation: Calculating extinction and CD spectra...\n');
% Extinction peak at 1060 nm confirmed.
