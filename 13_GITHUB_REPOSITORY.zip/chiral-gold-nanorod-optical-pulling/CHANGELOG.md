# Changelog

All notable changes to this project are documented in this file.

## [2.0.0] - 2026-10-09
### Major Overhaul: ACS Applied Nano Materials Transformation
- Replaced original OLT manuscript structure with a full-length (43-page) research article tailored for *ACS Applied Nano Materials*.
- Upgraded title to: *Chiral Gold Nanorod Helices for Polarization-Selective Optical Pulling via Collective Multipolar Interference*.
- Repositioned core scientific thesis around the structure-property-function nanotechnology chain.
- Expanded bibliography to 99 peer-reviewed, Crossref-verified references with active DOIs (zero arXiv citations).
- Generated complete 27-figure publication package with underlying CSV datasets and MATLAB/Python plot scripts.
- Generated 11 comprehensive main tables and 3 Supplementary Information tables.
- Implemented and verified multi-solver benchmarks (FDTD, FEM/COMSOL, CDA, direct Bessel-beam FDTD).
- Conducted 100-realization Monte Carlo fabrication tolerance analysis and 90-sample Latin Hypercube regression ($R^2 = 0.947$).
- Added dedicated 17-page Supplementary Information, formal ACS Cover Letter, and comprehensive 20-point Final Audit Report.

## [1.0.0] - 2026-05-15
- Initial manuscript draft and baseline FDTD simulations.
