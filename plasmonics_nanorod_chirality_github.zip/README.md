# Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices

[![GitHub](https://img.shields.io/badge/GitHub-nanorod--helix--tractor--beam-blue?logo=github)](https://github.com/priyanka292c/nanorod-helix-tractor-beam)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

This repository contains the complete reproducible Python codebase, 3D FDTD electromagnetic scattering datasets, Latin Hypercube design sweeps ($N=90$ and $N=120$), multipolar decomposition routines, and publication manuscripts for:

> **"Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices"**  
> **Authors**: Priyanka$^1$ and Ram Soorat$^{2,*}$  
> $^1$ *Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India* (`priyanka292c@gmail.com`)  
> $^2$ *School of Technology, Woxsen University, Hyderabad, Telangana 502345, India*  
> $^*$ *Corresponding author*: `rsoorat@gmail.com`  
> *Target Journal*: **Journal of Quantitative Spectroscopy & Radiative Transfer (JQSRT)**  

---

## 📂 Repository Structure

```
nanorod-helix-tractor-beam/
│
├── README.md                                  # Complete repository documentation & instructions
├── LICENSE                                    # MIT Open Source License
├── .gitignore                                 # Git ignore file
├── reproduce_all_paper_results.py             # Single master script reproducing all numerical values
│
├── python/                                    # Python quantum-statistical analysis scripts
│   ├── reproduce_all_paper_results.py         # Numerical reproduction script
│   ├── quantum_force_plasmon.py               # Stochastic momentum-channel partition model
│   └── fdtd_lumerical_api.py                  # Python API for Ansys Lumerical FDTD automation
│
├── LHS/                                       # Latin Hypercube Sampling datasets
│   ├── lhs_chiral_force_dataset_90pts.csv     # 90-configuration primary design dataset
│   └── lhs_chiral_force_dataset_120pts.csv    # 120-configuration sample-size convergence dataset
│
├── FDTD/                                      # Electromagnetic scattering & simulation data
│   ├── farfield_scattering_matrices_1060nm.npz # Far-field angular scattering cross-section matrices
│   └── fdtd_lumerical_api.py                  # FDTD Maxwell stress tensor automation interface
│
├── figures/                                   # High-resolution publication figures & generation scripts
│   ├── generate_all_manuscript_figures.py     # Script to generate Figures 1 through 9
│   ├── Figure1_system_schematic.pdf / .png
│   ├── Figure2_classical_quantum_validation.pdf / .png
│   ├── Figure3_force_noise_spectra.pdf / .png
│   ├── Figure4_chirality_polarization_comparison.pdf / .png
│   ├── Figure5_chiral_contrasts.pdf / .png
│   ├── Figure6_force_noise_pareto.pdf / .png
│   ├── Figure7_multipolar_noise_decomposition.pdf / .png
│   ├── Figure8_photon_number_scaling.pdf / .png
│   ├── Figure9_cd_force_noise_correlations.pdf / .png
│   └── Graphical_Abstract.pdf / .png / .jpg
│
└── manuscript/                                # Submission manuscript & supplementary files
    ├── manuscript_jqsrt.pdf                   # JQSRT Main Article PDF
    ├── manuscript_jqsrt.tex                   # JQSRT LaTeX source
    ├── supplementary_jqsrt.pdf                # Supplementary Material PDF
    ├── supplementary_jqsrt.tex                # Supplementary Material LaTeX source
    ├── cover_letter_jqsrt.pdf                 # Cover Letter PDF
    ├── cover_letter_jqsrt.tex                 # Cover Letter LaTeX source
    ├── references.bib                         # BibTeX reference database
    └── highlights.txt                         # Key submission highlights
```

---

## ⚡ 1-Line Complete Numerical Reproduction

To reproduce all reported forces, second moments, force-transfer efficiencies, noise spectral densities, and enhancement factors:

```bash
python reproduce_all_paper_results.py
```

### Expected Output Summary:
* **Operating Point**: Right-Handed 10-nanorod gold helix (RH-TCH-CPH) in water ($n_m = 1.333$) under LCP Bessel illumination at $\lambda = 1060$~nm ($\theta_0 = 49.46^\circ$).
* **Mean Pulling Force**: $\langle F_z \rangle = -10.35\text{ pN}/(\text{W}/\mu\text{m}^2)$ ($\sigma_{\rm pr,z} = -2.33 \times 10^{-15}\text{ m}^2$).
* **Single-Event Momentum Variance**: $V_{\Delta p} = 11.06 \times 10^{-56}\text{ kg}^2\cdot\text{m}^2/\text{s}^2$ ($\langle (\Delta p_z)^2 \rangle_1 = 12.26 \times 10^{-56}\text{ kg}^2\cdot\text{m}^2/\text{s}^2$).
* **Force-Transfer Efficiency**: $\eta_F = 0.3128$ (Chiral) vs. $0.2581$ (Achiral) $\implies \mathcal{A}_{\rm SNR}^{\rm int} = \mathbf{1.212}$ ($+21.2\%$).
* **Fixed-Flux Coherent Force SNR Enhancement**: $\mathcal{A}_{\rm SNR}^{\Phi} = \frac{\mathcal{E}_F}{\mathcal{N}_F} = \frac{2.288}{1.274} \approx \mathbf{1.792}$ ($\mathbf{+79.2\%}$).
* **Thermal Dissipation Rise**: $\Delta T_{\rm max} \approx 7.4\text{ K}$ (at $P_{\rm exp} = 10\text{ mW}$).
* **Brownian Crossover Flux**: $\Phi_{\rm cross} \approx 2.88 \times 10^{39}\text{ photons}\cdot\text{s}^{-1}\cdot\text{m}^{-2}$.

---

## 🎨 Re-generating All Figures (1 through 9)

To regenerate all publication figures at 300 DPI:

```bash
python generate_all_manuscript_figures.py
```

---

## 🔬 Master Results & Comparison Table

| Observable | RH-TCH-CPH (LCP) | Achiral Control | Unit / Comparison |
| :--- | :---: | :---: | :--- |
| **Extinction Cross-Section $\sigma_{\rm ext}$** | $1.77 \times 10^{-14}$ | $0.81 \times 10^{-14}$ | $\text{m}^2$ |
| **Mean Pulling Force $\langle F_z \rangle$** | $\mathbf{-10.35}$ (Pulling) | $\mathbf{+4.53}$ (Pushing) | $\text{pN}/(\text{W}/\mu\text{m}^2)$ |
| **Second Moment $\langle (\Delta p_z)^2 \rangle_1$** | $\mathbf{12.26 \times 10^{-56}}$ | $\mathbf{16.53 \times 10^{-56}}$ | $\text{kg}^2\cdot\text{m}^2/\text{s}^2$ |
| **Single-Event Variance $V_{\Delta p}$** | $\mathbf{11.06 \times 10^{-56}}$ | $\mathbf{15.43 \times 10^{-56}}$ | $\text{kg}^2\cdot\text{m}^2/\text{s}^2$ |
| **Force-Transfer Efficiency $\eta_F$** | $\mathbf{0.3128}$ | $\mathbf{0.2581}$ | $\mathcal{A}_{\rm SNR}^{\rm int} = \mathbf{1.212}$ ($+21.2\%$) |
| **Force Noise Amplitude $\sqrt{S_{FF}}$** | $\mathbf{0.152}$ | $\mathbf{0.120}$ | $\text{aN}/\sqrt{\text{Hz}}$ ($\mathcal{N}_F = \mathbf{1.274}$) |
| **Coherent SNR Gain $\mathcal{A}_{\rm SNR}^{\Phi}$** | $\mathbf{1.792}$ | Baseline | $\mathbf{+79.2\%}$ Gain |
| **LHS Design Sweeps** | $N=90$ and $N=120$ | --- | Verified ($R^2$ stability $< \pm 0.003$) |

---

## 📜 Citation

```bibtex
@article{priyanka2026quantum,
  author    = {Priyanka and Ram Soorat},
  title     = {Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices},
  journal   = {Journal of Quantitative Spectroscopy and Radiative Transfer},
  year      = {2026},
  note      = {Submitted}
}
```

## 📄 License
This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
