# Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices

[![GitHub](https://img.shields.io/badge/GitHub-nanorod--helix--tractor--beam-blue?logo=github)](https://github.com/priyanka292c/nanorod-helix-tractor-beam)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

This repository contains the full numerical analysis scripts, quantum-statistical models, 3D FDTD simulation pipelines (Ansys Lumerical), MATLAB BEM routines, and figure generation workflows for:

> **"Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices"**  
> **Authors**: Priyanka$^1$ and Ram Soorat$^{2,*}$  
> $^1$ *Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
> $^2$ *School of Technology, Woxsen University, Hyderabad, Telangana 502345, India*  
> $^*$ *Corresponding author*: `rsoorat@gmail.com` | *Contact*: `priyanka292c@gmail.com`  

---

## 📂 Repository Contents

```
plasmonics-nanorod-chirality/
│
├── Python Scripts & Quantum Analysis
│   ├── generate_all_figures.py             # Complete end-to-end figure generation (Figures 1–9)
│   ├── quantum_force_plasmon.py            # Quantum momentum-transfer & noise calculation engine
│   ├── cda_quantum_validation.py           # Coupled dipole approximation (CDA) validation model
│   ├── fdtd_lumerical_api.py               # Python API wrapper for Ansys Lumerical automation
│   ├── export_fdtd_figures.py              # Export and rendering routines for 3D FDTD field data
│   └── test_reconstruction.py              # Unit tests for angular momentum & force reconstruction
│
├── Numerical Datasets & Electromagnetic Scripts
│   ├── cda_benchmark_output.csv            # Polarization-resolved cross-sections & force spectra
│   ├── fdtd_quantum_pipeline.lsf           # Ansys Lumerical LSF automation script for full-wave 3D FDTD
│   ├── export_all_bem_matlab_figures.m     # MATLAB script for Boundary Element Method (BEM) plots
│   └── bem_simulation_figures.m            # MATLAB script for BEM near-field and surface charge modes
│
├── Publication Figures (PDF & PNG)
│   ├── Figure1_system_schematic.*          # Nanorod helix geometry and non-paraxial Bessel beam
│   ├── Figure2_classical_quantum_validation.* # Classical-to-quantum correspondence and shot-noise scaling
│   ├── Figure3_force_noise_spectra.*       # Force-noise spectral density and time-domain fluctuations
│   ├── Figure4_chirality_polarization_comparison.* # Chiroptical pulling/pushing and enantiomeric reversal
│   ├── Figure5_chiral_contrasts.*          # Chiral force, noise, and SNR contrast spectra
│   ├── Figure6_force_noise_pareto.*        # Multi-objective Pareto frontier across 90 LHS geometries
│   ├── Figure7_multipolar_noise_decomposition.* # ED, MD, EQ, MQ and covariance decomposition
│   ├── Figure8_photon_number_scaling.*     # Fock, coherent, and squeezed state SNR scaling
│   ├── Figure9_cd_force_noise_correlations.* # CD vs. force and noise regression analysis
│   ├── Figure_BEM_*.*                      # Boundary Element Method (BEM) validation figures
│   └── Figure_FDTD_*.*                     # 3D FDTD near-field and far-field radiation profiles
│
└── Documentation
    ├── README.md                           # Repository documentation (this file)
    ├── quickstart_execution_guide.md       # Step-by-step guide for reproducing all results
    ├── references.bib                      # Bibliography database
    └── LICENSE                             # MIT Open Source License
```

---

## ⚡ Quickstart & Reproducibility

### 1. Requirements & Dependencies
* Python 3.9+
* Required packages:
  ```bash
  pip install numpy scipy matplotlib pandas
  ```
* Optional (for direct full-wave re-simulation):
  * **Ansys Lumerical 2024 R1** (with `lumapi`)
  * **MATLAB R2022b+** (for BEM scripts)

### 2. Generating All Figures
To re-generate all publication figures (Figures 1–9) directly from the underlying quantum momentum-transfer model:
```bash
python generate_all_figures.py
```
This generates high-resolution `.pdf` (vector) and `.png` (raster) figures in the root directory.

### 3. Running Quantum-Statistical Analysis
To execute the quantum force operator variance and SNR calculation:
```bash
python quantum_force_plasmon.py
```

### 4. Running CDA Benchmarking
To run the coupled-dipole electrodynamic verification:
```bash
python cda_quantum_validation.py
```

---

## 🔬 Core Physics & Key Results

1. **Quantum Momentum-Transfer Model**: Models the optical pulling force as a stochastic momentum-partitioning process over forward, backward, and absorptive channels under non-paraxial Bessel illumination.
2. **Fock-State Noise**: Demonstrates that pure Fock states $|n\rangle$ retain finite force fluctuations $\text{Var}(\bar{F}_z)^{\rm Fock} = \frac{n}{\tau^2} V_{\Delta p} > 0$ due to probabilistic photon scattering channel partitioning.
3. **Chiral SNR Enhancement**: At the pulling resonance ($\lambda = 1060$~nm, $\langle F_z \rangle = -10.35$~pN/(W/$\mu$m$^2$)), structural chirality yields:
   * Single-interacting-photon force efficiency gain: $\mathcal{A}_{\rm SNR}^{\rm int} = \mathbf{1.212}$ ($+21.2\%$)
   * Fixed-flux coherent-state force SNR enhancement: $\mathcal{A}_{\rm SNR}^{\Phi} = \mathbf{1.792}$ ($+79.2\%$)
4. **Multipolar Covariance**: Identifies a $+30.8\%$ electric-dipole–magnetic-dipole (ED–MD) interference covariance contribution to the force variance.
5. **Statistical Robustness**: Validated across $n = 90$ and $n = 120$ Latin Hypercube Sampling (LHS) configurations.

---

## 📜 Citation

If you use this code or dataset in your research, please cite:

```bibtex
@article{priyanka2026quantum,
  author    = {Priyanka},
  title     = {Quantum-Statistical Momentum-Transfer Fluctuations and Chiral Enhancement of Optical Pulling in Plasmonic Nanorod Helices},
  journal   = {Physical Review A},
  year      = {2026},
  note      = {In review}
}
```

---

## 📄 License
This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
