# Chiral Plasmonic Enhancement of Optical Pulling and Force Sensitivity under Non-Paraxial Bessel Illumination

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Journal: Optics & Laser Technology](https://img.shields.io/badge/Journal-Optics%20%26%20Laser%20Technology-red.svg)](https://www.sciencedirect.com/journal/optics-and-laser-technology)

This repository contains the complete simulation models, finite-difference time-domain (FDTD) configurations, far-field angular scattering matrices, Latin Hypercube design datasets, and Python analysis scripts accompanying the research article:

> **"Chiral Plasmonic Enhancement of Optical Pulling and Force Sensitivity under Non-Paraxial Bessel Illumination"**  
> **Priyanka**$^1$ and **Ram Soorat**$^{2,*}$  
> $^1$ *Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
> $^2$ *School of Technology, Woxsen University, Hyderabad, Telangana 502345, India*  
> $^*$ *Corresponding author email:* `rsoorat@gmail.com`  
> *Under review in Optics & Laser Technology (Elsevier, ISSN: 0030-3992)*

---

## 🔬 Scientific Highlights & Key Numerical Results

| Observable / Metric | Symbol | Value at $\lambda = 1060$ nm | Significance |
| :--- | :--- | :--- | :--- |
| **Longitudinal Pulling Force** | $\langle F_z \rangle$ | **$-10.35$ pN/(W/$\mu$m$^2$)** | Strong negative tractor-beam recoil force |
| **Radiation-Pressure Efficiency** | $Q_\mathrm{pr}$ | **$-0.530$** | Normalized to $A_\mathrm{eff} = \pi R_\mathrm{avg}^2 \approx 4.40\times10^{-15}\text{ m}^2$ |
| **Scattering Asymmetry** | $\langle\cos\theta_\mathrm{scat}\rangle$ | **$0.954$** | Forward-biased scattering ($> 0.793$ pulling threshold) |
| **Force-Transfer Efficiency** | $\eta_F$ | **$0.3128$** | Dimensionless single-photon momentum efficiency |
| **Force-Noise ASD (single-sided)** | $\sqrt{S_{FF}}$ | **$0.1522$ aN/$\sqrt{\text{Hz}}$** | Model-predicted quantum momentum partition noise |
| **Chiral Force Enhancement** | $\mathcal{E}_F$ | **$2.288$** | $+128.8\%$ pulling force vs achiral reference |
| **Noise ASD Ratio** | $\mathcal{N}_F$ | **$1.274$** | Force amplifies faster than noise ($2.288 > 1.274$) |
| **Fixed-Flux Coherent SNR Gain** | $\mathcal{A}_\mathrm{SNR}^\Phi$ | **$1.792$ ($+79.2\%$)** | Ratio $\mathcal{E}_F / \mathcal{N}_F$ at identical beam flux |
| **ED–MD Cross-Covariance** | Cov(ED, MD) | **$+30.8\%$** | Largest individual cross-covariance contribution |

---

## ⚡ Quick Start & One-Line Reproduction

Clone or download the repository and verify all published 1060-nm numerical results:

```bash
# Clone the repository
git clone https://github.com/priyanka292c/nanorod-helix-tractor-beam.git
cd nanorod-helix-tractor-beam

# 1. Run master reproducibility verification (reproduces Table 1 & Table 2)
python Python/reproduce_all_paper_results.py

# 2. Verify single-sided vs double-sided PSD/ASD calculation
python Python/PSD_ASD.py

# 3. Verify multipolar covariance decomposition (Table 3)
python Python/multipolar_analysis.py

# 4. Generate all manuscript figures (Figures 1-9 in PDF and PNG)
python Figures/figure_generation_scripts/generate_all_manuscript_figures.py
```

---

## 📂 Repository Directory Structure

```
.
├── README.md                                  # Documentation and quickstart guide
├── LICENSE                                    # Open-source MIT License
├── plasmonics_nanorod_chirality_github.zip   # Complete standalone zipped archive (17 MB)
│
├── Lumerical/                                 # FDTD electrodynamic simulation files
│   ├── geometry/
│   │   └── helix_geometry_parameters.json     # 10-nanorod tapered-chirped helix coordinates
│   ├── bessel_source/
│   │   └── nonparaxial_bessel_source_36pw.json# 36-plane-wave Bessel source configuration
│   ├── force_MST/
│   │   └── mst_nfft_monitors_config.json      # Maxwell Stress Tensor box monitor setups
│   ├── near_to_far/
│   │   └── farfield_scattering_matrices_1060nm.npz # Near-to-far field projection dataset
│   ├── convergence/
│   │   └── plane_wave_discretization_convergence.csv # N_pw in {18, 36, 72} convergence data
│   ├── fdtd_quantum_pipeline.lsf              # Automated Lumerical script
│   ├── fdtd_lumerical_api.py                  # Python lumapi controller
│   └── johnson_christy_gold_fit.json          # Multi-coefficient Drude-Lorentz material fit
│
├── Data/                                      # Full computational datasets
│   ├── master_dataset.csv                     # Master optical cross-sections & force observables
│   ├── LHS_90.csv                             # 90-point Latin Hypercube design dataset
│   ├── LHS_120.csv                            # 120-point Latin Hypercube convergence dataset
│   └── scattering_matrices/
│       ├── farfield_scattering_matrices_1060nm.npz # Angular scattering field matrices
│       └── scattering_moments_1060nm.json     # Multipolar scattering moments (ED, MD, EQ, MQ)
│
├── Python/                                    # Analytical & statistical routines
│   ├── reproduce_all_paper_results.py         # Master automated verification script
│   ├── quantum_statistics.py                  # Effective momentum-channel quantum statistics
│   ├── PSD_ASD.py                             # Single-sided PSD (S_FF) and ASD (sqrt(S_FF)) solver
│   ├── SNR_analysis.py                        # Coherent and Fock-state SNR calculator
│   ├── multipolar_analysis.py                 # Multipolar covariance decomposition script
│   ├── momentum_transfer.py                   # Canonical photon momentum partition module
│   └── noise_analysis.py                      # Force noise variance and spectral density solver
│
├── Figures/                                   # High-resolution manuscript figures & scripts
│   ├── figure_generation_scripts/
│   │   └── generate_all_manuscript_figures.py # Master figure generator (Figures 1-9)
│   ├── Figure1_system_schematic.pdf           # Schematic and quantum workflow
│   ├── Figure2_classical_quantum_validation.pdf# Consistency checks & eta_F < 1
│   ├── Figure3_force_noise_spectra.pdf        # Force, noise ASD, and PSD spectra
│   ├── Figure4_chirality_polarization_comparison.pdf # RH vs LH vs Achiral under LCP/RCP
│   ├── Figure5_chiral_contrasts.pdf           # Helicity contrast spectra
│   ├── Figure6_force_noise_pareto.pdf         # 90-point LHS Pareto frontier
│   ├── Figure7_multipolar_noise_decomposition.pdf # Multipolar breakdown
│   ├── Figure8_photon_number_scaling.pdf      # Coherent/Fock/Squeezed scaling
│   ├── Figure9_cd_force_noise_correlations.pdf # CD vs Force vs Noise correlations
│   └── Graphical_Abstract.pdf                 # Publication graphical abstract
│
└── Supplementary/                             # Numerical convergence and sensitivity tables
    └── relevant_tables_data/
        ├── table_S1_absorption_sensitivity.csv # Absorption coupling factor chi_abs in [0.5, 1.5]
        ├── table_S7_plane_wave_convergence.csv # Plane-wave discretization convergence table
        └── table_S3_lhs_convergence.csv        # 90 vs 120 LHS regression metrics
```

---

## ⚙️ Mathematical Definitions

### 1. Optical Pulling Recoil Force
Under non-paraxial Bessel illumination with conical half-angle $\theta_0 = \arccos(0.650) \approx 49.46^\circ$, the axial pulling force per unit intensity is:
$$\langle F_z \rangle = \frac{n_m}{c} \sigma_{\mathrm{pr},z} = \frac{n_m}{c} \left[ \sigma_\mathrm{abs} \cos\theta_0 + \sigma_\mathrm{scat} (\cos\theta_0 - \langle\cos\theta_\mathrm{scat}\rangle) \right]$$
Optical pulling occurs when $\langle\cos\theta_\mathrm{scat}\rangle > \cos\theta_0 (1 + \sigma_\mathrm{abs}/\sigma_\mathrm{scat}) = 0.793$. For our structure, $\langle\cos\theta_\mathrm{scat}\rangle = 0.954$, yielding $\langle F_z \rangle = -10.35\text{ pN}/(\text{W}/\mu\text{m}^2)$.

### 2. Single-Sided Force-Noise Spectral Density
$$\begin{aligned}
S_{FF} &= 2 \Phi_\mathrm{inc} \sigma_\mathrm{ext} \langle(\Delta p_z)^2\rangle_1 = 2.316 \times 10^{-38}\text{ N}^2/\text{Hz} \\
\sqrt{S_{FF}} &= \sqrt{2 \Phi_\mathrm{inc} \sigma_\mathrm{ext} \langle(\Delta p_z)^2\rangle_1} = 0.1522\text{ aN}/\sqrt{\text{Hz}}
\end{aligned}$$
where $\Phi_\mathrm{inc} = I_\mathrm{inc}/\hbar\omega = 5.3362 \times 10^{30}\text{ photons}/(\text{s}\cdot\text{m}^2)$ at reference irradiance $I_\mathrm{inc} = 1.0\text{ W}/\mu\text{m}^2$.

---

## 📜 License & Citation

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

If you use this code or dataset in your research, please cite:
```bibtex
@article{priyanka2026chiral,
  title={Chiral Plasmonic Enhancement of Optical Pulling and Force Sensitivity under Non-Paraxial Bessel Illumination},
  author={Priyanka and Soorat, Ram},
  journal={Optics \& Laser Technology},
  year={2026}
}
```
