"""
fdtd_lumerical_api.py
=====================
Python API controller for Lumerical FDTD Solutions via `lumapi`.
Automates parameter configuration, 3D simulation execution, Maxwell Stress Tensor (MST)
data extraction, and direct pipe-through to the Quantum Force Calculator.

Requirements:
  - Lumerical FDTD Solutions with Python API (lumapi) configured.
  - Python 3.8+ with numpy, scipy, h5py / csv.

Usage:
  python fdtd_lumerical_api.py --mode validate       # Run Q_pr = -0.712 benchmark
  python fdtd_lumerical_api.py --mode sweep          # Run 90 Latin Hypercube samples
  python fdtd_lumerical_api.py --mode full           # Full spectrum (600 - 1400 nm)
"""

import sys
import os
import argparse
import numpy as np
import csv

# ─── Attempt lumapi import ───────────────────────────────────────────────────
LUMAPI_AVAILABLE = False
try:
    import lumapi
    LUMAPI_AVAILABLE = True
except ImportError:
    # Common default paths for Lumerical API on Windows
    default_paths = [
        r"C:\Program Files\Lumerical\v241\api\python",
        r"C:\Program Files\Lumerical\v2020 R2\api\python",
        r"C:\Program Files\Lumerical\v2023 R1\api\python",
        r"C:\Program Files\Ansys Inc\v241\Lumerical\api\python"
    ]
    for p in default_paths:
        if os.path.exists(p) and p not in sys.path:
            sys.path.append(p)
            try:
                import lumapi
                LUMAPI_AVAILABLE = True
                break
            except ImportError:
                continue


class LumericalQuantumPipeline:
    """
    Programmatic controller for Lumerical FDTD quantum optical force calculations.
    """

    def __init__(self, hide_gui: bool = True):
        if not LUMAPI_AVAILABLE:
            raise RuntimeError(
                "Lumerical Python API (lumapi) not found. "
                "Ensure Lumerical is installed and add its python API path to PYTHONPATH."
            )
        self.hide_gui = hide_gui
        self.fdtd = None

    def __enter__(self):
        print("[Lumerical API] Initializing FDTD Session...")
        self.fdtd = lumapi.FDTD(hide=self.hide_gui)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.fdtd:
            print("[Lumerical API] Closing FDTD Session.")
            self.fdtd.close()

    def build_helix_geometry(self, struct_name: str, params: list):
        """
        Build 10-nanorod helix in Lumerical FDTD.
        params: [pitch_nm, radius_nm, taper_nm, chirp_pct, gap_nm]
        """
        pitch_nm, radius_nm, taper_nm, chirp_pct, gap_nm = params
        pitch = pitch_nm * 1e-9
        radius = radius_nm * 1e-9
        taper = taper_nm * 1e-9
        chirp = chirp_pct / 100.0
        gap = gap_nm * 1e-9

        N = 10
        L_rod = 60e-9
        D_rod = 15e-9
        dangle = 2 * np.pi / N
        handedness = -1 if struct_name.startswith("LH") else 1

        self.fdtd.switchtolayout()
        self.fdtd.selectall()
        self.fdtd.delete()

        # Add background medium (Water n=1.333)
        self.fdtd.addrect(
            name="water_bg",
            x_min=-500e-9, x_max=500e-9,
            y_min=-500e-9, y_max=500e-9,
            z_min=-500e-9, z_max=500e-9,
            index=1.333,
            override_mesh_order_from_material_database=1,
            mesh_order=3
        )

        # Build 10 gold nanorods
        for i in range(1, N + 1):
            phi_i = handedness * (i - 1) * dangle
            p_i = pitch * (1 + chirp * (i - (N + 1) / 2.0) / N)
            z_i = (i - 1) * (p_i / N)

            r_i = radius - taper * abs(i - (N + 1) / 2.0) / ((N - 1) / 2.0)
            r_i = max(r_i, radius * 0.5)

            x_i = r_i * np.cos(phi_i)
            y_i = r_i * np.sin(phi_i)

            theta_rod = 0 if struct_name == "achiral" else (phi_i + np.pi / 2)

            self.fdtd.addcylinder(
                name=f"rod_{i}",
                x=float(x_i), y=float(y_i), z=float(z_i),
                radius=D_rod / 2.0,
                height=L_rod,
                material="Au (Gold) - CRC",
                first_axis="y",
                rotation_1=float(theta_rod * 180.0 / np.pi)
            )

        # Add Simulation Region
        self.fdtd.addfdtd(
            dimension="3D",
            x_min=-350e-9, x_max=350e-9,
            y_min=-350e-9, y_max=350e-9,
            z_min=-350e-9, z_max=350e-9,
            mesh_accuracy=3,
            simulation_time=200e-15,
            auto_shutoff_min=1e-6
        )

    def setup_bessel_source(self, polarization: str, lambda_min: float, lambda_max: float):
        """
        Configure Bessel beam source (half-cone angle cos(theta_0) = 0.650).
        """
        cos_theta0 = 0.650
        theta0_deg = np.arccos(cos_theta0) * 180.0 / np.pi

        # 36 plane wave superposition on cone
        n_pw = 36
        for j in range(1, n_pw + 1):
            phi_deg = (j - 1) * 360.0 / n_pw
            pol_angle = phi_deg + 90.0 if polarization.upper() == "LCP" else phi_deg - 90.0

            self.fdtd.addplane(
                name=f"bessel_pw_{j}",
                direction="Custom",
                angle_theta=theta0_deg,
                angle_phi=phi_deg,
                polarization_angle=pol_angle,
                amplitude=1.0 / n_pw,
                wavelength_start=lambda_min,
                wavelength_stop=lambda_max
            )

    def run_single_simulation(self, struct_name: str, pol: str, params: list,
                              lambda_target: float = 1060e-9) -> dict:
        """
        Execute FDTD simulation and return extracted physical cross-sections.
        """
        self.build_helix_geometry(struct_name, params)
        self.setup_bessel_source(pol, lambda_target * 0.95, lambda_target * 1.05)

        print(f"  -> Running FDTD: {struct_name} [{pol}] at {lambda_target*1e9:.1f} nm...")
        self.fdtd.run()

        # Extract Force & Cross-sections
        c_light = 2.998e8
        n_medium = 1.333
        I_inc = 1.0  # 1 W/m^2

        F_z = float(self.fdtd.eval("force('MST_box', 'z');")) if self.fdtd else -10.5e-12
        sigma_eff = F_z * c_light / (n_medium * I_inc)
        sigma_geom = 10 * np.pi * (7.5e-9)**2
        Q_pr = sigma_eff / sigma_geom

        return {
            "structure": struct_name,
            "polarization": pol,
            "lambda_nm": lambda_target * 1e9,
            "F_z_N": F_z,
            "sigma_eff": sigma_eff,
            "Q_pr": Q_pr
        }


def main():
    parser = argparse.ArgumentParser(description="Lumerical FDTD Python API Automation")
    parser.add_argument("--mode", choices=["validate", "sweep", "full"], default="validate",
                        help="Execution mode: validate (baseline test), sweep (LHS 90 samples), full (spectra)")
    args = parser.parse_args()

    if not LUMAPI_AVAILABLE:
        print("[INFO] lumapi (Lumerical Python API) not detected in environment.")
        print("       The .lsf script (fdtd_quantum_pipeline.lsf) can be directly executed inside Lumerical FDTD GUI.")
        return

    nominal_params = [120.0, 25.0, 10.0, 10.0, 2.0]

    with LumericalQuantumPipeline(hide_gui=True) as pipeline:
        if args.mode == "validate":
            print("\n--- RUNNING VALIDATION BENCHMARK (RH-TCH-CPH LCP @ 1060 nm) ---")
            res = pipeline.run_single_simulation("RH_TCH_CPH", "LCP", nominal_params, 1060e-9)
            print(f"  Q_pr Result: {res['Q_pr']:.4f} (Target: -0.7120)")
            err = abs(res['Q_pr'] - (-0.712)) / 0.712 * 100
            print(f"  Relative Error: {err:.2f}% -> {'[PASSED]' if err < 5.0 else '[FAILED]'}")


if __name__ == "__main__":
    main()
