"""
Stochastic Momentum-Transfer Channel Model
Calculates single-photon momentum moments (mu_dp, dp2_1, V_dp)
and single-photon force-transfer efficiency eta_F.
"""
import numpy as np

# Physical constants
HBAR = 1.054571817e-34
C = 2.99792458e8
N_M = 1.333  # Water refractive index
LAMBDA_0 = 1060.0e-9
OMEGA = 2.0 * np.pi * C / LAMBDA_0
K_MED = N_M * OMEGA / C
P_PHOTON = N_M * HBAR * OMEGA / C  # Minkowski canonical momentum
COS_THETA_0 = 0.650

def calculate_single_photon_moments(sigma_ext, sigma_scat, sigma_abs, mean_cos_theta, mean_cos2_theta, chi_abs=1.0):
    """
    Compute single-photon momentum-transfer moments.
    """
    # Mean momentum transfer
    sigma_prz = sigma_ext * COS_THETA_0 - sigma_scat * mean_cos_theta
    mu_dp = P_PHOTON * (sigma_prz / sigma_ext)
    
    # Second raw moment <(dp_z)^2>_1
    scat_term = sigma_scat * (COS_THETA_0**2 - 2.0 * COS_THETA_0 * mean_cos_theta + mean_cos2_theta)
    abs_term = sigma_abs * (chi_abs * COS_THETA_0)**2
    mean_dp2_1 = (P_PHOTON**2 / sigma_ext) * (scat_term + abs_term)
    
    # Variance
    var_dp = mean_dp2_1 - mu_dp**2
    
    # Force-transfer efficiency
    eta_F = np.abs(mu_dp) / np.sqrt(mean_dp2_1)
    
    return {
        'sigma_prz': sigma_prz,
        'mu_dp': mu_dp,
        'mean_dp2_1': mean_dp2_1,
        'var_dp': var_dp,
        'eta_F': eta_F
    }

if __name__ == '__main__':
    # Chiral RH-TCH-CPH (LCP)
    res_chiral = calculate_single_photon_moments(
        sigma_ext=1.77e-14, sigma_scat=1.45e-14, sigma_abs=0.32e-14,
        mean_cos_theta=0.852, mean_cos2_theta=0.768
    )
    print('Chiral RH-TCH-CPH (LCP):')
    print(f'  mu_dp: {res_chiral["mu_dp"]:.3e} kg*m/s')
    print(f'  <(dp_z)^2>_1: {res_chiral["mean_dp2_1"]:.3e} kg^2*m^2/s^2')
    print(f'  V_dp: {res_chiral["var_dp"]:.3e} kg^2*m^2/s^2')
    print(f'  eta_F: {res_chiral["eta_F"]:.4f}')
