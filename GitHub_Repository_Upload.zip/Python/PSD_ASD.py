"""
PSD_ASD.py
==========
Calculates single-sided and double-sided power spectral density (PSD)
and amplitude spectral density (ASD) of optical pulling forces.

Key Reference Equations:
  Single-sided PSD: S_FF = 2 * Phi_inc * sigma_ext * <(Delta p_z)^2>_1
  Single-sided ASD: sqrt(S_FF) = sqrt(2 * Phi_inc * sigma_ext * <(Delta p_z)^2>_1)

For RH-TCH-CPH (LCP, 1060 nm):
  Phi_inc = 5.3362e30 photons/(s*m^2) (at I_inc = 1.0 W/um^2)
  sigma_ext = 1.77e-14 m^2
  <(Delta p_z)^2>_1 = 12.26e-56 kg^2*m^2/s^2
  -> S_FF = 2.316e-38 N^2/Hz
  -> ASD  = 0.1522 aN/sqrt(Hz) (reported as 0.152 aN/sqrt(Hz))
"""

import numpy as np

def calculate_force_noise(sigma_ext_m2, dp_sq_mean_kg2_m2_s2, I_inc_W_m2=1.0e12, wavelength_nm=1060.0, n_medium=1.333):
    c = 2.99792458e8
    h_bar = 1.054571817e-34
    omega = 2.0 * np.pi * c / (wavelength_nm * 1e-9)
    E_photon = h_bar * omega
    phi_inc = I_inc_W_m2 / E_photon
    
    # Single-sided PSD (f >= 0)
    S_FF_single = 2.0 * phi_inc * sigma_ext_m2 * dp_sq_mean_kg2_m2_s2
    ASD_single_SI = np.sqrt(S_FF_single)
    ASD_single_aN_rHz = ASD_single_SI * 1e18
    
    # Double-sided PSD (-inf < f < inf)
    S_FF_double = S_FF_single / 2.0
    ASD_double_aN_rHz = np.sqrt(S_FF_double) * 1e18
    
    return {
        'phi_inc': phi_inc,
        'PSD_single_sided_N2_Hz': S_FF_single,
        'ASD_single_sided_aN_rHz': ASD_single_aN_rHz,
        'PSD_double_sided_N2_Hz': S_FF_double,
        'ASD_double_sided_aN_rHz': ASD_double_aN_rHz
    }

if __name__ == '__main__':
    chiral = calculate_force_noise(1.77e-14, 12.26e-56)
    achiral = calculate_force_noise(0.81e-14, 16.53e-56)
    
    print("RH-TCH-CPH (LCP, 1060 nm):")
    print(f"  Single-sided PSD: {chiral['PSD_single_sided_N2_Hz']:.4e} N^2/Hz")
    print(f"  Single-sided ASD: {chiral['ASD_single_sided_aN_rHz']:.4f} aN/sqrt(Hz) [Master text: 0.1522 aN/sqrt(Hz)]")
    print(f"  Double-sided ASD: {chiral['ASD_double_sided_aN_rHz']:.4f} aN/sqrt(Hz) [Historical factor-sqrt(2)]")
    
    print("\nAchiral Control (1060 nm):")
    print(f"  Single-sided PSD: {achiral['PSD_single_sided_N2_Hz']:.4e} N^2/Hz")
    print(f"  Single-sided ASD: {achiral['ASD_single_sided_aN_rHz']:.4f} aN/sqrt(Hz) [Master text: 0.1195 aN/sqrt(Hz)]")
    
    N_F = chiral['ASD_single_sided_aN_rHz'] / achiral['ASD_single_sided_aN_rHz']
    print(f"\nNoise ASD Ratio N_F: {N_F:.4f} [Reported: 1.274]")
