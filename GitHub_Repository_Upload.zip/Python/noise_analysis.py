"""
Quantum Force Noise Spectral Density and Fluctuation Analysis
Calculates single-sided shot-noise spectral density S_FF(omega)
and compares with thermal hydrodynamic Brownian noise.
"""
import numpy as np
from momentum_transfer import calculate_single_photon_moments, HBAR, OMEGA

KB = 1.380649e-23
T_ROOM = 293.15
ETA_WATER = 1.002e-3  # Pa*s
R_HYD = 45.0e-9       # Hydrodynamic radius (m)

def calculate_force_noise(I_inc_W_m2, sigma_ext, mean_dp2_1):
    """
    Calculate single-sided quantum force-noise spectral density S_FF = 2 * N_dot * <(dp_z)^2>_1
    """
    phi_inc = I_inc_W_m2 / (HBAR * OMEGA)
    n_dot = phi_inc * sigma_ext
    S_FF = 2.0 * n_dot * mean_dp2_1
    return S_FF, np.sqrt(S_FF)

def calculate_brownian_noise():
    """
    Calculate hydrodynamic Brownian noise in room-temperature water.
    """
    gamma_drag = 6.0 * np.pi * ETA_WATER * R_HYD
    S_FF_brown = 4.0 * KB * T_ROOM * gamma_drag
    return S_FF_brown, np.sqrt(S_FF_brown)

if __name__ == '__main__':
    I_inc = 1.0e12  # 1.0 W/um^2
    res_chiral = calculate_single_photon_moments(
        sigma_ext=1.77e-14, sigma_scat=1.45e-14, sigma_abs=0.32e-14,
        mean_cos_theta=0.852, mean_cos2_theta=0.768
    )
    S_FF_shot, ASD_shot = calculate_force_noise(I_inc, 1.77e-14, res_chiral['mean_dp2_1'])
    S_FF_brown, ASD_brown = calculate_brownian_noise()
    print(f'Quantum shot noise S_FF: {S_FF_shot:.2e} N^2/Hz (ASD: {ASD_shot*1e18:.3f} aN/rHz)')
    print(f'Thermal Brownian noise S_FF: {S_FF_brown:.2e} N^2/Hz (ASD: {ASD_brown*1e18:.3f} aN/rHz)')
