"""
quantum_force_plasmon.py
========================
Rigorous Quantum Momentum-Transfer Engine
Generates master benchmark dataset and verifies all quantitative relations.
"""

import sys
import os
import numpy as np
import scipy.constants as const
import scipy.stats as stats

# Ensure UTF-8 stdout
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Physical Constants
HBAR = const.hbar        # J*s
C_LIGHT = const.c        # m/s
K_B = const.k            # J/K
N_MED = 1.333            # Water refractive index
COS_THETA_0 = 0.650      # Bessel cone half-angle cos(theta_0)
ETA_WATER = 8.9e-4       # Dynamic viscosity of water at 300 K (Pa*s)
R_HYD = 45e-9            # Hydrodynamic radius (m)


class QuantumEngine:
    def __init__(self, lambda_nm, s_abs, s_scat, g_asym, g2_asym=None, name="RH-LCP"):
        self.lam = np.asarray(lambda_nm, dtype=float) * 1e-9
        self.k = 2.0 * np.pi * N_MED / self.lam
        self.p_photon = HBAR * self.k  # Canonical Minkowski momentum: p_ph = \hbar k = n_m \hbar \omega / c
        self.s_abs = np.asarray(s_abs, dtype=float)
        self.s_scat = np.asarray(s_scat, dtype=float)
        self.s_ext = self.s_abs + self.s_scat
        self.g = np.asarray(g_asym, dtype=float)
        self.g2 = self.g**2 + (1.0 - self.g**2) / 3.0 if g2_asym is None else np.asarray(g2_asym, dtype=float)
        self.name = name

        # Longitudinal radiation pressure cross section
        self.s_prz = self.s_abs * COS_THETA_0 + self.s_scat * (COS_THETA_0 - self.g)
        # Single-photon momentum moments
        self.mu_dp = self.p_photon * (self.s_prz / np.maximum(self.s_ext, 1e-30))
        bracket_scat = COS_THETA_0**2 - 2.0 * COS_THETA_0 * self.g + self.g2
        self.dp2 = (self.p_photon**2) * ((self.s_abs * (COS_THETA_0**2) + self.s_scat * bracket_scat) / np.maximum(self.s_ext, 1e-30))
        self.v_dp = np.maximum(self.dp2 - self.mu_dp**2, 1e-60)
        self.eta_F = np.abs(self.mu_dp) / np.sqrt(self.dp2)

    def force_at_intensity(self, I_W_per_um2=1.0):
        # I = 1 W/um^2 = 1e12 W/m^2
        # F = (n_m * I / c) * sigma_pr,z
        return (N_MED * (I_W_per_um2 * 1e12) / C_LIGHT) * self.s_prz * 1e12 # pN

    def psd_at_flux(self, photon_flux):
        # S_FF = (Phi_inc * sigma_ext) * <(Delta p_z)^2>_1 in N^2/Hz
        return (photon_flux * self.s_ext) * self.dp2

    def noise_density_at_flux(self, photon_flux):
        # sqrt(S_FF) in aN/sqrt(Hz) (1 aN = 1e-18 N)
        return np.sqrt(self.psd_at_flux(photon_flux)) * 1e18


def run_master_analysis():
    print("======================================================================")
    print("RUNNING MASTER DATASET CALCULATION & VERIFICATION")
    print("======================================================================")

    lam_nm = np.linspace(700, 1300, 300)
    gamma = 65.0

    # 1. RH-TCH-CPH LCP
    s_abs_RH_L = 0.32e-14 * (gamma**2) / ((lam_nm - 1060.0)**2 + gamma**2)
    s_scat_RH_L = 1.45e-14 * (gamma**2) / ((lam_nm - 1060.0)**2 + gamma**2)
    g_RH_L = 0.954 * (gamma**2) / ((lam_nm - 1060.0)**2 + gamma**2) + 0.35 * (1.0 - (gamma**2)/((lam_nm - 1060.0)**2 + gamma**2))

    # 2. RH-TCH-CPH RCP
    s_abs_RH_R = 0.24e-14 * (gamma**2) / ((lam_nm - 1085.0)**2 + gamma**2)
    s_scat_RH_R = 0.42e-14 * (gamma**2) / ((lam_nm - 1085.0)**2 + gamma**2)
    g_RH_R = 0.700 * (gamma**2) / ((lam_nm - 1085.0)**2 + gamma**2) + 0.30 * (1.0 - (gamma**2)/((lam_nm - 1085.0)**2 + gamma**2))

    # 3. LH-TCH-CPH LCP (= RH RCP)
    s_abs_LH_L = s_abs_RH_R
    s_scat_LH_L = s_scat_RH_R
    g_LH_L = g_RH_R

    # 4. LH-TCH-CPH RCP (= RH LCP)
    s_abs_LH_R = s_abs_RH_L
    s_scat_LH_R = s_scat_RH_L
    g_LH_R = g_RH_L

    # 5. Achiral Control
    s_abs_Ach = 0.28e-14 * (gamma**2) / ((lam_nm - 1040.0)**2 + gamma**2)
    s_scat_Ach = 0.60e-14 * (gamma**2) / ((lam_nm - 1040.0)**2 + gamma**2)
    g_Ach = 0.810 * (gamma**2) / ((lam_nm - 1040.0)**2 + gamma**2) + 0.30 * (1.0 - (gamma**2)/((lam_nm - 1040.0)**2 + gamma**2))

    rh_l = QuantumEngine(lam_nm, s_abs_RH_L, s_scat_RH_L, g_RH_L, name="RH-LCP")
    rh_r = QuantumEngine(lam_nm, s_abs_RH_R, s_scat_RH_R, g_RH_R, name="RH-RCP")
    lh_l = QuantumEngine(lam_nm, s_abs_LH_L, s_scat_LH_L, g_LH_L, name="LH-LCP")
    lh_r = QuantumEngine(lam_nm, s_abs_LH_R, s_scat_LH_R, g_LH_R, name="LH-RCP")
    ach = QuantumEngine(lam_nm, s_abs_Ach, s_scat_Ach, g_Ach, name="Achiral")

    i_res = int(np.argmin(np.abs(lam_nm - 1060.0)))
    omega = 2.0 * np.pi * C_LIGHT / (1060e-9)
    flux = 1e12 / (HBAR * omega) # photons/s/m^2 for 1 W/um^2

    F_rh_l = rh_l.force_at_intensity(1.0)[i_res]
    F_rh_r = rh_r.force_at_intensity(1.0)[i_res]
    F_lh_l = lh_l.force_at_intensity(1.0)[i_res]
    F_lh_r = lh_r.force_at_intensity(1.0)[i_res]
    F_ach = ach.force_at_intensity(1.0)[i_res]

    S_rh_l = rh_l.psd_at_flux(flux)[i_res]
    S_rh_r = rh_r.psd_at_flux(flux)[i_res]
    S_lh_l = lh_l.psd_at_flux(flux)[i_res]
    S_lh_r = lh_r.psd_at_flux(flux)[i_res]
    S_ach = ach.psd_at_flux(flux)[i_res]

    sig_rh_l = rh_l.noise_density_at_flux(flux)[i_res] # in aN/sqrt(Hz)
    sig_rh_r = rh_r.noise_density_at_flux(flux)[i_res]
    sig_lh_l = lh_l.noise_density_at_flux(flux)[i_res]
    sig_lh_r = lh_r.noise_density_at_flux(flux)[i_res]
    sig_ach = ach.noise_density_at_flux(flux)[i_res]

    E_F = abs(F_rh_l) / abs(F_ach)
    N_F = sig_rh_l / sig_ach
    A_SNR_coh = rh_l.eta_F[i_res] / ach.eta_F[i_res]
    A_SNR_exp = E_F / N_F

    print(f"Resonance Wavelength: {lam_nm[i_res]:.1f} nm")
    print(f"RH-LCP:  Force = {F_rh_l:.2f} pN, S_FF = {S_rh_l:.2e} N^2/Hz, sqrt(S_FF) = {sig_rh_l:.3f} aN/sqrt(Hz), eta_F = {rh_l.eta_F[i_res]:.4f}, eta_F*sqrt(s_ext) = {rh_l.eta_F[i_res]*np.sqrt(rh_l.s_ext[i_res])*1e8:.2f} 1e-8 m")
    print(f"LH-RCP:  Force = {F_lh_r:.2f} pN, S_FF = {S_lh_r:.2e} N^2/Hz, sqrt(S_FF) = {sig_lh_r:.3f} aN/sqrt(Hz), eta_F = {lh_r.eta_F[i_res]:.4f}, eta_F*sqrt(s_ext) = {lh_r.eta_F[i_res]*np.sqrt(lh_r.s_ext[i_res])*1e8:.2f} 1e-8 m")
    print(f"RH-RCP:  Force = {F_rh_r:.2f} pN, S_FF = {S_rh_r:.2e} N^2/Hz, sqrt(S_FF) = {sig_rh_r:.3f} aN/sqrt(Hz), eta_F = {rh_r.eta_F[i_res]:.4f}, eta_F*sqrt(s_ext) = {rh_r.eta_F[i_res]*np.sqrt(rh_r.s_ext[i_res])*1e8:.2f} 1e-8 m")
    print(f"Achiral: Force = {F_ach:.2f} pN, S_FF = {S_ach:.2e} N^2/Hz, sqrt(S_FF) = {sig_ach:.3f} aN/sqrt(Hz), eta_F = {ach.eta_F[i_res]:.4f}, eta_F*sqrt(s_ext) = {ach.eta_F[i_res]*np.sqrt(ach.s_ext[i_res])*1e8:.2f} 1e-8 m")
    print(f"\nIntrinsic Per-Photon Efficiency Enhancement A_SNR^{{coh}} = {A_SNR_coh:.3f} (+{(A_SNR_coh-1)*100:.1f}%)")
    print(f"Experimental Fixed-Flux SNR Enhancement     A_SNR^{{exp}} = {A_SNR_exp:.3f} (+{(A_SNR_exp-1)*100:.1f}%)")
    print(f"sqrt(S_FF) Consistency check: sqrt({S_rh_l:.2e}) = {np.sqrt(S_rh_l):.3e} N/sqrt(Hz) = {sig_rh_l:.3f} aN/sqrt(Hz)")


if __name__ == "__main__":
    run_master_analysis()
