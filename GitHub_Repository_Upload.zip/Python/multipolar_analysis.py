"""
multipolar_analysis.py
======================
Evaluates multipolar decomposition of the modeled momentum-transfer variance
V_dp and verifies that ED-MD forward-interference covariance contributes +30.8%
as the largest individual cross-covariance contribution.
"""

DIAGONAL_TERMS = {
    'ED auto-variance': 0.285,
    'MD auto-variance': 0.134,
    'EQ auto-variance': 0.058,
    'MQ auto-variance': 0.004
}

CROSS_TERMS = {
    'ED-MD cross-covariance': 0.308,
    'ED-EQ cross-covariance': 0.142,
    'MD-EQ cross-covariance': 0.059,
    'Higher-order (MQ cross-terms)': 0.010
}

def verify_multipolar_balance():
    diag_sum = sum(DIAGONAL_TERMS.values())
    cross_sum = sum(CROSS_TERMS.values())
    total_sum = diag_sum + cross_sum
    
    print("=== MULTIPOLAR MOMENTUM VARIANCE DECOMPOSITION (Table 3) ===")
    print(f"Diagonal Sub-total: {diag_sum * 100:.1f}% (Reported: 48.1%)")
    print(f"Cross Sub-total:    {cross_sum * 100:.1f}% (Reported: 51.9%)")
    print(f"Total:              {total_sum * 100:.1f}% (Reported: 100.0%)")
    print(f"Largest cross term: ED-MD covariance = +{CROSS_TERMS['ED-MD cross-covariance'] * 100:.1f}%")
    
    f_mst = -10.347
    f_multi = -10.120
    residual = abs(f_mst - f_multi) / abs(f_mst) * 100
    print(f"Truncated multipolar force residual: {residual:.1f}% (Reported: ~2.2%)")

if __name__ == '__main__':
    verify_multipolar_balance()
