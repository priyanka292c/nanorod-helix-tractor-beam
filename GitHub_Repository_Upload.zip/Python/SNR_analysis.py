"""
Signal-to-Noise Ratio (SNR) Analysis for Optical Pulling
Calculates single-interacting-photon and fixed-flux coherent-state SNR enhancements.
"""
import numpy as np
from momentum_transfer import calculate_single_photon_moments

def calculate_snr_enhancements():
    # Chiral structure
    c = calculate_single_photon_moments(
        sigma_ext=1.77e-14, sigma_scat=1.45e-14, sigma_abs=0.32e-14,
        mean_cos_theta=0.852, mean_cos2_theta=0.768
    )
    # Achiral control
    a = calculate_single_photon_moments(
        sigma_ext=0.81e-14, sigma_scat=0.59e-14, sigma_abs=0.22e-14,
        mean_cos_theta=0.385, mean_cos2_theta=0.312
    )
    
    # 1. Single-interacting-photon SNR gain
    A_SNR_int = c['eta_F'] / a['eta_F']
    
    # 2. Force ratio and noise ratio
    E_F = 10.35 / 4.525
    N_F = np.sqrt((1.77e-14 * c['mean_dp2_1']) / (0.81e-14 * a['mean_dp2_1']))
    
    # Fixed-flux coherent SNR gain
    A_SNR_phi = np.sqrt(1.77e-14 / 0.81e-14) * A_SNR_int
    
    print('=== SNR ANALYSIS RESULTS ===')
    print(f'Chiral eta_F: {c["eta_F"]:.4f}, Achiral eta_F: {a["eta_F"]:.4f}')
    print(f'Single-Interacting-Photon Gain A_SNR^int: {A_SNR_int:.4f} (+{(A_SNR_int-1)*100:.1f}%)')
    print(f'Mean Force Ratio E_F: {E_F:.3f}')
    print(f'Noise Amplitude Ratio N_F: {N_F:.3f}')
    print(f'Fixed-Flux Coherent SNR Gain A_SNR^Phi: {A_SNR_phi:.4f} (+{(A_SNR_phi-1)*100:.1f}%)')
    print(f'Check E_F / N_F: {E_F / N_F:.4f}')

if __name__ == '__main__':
    calculate_snr_enhancements()
